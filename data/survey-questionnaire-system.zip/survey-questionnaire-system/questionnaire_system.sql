/*
 Navicat Premium Data Transfer

 Source Server         : local
 Source Server Type    : MySQL
 Source Server Version : 80019
 Source Host           : localhost:3306
 Source Schema         : questionnaire_system

 Target Server Type    : MySQL
 Target Server Version : 80019
 File Encoding         : 65001

 Date: 17/05/2024 15:29:32
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for answer
-- ----------------------------
DROP TABLE IF EXISTS `answer`;
CREATE TABLE `answer`  (
  `answer_id` bigint NOT NULL AUTO_INCREMENT COMMENT '答案id',
  `survey_id` bigint NULL DEFAULT NULL COMMENT '问卷id',
  `question_id` bigint NULL DEFAULT NULL COMMENT '问题id',
  `answer_context` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '输入的内容',
  `option_id` bigint NULL DEFAULT NULL COMMENT '选择题选项id',
  `create_time` datetime NULL DEFAULT NULL COMMENT '回答完成时间',
  `survey_finish_log_id` bigint NULL DEFAULT NULL COMMENT '问卷完成记录的id',
  PRIMARY KEY (`answer_id`) USING BTREE,
  INDEX `survey_id`(`survey_id`) USING BTREE,
  CONSTRAINT `answer_ibfk_1` FOREIGN KEY (`survey_id`) REFERENCES `survey` (`survey_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 1257 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '问卷结果表\r\n' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for article
-- ----------------------------
DROP TABLE IF EXISTS `article`;
CREATE TABLE `article`  (
  `article_id` bigint NOT NULL AUTO_INCREMENT COMMENT '文章id',
  `article_title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '文章标题',
  `article_desc` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '文章描述',
  `article_content` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '文章内容',
  `article_image` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '文章封面',
  `article_views` bigint UNSIGNED NULL DEFAULT NULL COMMENT '文章浏览量',
  `article_tag` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '文章标签(用“,“分隔)',
  `update_time` datetime NULL DEFAULT NULL COMMENT '文章更新时间',
  `create_time` datetime NOT NULL COMMENT '文章发表时间',
  `article_is_open` tinyint(1) NULL DEFAULT NULL COMMENT '是否可以浏览(-1：未撰写内容，1：是，2：否，0：待审核，3：审核不通过)',
  `category_id` bigint NOT NULL COMMENT '分类id',
  `user_id` bigint NOT NULL COMMENT '用户id',
  PRIMARY KEY (`article_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1789202622104735745 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '文章表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for category
-- ----------------------------
DROP TABLE IF EXISTS `category`;
CREATE TABLE `category`  (
  `category_id` bigint NOT NULL AUTO_INCREMENT COMMENT '分类id',
  `category_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '分类名',
  `user_id` bigint NULL DEFAULT NULL COMMENT '所属用户',
  `update_time` datetime NULL DEFAULT NULL COMMENT '分类更新时间',
  PRIMARY KEY (`category_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1790374285462749186 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '分类表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for front_ad
-- ----------------------------
DROP TABLE IF EXISTS `front_ad`;
CREATE TABLE `front_ad`  (
  `ad_id` bigint NOT NULL COMMENT '首页图Id',
  `ad_text` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '备注',
  `ad_status` int NOT NULL COMMENT '首页图状态(1：启用，0：未启用)',
  `ad_sort` tinyint NULL DEFAULT NULL COMMENT '首页图顺序',
  `ad_img` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '首页图地址',
  PRIMARY KEY (`ad_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for question
-- ----------------------------
DROP TABLE IF EXISTS `question`;
CREATE TABLE `question`  (
  `question_id` bigint NOT NULL AUTO_INCREMENT COMMENT '问题id',
  `survey_id` bigint NOT NULL COMMENT '所属的问卷id',
  `question_type` int NOT NULL COMMENT '问题类型id(1单选、2多选、3客观题)',
  `question_content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '问题内容',
  `question_sort` int NOT NULL COMMENT '题目序号',
  PRIMARY KEY (`question_id`) USING BTREE,
  INDEX `survey_id`(`survey_id`) USING BTREE,
  CONSTRAINT `question_ibfk_1` FOREIGN KEY (`survey_id`) REFERENCES `survey` (`survey_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 1790393066188718094 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '问卷问题表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for question_option
-- ----------------------------
DROP TABLE IF EXISTS `question_option`;
CREATE TABLE `question_option`  (
  `option_id` bigint NOT NULL AUTO_INCREMENT COMMENT '选项id',
  `question_id` bigint NOT NULL COMMENT '问卷问题的id',
  `option_content` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '选项内容',
  `option_sort` int NOT NULL COMMENT '选项顺序',
  PRIMARY KEY (`option_id`) USING BTREE,
  INDEX `question_id`(`question_id`) USING BTREE,
  CONSTRAINT `question_option_ibfk_1` FOREIGN KEY (`question_id`) REFERENCES `question` (`question_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 1525 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '选项表，对应问卷问题的选择题' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for report_article
-- ----------------------------
DROP TABLE IF EXISTS `report_article`;
CREATE TABLE `report_article`  (
  `report_id` bigint NOT NULL AUTO_INCREMENT COMMENT '文章举报id',
  `user_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '被举报的文章的用户名',
  `report_article_id` bigint NULL DEFAULT NULL COMMENT '举报的文章id',
  `report_article_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '举报的文章标题',
  `report_count` bigint UNSIGNED NULL DEFAULT NULL COMMENT '被举报的次数',
  `report_reason` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '被举报的理由（拼接所有理由）',
  `report_status` tinyint NULL DEFAULT NULL COMMENT '举报审核状态(0：待审核，1：已审核处置，2：作者整改重申)',
  `report_result` tinyint NULL DEFAULT NULL COMMENT '审核处置结果（1：正常，2：封禁）',
  `update_time` datetime NULL DEFAULT NULL COMMENT '创建和更新时间',
  PRIMARY KEY (`report_id`) USING BTREE,
  INDEX `report_article_id`(`report_article_id`) USING BTREE,
  CONSTRAINT `report_article_ibfk_1` FOREIGN KEY (`report_article_id`) REFERENCES `article` (`article_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '文章举报信息表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for report_survey
-- ----------------------------
DROP TABLE IF EXISTS `report_survey`;
CREATE TABLE `report_survey`  (
  `report_id` bigint NOT NULL AUTO_INCREMENT COMMENT '问卷举报id',
  `user_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '被举报的问卷的用户名',
  `report_survey_id` bigint NULL DEFAULT NULL COMMENT '被举报的问卷id',
  `report_survey_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '被举报的问卷标题',
  `report_count` bigint NULL DEFAULT NULL COMMENT '被举报的次数',
  `report_reason` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '举报的理由',
  `report_status` tinyint NULL DEFAULT NULL COMMENT '举报审核状态(0：待审核，1：已审核处置，2：作者整改重申)',
  `report_result` tinyint NULL DEFAULT NULL COMMENT '审核处置结果(1：正常，2：封禁重置问卷)',
  `update_time` datetime NULL DEFAULT NULL COMMENT '创建和更新时间',
  PRIMARY KEY (`report_id`) USING BTREE,
  INDEX `report_survey_id`(`report_survey_id`) USING BTREE,
  CONSTRAINT `report_survey_ibfk_1` FOREIGN KEY (`report_survey_id`) REFERENCES `survey` (`survey_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '问卷举报信息表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for role
-- ----------------------------
DROP TABLE IF EXISTS `role`;
CREATE TABLE `role`  (
  `role_id` int NOT NULL COMMENT '角色id',
  `role_name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '角色名',
  PRIMARY KEY (`role_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '用户角色表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for router
-- ----------------------------
DROP TABLE IF EXISTS `router`;
CREATE TABLE `router`  (
  `menu_id` int NOT NULL AUTO_INCREMENT COMMENT '菜单id',
  `menu_title` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '菜单名字',
  `menu_pid` int NULL DEFAULT NULL COMMENT '菜单父类id',
  `menu_click` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '路由点击函数',
  `menu_right` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '权限',
  `menu_component` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '路由路径',
  `menu_icon` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '路由图标',
  PRIMARY KEY (`menu_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for survey
-- ----------------------------
DROP TABLE IF EXISTS `survey`;
CREATE TABLE `survey`  (
  `survey_id` bigint NOT NULL AUTO_INCREMENT COMMENT '问卷ID(主键)',
  `user_id` bigint NOT NULL COMMENT '用户id',
  `survey_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '问卷标题',
  `survey_description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '问卷描述',
  `create_time` datetime NULL DEFAULT NULL COMMENT '问卷创建时间',
  `update_time` datetime NULL DEFAULT NULL COMMENT '问卷更新时间',
  `survey_start_time` datetime NULL DEFAULT NULL COMMENT '问卷开始时间',
  `survey_end_time` datetime NULL DEFAULT NULL COMMENT '问卷结束时间',
  `survey_collected` int NOT NULL COMMENT '问卷有多少人做了',
  `survey_collected_limit` int NOT NULL COMMENT '问卷需要收集的总数',
  `survey_category_id` bigint NOT NULL COMMENT '问卷分类id',
  `survey_status` int NOT NULL COMMENT '问卷状态id(发布中1、完成2、未发布0、暂停-1、未设计问卷-2、未开始3)',
  `survey_tip` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '问卷完成后结束语',
  `survey_balance` decimal(10, 2) NULL DEFAULT NULL COMMENT '奖励金额',
  PRIMARY KEY (`survey_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1790393066058694659 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '调查问卷表（主要是问卷的基本信息）' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for survey_bonus
-- ----------------------------
DROP TABLE IF EXISTS `survey_bonus`;
CREATE TABLE `survey_bonus`  (
  `bonus_id` bigint NOT NULL AUTO_INCREMENT COMMENT '奖励ID',
  `survey_id` bigint NULL DEFAULT NULL COMMENT '问卷ID',
  `survey_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '问卷标题',
  `bonus_amount` decimal(10, 2) NULL DEFAULT NULL COMMENT '奖励金额',
  `bonus_account` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '奖励账户',
  `create_time` datetime NULL DEFAULT NULL COMMENT '获得时间',
  `user_id` bigint NULL DEFAULT NULL COMMENT '用户ID',
  PRIMARY KEY (`bonus_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 20 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '奖励记录表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for survey_finish_log
-- ----------------------------
DROP TABLE IF EXISTS `survey_finish_log`;
CREATE TABLE `survey_finish_log`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `survey_id` bigint NULL DEFAULT NULL COMMENT '问卷id',
  `user_id` bigint NULL DEFAULT NULL COMMENT '问卷所属用户id',
  `create_time` datetime NULL DEFAULT NULL COMMENT '问卷完成时间',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `survey_id`(`survey_id`) USING BTREE,
  CONSTRAINT `survey_finish_log_ibfk_1` FOREIGN KEY (`survey_id`) REFERENCES `survey` (`survey_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 124 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '问卷每完成一份的日志' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tmp_option
-- ----------------------------
DROP TABLE IF EXISTS `tmp_option`;
CREATE TABLE `tmp_option`  (
  `tmp_option_id` bigint NOT NULL AUTO_INCREMENT COMMENT '模板选项主键',
  `tmp_question_id` bigint NOT NULL COMMENT '模板问题id',
  `tmp_option_content` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '模板选项内容',
  `tmp_option_sort` int NULL DEFAULT NULL COMMENT '模板选项顺序',
  PRIMARY KEY (`tmp_option_id`) USING BTREE,
  INDEX `tmp_question_id`(`tmp_question_id`) USING BTREE,
  CONSTRAINT `tmp_option_ibfk_1` FOREIGN KEY (`tmp_question_id`) REFERENCES `tmp_question` (`tmp_question_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 529 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '模板选项表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tmp_question
-- ----------------------------
DROP TABLE IF EXISTS `tmp_question`;
CREATE TABLE `tmp_question`  (
  `tmp_question_id` bigint NOT NULL AUTO_INCREMENT COMMENT '模板问题id',
  `tmp_id` bigint NOT NULL COMMENT '模板id',
  `tmp_question_type` int NOT NULL COMMENT '模板问卷类型id(单选、多选、单行输入)',
  `tmp_question_content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '模板问题内容',
  `tmp_question_sort` int NULL DEFAULT NULL COMMENT '模板题目顺序',
  PRIMARY KEY (`tmp_question_id`) USING BTREE,
  INDEX `tmp_id`(`tmp_id`) USING BTREE,
  CONSTRAINT `tmp_question_ibfk_1` FOREIGN KEY (`tmp_id`) REFERENCES `tmp_survey` (`tmp_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 1790392795358314510 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '模板问卷问题表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tmp_survey
-- ----------------------------
DROP TABLE IF EXISTS `tmp_survey`;
CREATE TABLE `tmp_survey`  (
  `tmp_id` bigint NOT NULL COMMENT '问卷模板id',
  `user_id` bigint NULL DEFAULT NULL COMMENT '用户id',
  `tmp_survey_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '问卷模板标题',
  `tmp_survey_desc` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '问卷模板描述',
  `tmp_survey_status` int NULL DEFAULT NULL COMMENT '问卷模板状态（0：未设计，1：已设计）',
  `tmp_survey_tip` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '问卷模板结束语',
  `create_time` datetime NULL DEFAULT NULL COMMENT '问卷模板创建时间',
  `update_time` datetime NULL DEFAULT NULL COMMENT '问卷模板修改时间',
  PRIMARY KEY (`tmp_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '模板问卷表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for type
-- ----------------------------
DROP TABLE IF EXISTS `type`;
CREATE TABLE `type`  (
  `type_id` int NOT NULL AUTO_INCREMENT COMMENT '问卷问题类型',
  `type_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '问卷问题类型名',
  `type_value` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '问卷问题属性',
  PRIMARY KEY (`type_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `user_id` bigint NOT NULL AUTO_INCREMENT COMMENT '用户id',
  `user_name` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '用户名',
  `user_password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '用户密码(加密存储)',
  `user_email` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '用户邮箱',
  `user_nickname` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '用户昵称',
  `user_avatar_path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '用户头像路径',
  `user_balance` decimal(10, 2) NULL DEFAULT NULL COMMENT '用户余额',
  `user_role_id` int NOT NULL COMMENT '用户角色id',
  `user_is_valid` int NOT NULL COMMENT '用户账户是否可用(0不可用，1可用)',
  `create_time` datetime NULL DEFAULT NULL COMMENT '用户创建时间',
  `update_time` datetime NULL DEFAULT NULL COMMENT '用户信息更新时间',
  PRIMARY KEY (`user_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '调查问卷系统用户表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for user_order
-- ----------------------------
DROP TABLE IF EXISTS `user_order`;
CREATE TABLE `user_order`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `order_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '订单id',
  `order_balance` decimal(10, 2) NOT NULL COMMENT '订单金额',
  `user_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '用户名',
  `create_time` datetime NOT NULL COMMENT '订单创建时间',
  `order_text` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '订单备注',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '订单表' ROW_FORMAT = Dynamic;

SET FOREIGN_KEY_CHECKS = 1;
