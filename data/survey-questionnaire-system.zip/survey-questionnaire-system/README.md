# 调查问卷系统（后端）

#### 介绍
毕业设计：基于springboot的调查问卷管理系统

#### 软件架构
B/S架构、前后端分离

### 技术栈（后端）
- **Spring Boot**：构建高效、可维护的Web应用。  
- **MyBatis-Plus**：简化MyBatis操作，提高开发效率。  
- **Redis**：作为缓存层，提高系统响应速度，并用于存储会话数据等。  
- **JWT (JSON Web Token)**：用于生成token，实现用户认证与授权。  
- **Mail Service**（Spring Mail）：用于发送验证邮件、通知邮件等。  
- **MySQL**：作为持久化存储层。  
- **EasyExcel**：生成Excel文件，实现问卷结果的导出。  
- **alipay-easysdk**：集成支付宝SDK，支持支付宝沙箱环境模拟支付。

### 技术栈（前端）
- **Vue 2.x**：构建用户界面的渐进式JavaScript框架。  
- **Element-UI**：基于Vue 2.x的组件库，提供丰富的UI组件。  
- **Axios**：用于发送HTTP请求，与后端API进行交互。
- **ECharts**：使用ECharts库来展示问卷结果的图表。

前端地址：[调查问卷系统前端](https://gitee.com/maozhai133/survey-questionnaire-Web)

## 主要功能
- **问卷管理**：支持问卷的创建、编辑、发布和删除。
- **结果分析**：提供问卷结果的统计分析功能，并使用ECharts展示图表。  
- **Excel导出**：使用EasyExcel生成Excel文件，导出问卷结果。  
- **支付功能**：集成支付宝SDK，支持支付宝沙箱环境模拟支付。
- **个人中心**：个人基本信息修改，包括密码、邮箱、头像等。

## 启动相关事项
- 后端application.yml文件：配置邮件服务，本项目采用QQ邮箱进行的邮件通知转发，也可使用其他邮箱，申请相关的邮件配置POP3/SMTP即可。
- 后端application.properties 配置个人文件上传目录（临时文件目录和上传目录都需要配置，注意目录结构，Linux与Windows结构上有差异），默认头像一定要放在image/avatar/default/目录下，文件名默认defaultAvatar.jpg（与配置文件中的默认头像文件名一致即可）；支付宝的相关配置搜索Springboot集成支付宝沙箱支付相关博客文章进行参考配置即可。
- 将项目的后端配置配置完成后，后端和前端项目启动后，地址栏输入地址:端口号，进入主页，在主页点击“成为发布者”，跳转到登录页面自行注册一个管理员账号，在数据库的user表将注册的账号的user_role_id的字段修改为1即可。其他数据可自行添加，问卷内容设计可以参考[蜂鸟问卷](https://www.fnwenjuan.cn/Home/Templates?cId=0)这里面的内容模拟填充。


## 项目部分演示图
![输入图片说明](READMEImage/%E9%97%AE%E5%8D%B7%E5%89%8D%E5%8F%B0%E9%A6%96%E9%A1%B5.png)
![输入图片说明](READMEImage/%E9%97%AE%E5%8D%B7%E5%9B%9E%E7%AD%94%E9%A1%B5%E9%9D%A2.png)
![输入图片说明](READMEImage/%E7%99%BB%E5%BD%95.png)
![输入图片说明](READMEImage/%E6%B3%A8%E5%86%8C.png)
![输入图片说明](READMEImage/%E5%90%8E%E5%8F%B0%E9%A6%96%E9%A1%B5.png)
![输入图片说明](READMEImage/%E9%97%AE%E5%8D%B7%E7%AE%A1%E7%90%86.png)
![输入图片说明](READMEImage/%E6%A8%A1%E6%9D%BF%E5%88%9B%E5%BB%BA%E9%97%AE%E5%8D%B7.png)
![输入图片说明](READMEImage/%E9%97%AE%E5%8D%B7%E8%AE%BE%E8%AE%A1.png)
![输入图片说明](READMEImage/%E9%97%AE%E5%8D%B7%E5%88%86%E6%9E%901.png)
![输入图片说明](READMEImage/%E9%97%AE%E5%8D%B7%E5%88%86%E6%9E%902.png)
![输入图片说明](READMEImage/%E9%97%AE%E5%8D%B7%E5%88%86%E6%9E%903.png)
![输入图片说明](READMEImage/%E6%94%AF%E4%BB%98%E5%AE%9D%E6%B2%99%E7%AE%B1%E6%94%AF%E4%BB%98.png)
