package com.nekotaku.questionnairesystem.service;

import com.nekotaku.questionnairesystem.entity.Role;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 用户角色表 服务类
 * </p>
 *
 * @author nekotaku
 * @since 2023-12-10
 */
public interface RoleService extends IService<Role> {

}
