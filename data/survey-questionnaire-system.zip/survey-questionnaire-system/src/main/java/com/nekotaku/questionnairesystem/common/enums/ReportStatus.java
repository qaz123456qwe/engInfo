package com.nekotaku.questionnairesystem.common.enums;


/**
 * 举报的状态
 *
 * @Title:ReportStatus
 * @Author:NekoTaku
 * @Date:2024/04/01 10:26
 * @Version:1.0
 */
public enum ReportStatus {

    TO_BE_REVIEWED(0,"待审核"),

    AUDITED(1,"已审核"),

    RESTATE_PENDING_REVIEW(2,"重申待审核");


    private final int statusId;
    private final String statusName;

    ReportStatus(int statusId, String statusName) {
        this.statusId = statusId;
        this.statusName = statusName;
    }

    public int getStatusId() {
        return statusId;
    }

    public String getStatusName() {
        return statusName;
    }

    public static ReportStatus getByStatusId(int statusId) {
        for (ReportStatus reportStatus : values()) {
            if (reportStatus.getStatusId() == statusId) {
                return reportStatus;
            }
        }
        throw new IllegalArgumentException("无效状态id: " + statusId);
    }
}
