package com.nekotaku.questionnairesystem.vo.excel.dto;

import com.alibaba.excel.metadata.BaseRowModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 带选择题的答案的导出ExcelDto类
 *
 *
 * @Title:Base
 * @Author:NekoTaku
 * @Date:2024/03/30 17:36
 * @Version:1.0
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ExportDataBase extends BaseRowModel {

    private String questionContent;

    private String answerContent;


}
