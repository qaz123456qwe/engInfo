package com.nekotaku.questionnairesystem.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.nekotaku.questionnairesystem.common.page.QueryPageParam;
import com.nekotaku.questionnairesystem.entity.report.ReportArticle;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  文章举报表 服务类
 * </p>
 *
 * @author nekotaku
 * @since 2024-04-01
 */
public interface ReportArticleService extends IService<ReportArticle> {

    Integer saveOrUpdateArticleReport(ReportArticle reportArticle,Boolean isAdmin);

    Page<ReportArticle> listReportArticle(QueryPageParam queryPageParam);

    Integer appealArticle(Long userId, Long articleId);

    Integer delReportArticle(Long articleId);
}
