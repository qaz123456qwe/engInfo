package com.nekotaku.questionnairesystem.common.enums;

/**
 * 导航图状态枚举类
 *
 * @Title:NaviImageStatus
 * @Author:NekoTaku
 * @Date:2024/05/12 2:39
 * @Version:1.0
 */
public enum NaviImageStatus {

    OPEN(1, "已启用"),
    PRIVATE(0, "未启用");

    private final int statusId;
    private final String statusName;

    NaviImageStatus(int statusId, String statusName) {
        this.statusId = statusId;
        this.statusName = statusName;
    }

    public int getStatusId() {
        return statusId;
    }

    public String getStatusName() {
        return statusName;
    }

    public static NaviImageStatus getByStatusId(int statusId) {
        for (NaviImageStatus naviImageStatus : values()) {
            if (naviImageStatus.getStatusId() == statusId) {
                return naviImageStatus;
            }
        }
        throw new IllegalArgumentException("无效状态id: " + statusId);
    }
}
