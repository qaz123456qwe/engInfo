package com.nekotaku.questionnairesystem.controller;


import cn.hutool.core.util.ObjUtil;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.nekotaku.questionnairesystem.common.R.ResponseCode;
import com.nekotaku.questionnairesystem.common.R.Result;
import com.nekotaku.questionnairesystem.common.constants.redis.RedisConstants;
import com.nekotaku.questionnairesystem.common.enums.SurveyStatus;
import com.nekotaku.questionnairesystem.common.page.QueryPageParam;
import com.nekotaku.questionnairesystem.vo.AnswerVo;
import com.nekotaku.questionnairesystem.vo.analysis.TextQuestionAnalysisVo;
import com.nekotaku.questionnairesystem.entity.Survey;
import com.nekotaku.questionnairesystem.entity.SurveyFinishLog;
import com.nekotaku.questionnairesystem.service.AnswerService;
import com.nekotaku.questionnairesystem.service.SurveyFinishLogService;
import com.nekotaku.questionnairesystem.service.SurveyService;
import com.nekotaku.questionnairesystem.utils.IpUtil;
import com.nekotaku.questionnairesystem.utils.TokenUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.math.BigDecimal;
import java.util.HashMap;

/**
 * <p>
 * 问卷结果表	 前端控制器
 * </p>
 *
 * @author nekotaku
 * @since 2024-02-20
 */
@RestController
@RequestMapping("/answer")
@Slf4j
public class AnswerController {

    @Autowired
    private AnswerService answerService;

    @Autowired
    private SurveyService surveyService;

    @Autowired
    private SurveyFinishLogService surveyFinishLogService;

    @Autowired
    private TokenUtil tokenUtil;

    @Autowired
    @Qualifier("integerRedisTemplate")
    private RedisTemplate<String,Integer> listRedisTemplate;

    /**
     * 保存答案
     *
     * @param answerVo
     * @return
     */
    @PostMapping("/submit")
    public Result submitQuestionnaire(@RequestBody AnswerVo answerVo, HttpServletRequest request) {

        String ipAddress = IpUtil.getIpAddress(request);

        log.info("ip地址:{}", ipAddress);

        Survey surveyById = surveyService.getSurveyById(answerVo.getSurveyId());

        if (ObjUtil.isNull(surveyById)) {
            return Result.fail(ResponseCode.FAIL.val(), "问卷不存在或已完成，感谢你的参与");
        }

        // 获取问卷查看状态(发布中的问卷才可以回答,并且数量要小于限制数量)
        if (surveyById.getSurveyStatus() == SurveyStatus.PUBLISHED.getStatusId()
                && surveyById.getSurveyCollected() <= surveyById.getSurveyCollectedLimit()) {

            // 检测问卷是否结束(达到结束时间)
            boolean isEnd = surveyService.checkSurveyIsEnd(surveyService.getSurveyById(answerVo.getSurveyId()));
            if (isEnd) {
                return Result.fail(ResponseCode.SURVEY_END.val(),
                        ResponseCode.SURVEY_END.msg());
            }

            // 处理问卷结果
            Integer res = surveyService.updateSurveyCollected(surveyById);

            if (res == ResponseCode.SUCCESS.val()) {

                // 日志表更新
                SurveyFinishLog surveyFinishLog = new SurveyFinishLog();
                surveyFinishLog.setSurveyId(surveyById.getSurveyId());
                surveyFinishLog.setUserId(tokenUtil.getUserIdFromToken(request));

                surveyFinishLogService.save(surveyFinishLog);

                // 日志实体类设置了@TableId(type = IdType.AUTO)，可以直接获取新增的日志id
                Long logId = surveyFinishLog.getId();

                // 成功，更新答案表
                res = answerService.saveAnswer(answerVo, logId);

                // 判断是否有红包
                if(surveyById.getSurveyBalance().compareTo(BigDecimal.ZERO)>0) {
                    // 返回给前端的数据，问卷基本数据，红包金额
                    HashMap<String, Object> map = new HashMap<>();
                    Survey survey = new Survey();
                    // 数据脱敏(过滤一些属性)
                    survey.setSurveyId(surveyById.getSurveyId());
                    survey.setSurveyTitle(surveyById.getSurveyTitle());
                    map.put("survey", survey);
                    // 获取红包金额
                    Integer integer = listRedisTemplate.opsForList().leftPop(RedisConstants.RED_PACKET + surveyById.getSurveyId());
                    BigDecimal amount = BigDecimal.valueOf(integer).divide(BigDecimal.valueOf(100.0));
                    map.put("amount", amount);
                    if (res == ResponseCode.SUCCESS.val()) {
                        return Result.success(ResponseCode.SUCCESS.val(), surveyById.getSurveyTip(), map);
                    }
                }

                if (res == ResponseCode.SUCCESS.val()) {
                    return Result.success(ResponseCode.SUCCESS.val(), surveyById.getSurveyTip());
                }

            }
        }
        // 问卷已经结束
        if (surveyById.getSurveyStatus() == SurveyStatus.COMPLETED.getStatusId()) {
            return Result.fail(ResponseCode.SURVEY_END.val(),
                    ResponseCode.SURVEY_END.msg());
        }

        return Result.fail(ResponseCode.SURVEY_INVALID.val(),
                ResponseCode.SURVEY_INVALID.msg()
                        + SurveyStatus.getByStatusId(surveyById.getSurveyStatus()).getStatusName());
    }

    /**
     * 统计答案表中当前问卷的选择题选择情况
     *
     * @param surveyId
     * @return
     */
//    @GetMapping("/AnalysisAnswerCount/{surveyId}")
//    public Result getAnswerChoiceCount(@PathVariable("surveyId") Long surveyId) {
//        List<AnswerChoiceAnalysisVo> countList = answerService.getAnswerCountBySurveyId(surveyId);
//
//        if (countList.size() == 0) {
//            return Result.fail(ResponseCode.FAIL.val(), ResponseCode.FAIL.msg());
//        }
//
//        return Result.success(countList);
//    }

    /**
     * 获取客观题的回答列表详细
     *
     * @param surveyId
     * @return
     */
    @PostMapping("/TextAnswerAnalysis/{surveyId}")
    public Result getTextAnswerContextList(@PathVariable("surveyId") Long surveyId,
                                           @RequestBody QueryPageParam queryPageParam) {

        Page<TextQuestionAnalysisVo> textAnswerContextList =
                answerService.getTextAnswerContextList(surveyId, queryPageParam);
        return Result.success(ResponseCode.SUCCESS.val(), ResponseCode.SUCCESS.msg(),
                textAnswerContextList.getRecords(),textAnswerContextList.getTotal());
    }

}
