package com.nekotaku.questionnairesystem.utils;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.UUID;

/**
 * 订单生成器
 *
 * @Title:OrderIdGenerator
 * @Author:NekoTaku
 * @Date:2024/05/12 16:53
 * @Version:1.0
 */
public class OrderIdGenerator {

    private static final String SEPARATOR = "-";
    private static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyyMMddHHmmssSSS");

    /**
     * 生成订单ID
     *
     * @param userId    用户ID（Long类型，但长度可能超出Long范围，这里作为字符串处理）
     * @param payment   支付金额（double类型）
     * @return 生成的订单ID
     * @throws NoSuchAlgorithmException 如果找不到MD5算法
     */
    public static String generateOrderId(String userId, double payment) throws NoSuchAlgorithmException {
        // 获取当前时间的字符串表示
        String currentTime = LocalDateTime.now().format(DATE_TIME_FORMATTER);

        // 格式化支付金额，取整数部分或固定精度的小数部分（这里取整数部分）
        String formattedPayment = String.valueOf((long) payment);

        // 将所有信息拼接起来
        String combined = userId + SEPARATOR + formattedPayment + SEPARATOR + currentTime;

        // 使用MD5算法对拼接后的字符串进行哈希，以确保唯一性并缩短长度
        MessageDigest md = MessageDigest.getInstance("MD5");
        byte[] hashBytes = md.digest(combined.getBytes(StandardCharsets.UTF_8));
        StringBuilder hexString = new StringBuilder();
        for (byte b : hashBytes) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) hexString.append('0');
            hexString.append(hex);
        }

        // 使用UUID作为前缀或后缀，以确保全局唯一性（这里作为前缀）
        UUID uuid = UUID.randomUUID();
        String uuidString = uuid.toString().replace("-", ""); // 移除UUID中的短横线

        // 返回生成的订单ID，由UUID和MD5哈希值组成
        return uuidString + SEPARATOR + hexString.toString();
    }
}
