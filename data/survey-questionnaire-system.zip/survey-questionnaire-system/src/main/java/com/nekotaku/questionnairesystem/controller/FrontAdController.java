package com.nekotaku.questionnairesystem.controller;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.nekotaku.questionnairesystem.common.R.ResponseCode;
import com.nekotaku.questionnairesystem.common.R.ResponseConstants;
import com.nekotaku.questionnairesystem.common.R.Result;
import com.nekotaku.questionnairesystem.common.page.QueryPageParam;
import com.nekotaku.questionnairesystem.entity.FrontAd;
import com.nekotaku.questionnairesystem.service.FrontAdService;
import com.nekotaku.questionnairesystem.utils.TokenUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.constraints.NotBlank;
import java.util.List;

/**
 * <p>
 * 导航图 前端控制器
 * </p>
 *
 * @author nekotaku
 * @since 2024-05-12
 */
@RestController
@RequestMapping("/front-ad")
public class FrontAdController {

    @Autowired
    private TokenUtil tokenUtil;

    @Autowired
    private FrontAdService frontAdService;

    /**
     * 新增或更新导航栏基本信息
     *
     * @param frontAd
     * @param request
     * @return
     */
    @PostMapping("/saveOrUpdateAdInfo")
    public Result saveOrUpdateAdInfo(@RequestBody FrontAd frontAd,
                                     HttpServletRequest request) {
        boolean isAdmin = tokenUtil.checkIsAdmin(request);

        // 非管理员拒绝请求
        if (!isAdmin) {
            return Result.fail(ResponseCode.FORBIDDEN.val(), ResponseCode.FORBIDDEN.msg());
        }

        Integer res = frontAdService.saveOrUpdateAdInfo(frontAd, tokenUtil.getUserIdFromToken(request));

        if (res != ResponseCode.SUCCESS.val()) {
            return Result.fail(res, ResponseCode.getMsgByVal(res));
        }

        return Result.success(ResponseCode.SUCCESS.val(), "保存导航图成功！");
    }

    /**
     * 分页查询导航图信息列表(可带条件查询)
     *
     * @param queryPageParam
     * @param request
     * @return
     */
    @PostMapping("/listAdInfo")
    public Result listAdInfo(@RequestBody QueryPageParam queryPageParam,
                             HttpServletRequest request) {
        // 判断是否为管理员操作
        boolean isAdminUser = tokenUtil.checkIsAdmin(request);
        if (!isAdminUser) {
            // 非管理员用户拒绝访问
            return Result.fail(ResponseCode.FORBIDDEN.val(),
                    ResponseCode.FORBIDDEN.msg());
        }
        // 分页查询
        Page<FrontAd> res = frontAdService.listFrontAdList(queryPageParam);

        return Result.success(ResponseCode.SUCCESS.val(), ResponseCode.SUCCESS.msg(),
                res.getRecords(), res.getTotal());
    }

    /**
     * 获取所有已经启用的导航图
     *
     * @return
     */
    @GetMapping("/getOpenNaviImage")
    public Result getOpenNaviImage() {
        List<FrontAd> res = frontAdService.getOpenNaviImage();
        return Result.success(res);
    }

    /**
     * 开启导航图
     *
     * @param frontAd
     * @param request
     * @return
     */
    @PutMapping("/openNaviImage")
    public Result openNaviImage(@RequestBody FrontAd frontAd,
                                HttpServletRequest request) {
        // 判断是否为管理员操作
        boolean isAdminUser = tokenUtil.checkIsAdmin(request);
        if (!isAdminUser) {
            // 非管理员用户拒绝访问
            return Result.fail(ResponseCode.FORBIDDEN.val(),
                    ResponseCode.FORBIDDEN.msg());
        }

        Integer res = frontAdService.openNaviImage(frontAd);

        if (res != ResponseCode.SUCCESS.val()) {
            return Result.fail(res, ResponseCode.getMsgByVal(res));
        }

        return Result.success(ResponseCode.SUCCESS.val(), "开启导航图成功");
    }

    /**
     * 删除导航图
     *
     * @param adId
     * @return
     */
    @DeleteMapping("/deleteAd/{adId}")
    public Result deleteAd(@NotBlank(message = ResponseConstants.INVALID_RESPONSE_CODE)
                           @PathVariable("adId") String adId,HttpServletRequest request){

        // 判断是否为管理员操作
        boolean isAdminUser = tokenUtil.checkIsAdmin(request);
        if (!isAdminUser) {
            // 非管理员用户拒绝访问
            return Result.fail(ResponseCode.FORBIDDEN.val(),
                    ResponseCode.FORBIDDEN.msg());
        }

        Integer res = frontAdService.deleteAdInfo(adId);
        if (!res.equals(ResponseCode.SUCCESS.val())) {
            return Result.fail(ResponseCode.FAIL.val(), "删除导航图失败");
        }
        return Result.success(ResponseCode.SUCCESS.val(), "删除导航图成功");
    }
}
