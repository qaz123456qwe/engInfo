package com.nekotaku.questionnairesystem.controller;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.nekotaku.questionnairesystem.common.R.ResponseCode;
import com.nekotaku.questionnairesystem.common.R.Result;
import com.nekotaku.questionnairesystem.common.page.QueryPageParam;
import com.nekotaku.questionnairesystem.entity.UserOrder;
import com.nekotaku.questionnairesystem.service.UserOrderService;
import com.nekotaku.questionnairesystem.utils.TokenUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

/**
 * <p>
 * 订单表 前端控制器
 * </p>
 *
 * @author nekotaku
 * @since 2024-05-12
 */
@RestController
@RequestMapping("/user-order")
public class UserOrderController {


    @Autowired
    private UserOrderService userOrderService;

    @Autowired
    private TokenUtil tokenUtil;

    /**
     * 分页查询用户充值订单
     *
     * @param queryPageParam
     * @param request
     * @return
     */
    @PostMapping("/listOrders")
    public Result listOrder(@RequestBody QueryPageParam queryPageParam,
                            HttpServletRequest request) {

        // 判断是否为管理员操作
        boolean isAdminUser = tokenUtil.checkIsAdmin(request);
        if (!isAdminUser) {
            // 非管理员用户拒绝访问
            return Result.fail(ResponseCode.FORBIDDEN.val(),
                    ResponseCode.FORBIDDEN.msg());
        }

        Page<UserOrder> res = userOrderService.listOrders(queryPageParam);

        return Result.success(ResponseCode.SUCCESS.val(), ResponseCode.SUCCESS.msg(),
                res.getRecords(), res.getTotal());

    }


}
