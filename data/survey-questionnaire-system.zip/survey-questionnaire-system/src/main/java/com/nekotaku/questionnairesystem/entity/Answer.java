package com.nekotaku.questionnairesystem.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import java.time.LocalDateTime;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 问卷结果表	
 * </p>
 *
 * @author nekotaku
 * @since 2024-02-20
 */
@Data
@EqualsAndHashCode(callSuper = false)
@ApiModel(value="Answer对象", description="问卷结果表")
public class Answer implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "答案id")
    @TableId(value = "answer_id", type = IdType.AUTO)
    private Long answerId;

    @ApiModelProperty(value = "问卷id")
    private Long surveyId;

    @ApiModelProperty(value = "问题id")
    private Long questionId;

    @ApiModelProperty(value = "输入的内容")
    private String answerContext;

    @ApiModelProperty(value = "选择题选项id")
    private Long optionId;

    @ApiModelProperty(value = "回答完成时间")
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    @ApiModelProperty(value = "问题类型(非数据库属性，用于业务逻辑)")
    private transient String type;

    @ApiModelProperty(value = "问卷完成日志id")
    private Long surveyFinishLogId;


}
