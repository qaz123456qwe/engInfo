package com.nekotaku.questionnairesystem.mapper;

import com.nekotaku.questionnairesystem.entity.TmpOption;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.web.bind.annotation.PatchMapping;

import java.util.List;

/**
 * <p>
 * 模板选项表 Mapper 接口
 * </p>
 *
 * @author nekotaku
 * @since 2024-03-04
 */
@Mapper
public interface TmpOptionMapper extends BaseMapper<TmpOption> {

    List<TmpOption> selectTmpListByQuestionId(@Param("tmpQuestionId")Long tmpQuestionId);
}
