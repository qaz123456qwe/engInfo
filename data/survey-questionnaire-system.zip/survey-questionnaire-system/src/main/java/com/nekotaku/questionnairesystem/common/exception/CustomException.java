package com.nekotaku.questionnairesystem.common.exception;

/**
 * 自定义业务异常
 *
 * @Title:TokenAuthExpiredException
 * @Author:NekoTaku
 * @Date:2023/12/03 15:14
 * @Version:1.0
 */
public class CustomException extends RuntimeException {

    public CustomException(String message) {
        super(message);
    }
}
