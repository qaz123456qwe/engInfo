package com.nekotaku.questionnairesystem.common.enums;

/**
 * 举报的结果
 *
 * @Title:ReportStatus
 * @Author:NekoTaku
 * @Date:2024/04/01 13:46
 * @Version:1.0
 */
public enum ReportResult {

    PASS(1, "正常"),
    BAN(2, "封禁"),
    NO_DISPOSE(0, "待处置");

    private final int statusId;
    private final String statusName;

    ReportResult(int statusId, String statusName) {
        this.statusId = statusId;
        this.statusName = statusName;
    }

    public int getStatusId() {
        return statusId;
    }

    public String getStatusName() {
        return statusName;
    }

    public static ReportResult getByStatusId(int statusId) {
        for (ReportResult reportResult : values()) {
            if (reportResult.getStatusId() == statusId) {
                return reportResult;
            }
        }
        throw new IllegalArgumentException("无效状态id: " + statusId);
    }
}
