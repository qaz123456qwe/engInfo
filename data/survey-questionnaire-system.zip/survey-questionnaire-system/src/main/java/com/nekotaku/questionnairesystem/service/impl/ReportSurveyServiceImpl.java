package com.nekotaku.questionnairesystem.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.OrderItem;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.nekotaku.questionnairesystem.common.R.ResponseCode;
import com.nekotaku.questionnairesystem.common.enums.ReportResult;
import com.nekotaku.questionnairesystem.common.enums.ReportStatus;
import com.nekotaku.questionnairesystem.common.enums.SurveyStatus;
import com.nekotaku.questionnairesystem.common.page.QueryPageParam;
import com.nekotaku.questionnairesystem.entity.Survey;
import com.nekotaku.questionnairesystem.entity.User;
import com.nekotaku.questionnairesystem.entity.report.ReportArticle;
import com.nekotaku.questionnairesystem.entity.report.ReportSurvey;
import com.nekotaku.questionnairesystem.mapper.ReportSurveyMapper;
import com.nekotaku.questionnairesystem.service.AnswerService;
import com.nekotaku.questionnairesystem.service.ReportSurveyService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.nekotaku.questionnairesystem.service.SurveyFinishLogService;
import com.nekotaku.questionnairesystem.service.SurveyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Arrays;
import java.util.HashMap;

/**
 * <p>
 * 问卷举报信息表 服务实现类
 * </p>
 *
 * @author nekotaku
 * @since 2024-04-05
 */
@Service
public class ReportSurveyServiceImpl extends ServiceImpl<ReportSurveyMapper, ReportSurvey> implements ReportSurveyService {

    @Autowired
    private ReportSurveyMapper reportSurveyMapper;

    @Autowired
    private UserServiceImpl userService;

    @Autowired
    private SurveyService surveyService;

    @Autowired
    private SurveyFinishLogService surveyFinishLogService;

    @Autowired
    private AnswerService answerService;

    /**
     * 新增或者审核问卷信息
     *
     * @param reportSurvey
     * @param isAdmin
     * @return
     */
    @Override
    @Transactional
    public synchronized Integer saveOrUpdateArticleReport(ReportSurvey reportSurvey, boolean isAdmin) {

        // 是否是管理员审核操作,如果是审核操作，执行审核方法
        if (isAdmin && BeanUtil.isNotEmpty(reportSurvey.getReportId())) {
            // 执行管理员审核操作
            return this.approvalSurvey(reportSurvey);
        }

        // 判断问卷是否被删除,是否被封禁
        Survey surveyById = surveyService.getSurveyById(reportSurvey.getReportSurveyId());
        if (BeanUtil.isEmpty(surveyById)
                || surveyById.getSurveyStatus().equals(SurveyStatus.SURVEY_BAN.getStatusId())) {
            return ResponseCode.SURVEY_IS_BAN_OR_DEL.val();
        }

        // 设置用户名
        reportSurvey.setUserName(userService.getById(surveyById.getUserId()).getUserName());

        LambdaQueryWrapper<ReportSurvey> qw = new LambdaQueryWrapper<>();

        // 如果已经被举报 找到问卷举报信息
        ReportSurvey reportInfo = reportSurveyMapper.selectOne(
                qw.eq(ReportSurvey::getReportSurveyId, reportSurvey.getReportSurveyId())
        );

        // 判断问卷是否已经审核通过了
        if (BeanUtil.isNotEmpty(reportInfo)
                && reportInfo.getReportResult() == ReportResult.PASS.getStatusId()) {
            // 不做操作
            return ResponseCode.SUCCESS.val();
        }

        // 举报问卷信息存在，且还没有审核，增加举报次数，拼接举报理由
        if (BeanUtil.isNotEmpty(reportInfo)
                && reportInfo.getReportStatus() == ReportStatus.TO_BE_REVIEWED.getStatusId()) {
            String reportReason = reportSurvey.getReportReason();
            // 如果理由不为空才进行拼接
            if (StrUtil.isNotBlank(reportReason) || !reportReason.equals("")) {
                reportInfo.setReportReason(reportInfo.getReportReason() + "," + reportReason);
            }
            // 更新举报次数
            reportInfo.setReportCount(reportInfo.getReportCount() + 1);
            this.saveOrUpdate(reportInfo);
            return ResponseCode.SUCCESS.val();
        }

        // 第一次举报信息增加
        this.saveOrUpdate(reportSurvey);
        return ResponseCode.SUCCESS.val();
    }

    /**
     * 分页查询问卷举报信息列表
     *
     * @param queryPageParam
     * @return
     */
    @Override
    public Page<ReportSurvey> listReportSurvey(QueryPageParam queryPageParam) {
        Page<ReportSurvey> reportSurveyPage = new Page<>();

        // 设置当前页
        reportSurveyPage.setCurrent(queryPageParam.getPageNum());

        // 设置当前页面数量
        reportSurveyPage.setSize(queryPageParam.getPageSize());

        // 按照最新数据查询(按照update_time字段)
        reportSurveyPage.setOrders(Arrays.asList(OrderItem.desc("update_time")));

        // 获取查询条件
        HashMap param = queryPageParam.getParam();
        String status = param.get("status").toString();
        String result = param.get("result").toString();
        String surveyName = param.get("surveyName").toString();

        LambdaQueryWrapper<ReportSurvey> qw = new LambdaQueryWrapper<>();
        // 进度
        if (StringUtils.isNotBlank(status) && !"null".equals(status)) {
            qw.eq(ReportSurvey::getReportStatus, Integer.parseInt(status));
        }
        // 结果
        if (StringUtils.isNotBlank(result) && !"null".equals(result)) {
            qw.eq(ReportSurvey::getReportResult, Integer.parseInt(result));
        }
        // 标题
        if (StringUtils.isNotBlank(surveyName) && !"null".equals(surveyName)) {
            qw.like(ReportSurvey::getReportSurveyTitle, surveyName);
        }
        return this.page(reportSurveyPage, qw);
    }

    /**
     * 问卷申述
     *
     * @param userId
     * @param surveyId
     * @return
     */
    @Override
    public Integer appealSurvey(Long userId, Long surveyId) {

        // 是否有这条封禁问卷信息
        LambdaQueryWrapper<ReportSurvey> qw = new LambdaQueryWrapper<>();
        qw.eq(ReportSurvey::getReportSurveyId, surveyId);
        qw.eq(ReportSurvey::getReportResult, ReportResult.BAN.getStatusId());
        ReportSurvey reportSurvey = reportSurveyMapper.selectOne(qw);

        // 问卷不需要申述的情况(没有举报信息，举报处置结果为通过或者待审核)
        if (BeanUtil.isEmpty(reportSurvey)
                || reportSurvey.getReportResult() == ReportResult.PASS.getStatusId()
                || reportSurvey.getReportResult() == ReportResult.NO_DISPOSE.getStatusId()) {
            return ResponseCode.SURVEY_NOT_REPORT.val();
        }

        // 比较用户(只有本用户才能申请申述)
        User byId = userService.getById(userId);
        if (!byId.getUserName().equals(reportSurvey.getUserName())) {
            // 请求拒绝
            return ResponseCode.FORBIDDEN.val();
        }

        // 处理问卷的状态
        Integer res = surveyService.setReportResult(surveyId, ReportResult.NO_DISPOSE.getStatusId(),
                byId.getUserEmail(), reportSurvey.getReportStatus());

        // 处理举报信息
        reportSurvey.setReportStatus(ReportStatus.RESTATE_PENDING_REVIEW.getStatusId());

        // 更新
        if (!res.equals(ResponseCode.SUCCESS.val())) {
            return res;
        }
        saveOrUpdate(reportSurvey);

        return res;
    }

    /**
     * 删除举报信息
     *
     * @param surveyId
     * @return
     */
    @Override
    public Integer delReportSurvey(Long surveyId) {
        // 获取问卷
        Survey surveyById = surveyService.getSurveyById(surveyId);

        // 获取举报信息
        ReportSurvey reportSurvey = reportSurveyMapper.selectOne(new LambdaQueryWrapper<ReportSurvey>()
                .eq(ReportSurvey::getReportSurveyId, surveyId));

        // 判断举报信息状态(如果问卷通过审核并且处置结果为正常通过才可删除)
        if (reportSurvey.getReportStatus() == ReportStatus.AUDITED.getStatusId()
                && reportSurvey.getReportResult() == ReportResult.PASS.getStatusId()
                && BeanUtil.isNotEmpty(reportSurvey)) {
            // 删除举报信息
            int res = reportSurveyMapper.deleteById(reportSurvey.getReportId());
            return res > 0 ? ResponseCode.SUCCESS.val() : ResponseCode.FAIL.val();
        }

        // 如果问卷已经被删除,则直接删除
        if (!BeanUtil.isNotEmpty(surveyById)) {
            int res = reportSurveyMapper.deleteById(reportSurvey.getReportId());
            return res > 0 ? ResponseCode.SUCCESS.val() : ResponseCode.FAIL.val();
        }

        return ResponseCode.REPORT_ARTICLE_DEL_FAIL.val();
    }

    /**
     * 问卷审批
     *
     * @return
     */
    @Transactional
    public Integer approvalSurvey(ReportSurvey reportSurvey) {
        // 邮箱获取
        String userEmail = userService.getOne(new LambdaQueryWrapper<User>()
                .eq(User::getUserName, reportSurvey.getUserName())).getUserEmail();

        // 处理问卷状态
        Integer res = surveyService.setReportResult(reportSurvey.getReportSurveyId()
                , reportSurvey.getReportResult(), userEmail, reportSurvey.getReportStatus());

        if (res == ResponseCode.SUCCESS.val()) {

            if (reportSurvey.getReportResult() == ReportResult.BAN.getStatusId()) {
                // 删除answer和surveyFinishLog表中对应的数据
                answerService.deleteBySurveyId(reportSurvey.getReportSurveyId());
                surveyFinishLogService.deleteBySurveyId(reportSurvey.getReportSurveyId());
            }

            // 更新举报信息状态(变为已审核)
            reportSurvey.setReportStatus(ReportStatus.AUDITED.getStatusId());
            this.saveOrUpdate(reportSurvey);
        }


        return res;
    }
}
