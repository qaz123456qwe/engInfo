package com.nekotaku.questionnairesystem.controller;


import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.ObjUtil;
import cn.hutool.core.util.ObjectUtil;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.nekotaku.questionnairesystem.common.R.ResponseCode;
import com.nekotaku.questionnairesystem.common.R.ResponseConstants;
import com.nekotaku.questionnairesystem.common.R.Result;
import com.nekotaku.questionnairesystem.common.enums.SurveyStatus;
import com.nekotaku.questionnairesystem.common.page.QueryPageParam;
import com.nekotaku.questionnairesystem.vo.QuestionVo;
import com.nekotaku.questionnairesystem.vo.SurveyAndQuestionVo;
import com.nekotaku.questionnairesystem.vo.SurveyCountDataVo;
import com.nekotaku.questionnairesystem.vo.SurveyMonthlyCountVo;
import com.nekotaku.questionnairesystem.vo.analysis.AnswerChoiceAnalysisVo;
import com.nekotaku.questionnairesystem.vo.analysis.SurveyAnalysisVo;
import com.nekotaku.questionnairesystem.entity.Survey;
import com.nekotaku.questionnairesystem.service.*;
import com.nekotaku.questionnairesystem.utils.TokenUtil;
import com.nekotaku.questionnairesystem.vo.front.SurveyFrontVo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.constraints.NotBlank;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;

/**
 * <p>
 * 调查问卷表（主要是问卷的基本信息） 前端控制器
 * </p>
 *
 * @author nekotaku
 * @since 2023-12-13
 */
@RestController
@RequestMapping("/survey")
@Slf4j
public class SurveyController {

    @Autowired
    private SurveyService surveyService;

    @Autowired
    private SurveyFinishLogService surveyFinishLogService;

    @Autowired
    private TokenUtil tokenUtil;

    @Autowired
    private QuestionService questionService;

    @Autowired
    private TmpSurveyService tmpSurveyService;

    @Autowired
    private TmpQuestionService tmpQuestionService;

    @Autowired
    private AnswerService answerService;

    /**
     * 新增或修改问卷
     *
     * @param survey
     * @param httpServletRequest
     * @return
     */
    @PostMapping("/saveOrUpdateSurvey")
    public Result saveOrUpdateSurvey(@RequestBody Survey survey,
                                     HttpServletRequest httpServletRequest) {
        // 获取用户id
        Long userId = tokenUtil.getUserIdFromToken(httpServletRequest);
        log.info("添加问卷信息：" + survey.toString());
        survey.setUserId(userId);

        // 调用保存服务
        Integer res = surveyService.saveOrUpdateSurvey(survey);

        if (res != ResponseCode.SUCCESS.val()) {
            return Result.fail(res, ResponseCode.getMsgByVal(res));
        }
        return Result.success(res, "问卷成功");
    }

    /**
     * 分页查询所有问卷信息(可带条件查询)
     *
     * @param queryPageParam
     * @param httpServletRequest
     * @return
     */
    @PostMapping("/listSurveys")
    public Result listSurveys(@RequestBody QueryPageParam queryPageParam
            , HttpServletRequest httpServletRequest) {
        Long userId = tokenUtil.getUserIdFromToken(httpServletRequest);
        Page<Survey> res = surveyService.listSurveys(queryPageParam, userId);
        List<Survey> records = res.getRecords();
        // 检查一下问卷是否有开始的或者结束的
        for (Survey survey : records) {
            surveyService.processSurveyAsync(survey);
        }
        // 获取状态
        String surveyStatus = queryPageParam.getParam().get("surveyStatus").toString();
        // 如果是完成的状态问卷，修改一下问卷完成时间(由于定时器是每五分钟一次，所以不一定是设定的问卷结束时间)
        if (surveyStatus.equals(String.valueOf(SurveyStatus.COMPLETED.getStatusId()))
                && !CollUtil.isEmpty(records)) {
            for (Survey survey : records) {
                // 问卷更新时间，正常情况下，最后完成的时间也等于这个
                LocalDateTime updateTime = survey.getUpdateTime();
                // 问卷设定的结束时间
                LocalDateTime surveyEndTime = survey.getSurveyEndTime();
                // 如果更新时间大于结束时间，即到达结束时间完成的问卷，需要修订一下返回的完成时间
                if (updateTime.isAfter(surveyEndTime)) {
                    survey.setUpdateTime(surveyEndTime);
                }
            }
        }
        return Result.success(ResponseCode.SUCCESS.val(), ResponseCode.SUCCESS.msg(),
                res.getRecords(), res.getTotal());
    }

    /**
     * 分页查询所有问卷信息，前台首页用
     *
     * @param queryPageParam
     * @return
     */
    @PostMapping("/listSurveysForFront")
    public Result listSurveysForFront(@RequestBody QueryPageParam queryPageParam) {

        Page<SurveyFrontVo> res = surveyService.listSurveysForFront(queryPageParam);

        return Result.success(ResponseCode.SUCCESS.val(), ResponseCode.SUCCESS.msg(),
                res.getRecords(), res.getTotal());
    }

    /**
     * 获取问卷数据(包括其问题和选项)
     * 用于查看或者实际做问卷的页面
     *
     * @param surveyId
     * @return
     */
    @GetMapping("/surveyDetailed/{surveyId}")
    public Result getSurvey(@PathVariable("surveyId") Long surveyId) {

        Survey surveyById = surveyService.getSurveyById(surveyId);

        // 判断问卷状态，以此来判断redis缓存中是否存有
        Integer surveyStatus = surveyById.getSurveyStatus();
        if (surveyStatus == SurveyStatus.PUBLISHED.getStatusId()
                || surveyStatus == SurveyStatus.PAUSED.getStatusId()
                || surveyStatus == SurveyStatus.UN_STARTED.getStatusId()) {
            // 检查问卷是否已经结束(达到设定的结束时间),防止定时器没有检查到
            boolean isEnd = surveyService.checkSurveyIsEnd(surveyById);
            if (isEnd) {
                SurveyAndQuestionVo survey = surveyService.getSurveyDetailedById(surveyId, questionService.getQuestions(surveyId));
                // 返回数据，不过已经无法答题，只能查看
                return Result.success(ResponseCode.SURVEY_END.val(),
                        ResponseCode.SURVEY_END.msg(), survey);
            }
            // 从redis缓存中获取
            SurveyAndQuestionVo survey = surveyService.getSurveyDetailedFromRedis(surveyId);
            if (!ObjectUtil.isEmpty(survey)) {
                return Result.success(ResponseCode.SUCCESS.msg(), survey);
            }
        }
        SurveyAndQuestionVo survey = surveyService.getSurveyDetailedById(surveyId, questionService.getQuestions(surveyId));
        // 判断是否为空
        if (ObjectUtil.isEmpty(survey)) {
            return Result.fail(ResponseCode.FAIL.val(), ResponseCode.FAIL.msg());
        }
        // 判断问卷是否结束
        if (survey.getSurveyStatus() == SurveyStatus.COMPLETED.getStatusId()) {
            return Result.success(ResponseCode.SURVEY_END.val(),
                    ResponseCode.SURVEY_END.msg(), survey);
        }
        return Result.success(ResponseCode.SUCCESS.msg(), survey);
    }

    /**
     * 查看专用(个人和管理员)
     *
     * @param surveyId
     * @return
     */
    @GetMapping("/surveyDetailedForCheck/{surveyId}")
    public Result getSurveyForCheck(@PathVariable("surveyId") Long surveyId, HttpServletRequest request) {

        Survey surveyIsTmp = surveyService.getSurveyById(surveyId);

        // 判断是否查看的是模板
        if (ObjUtil.isNull(surveyIsTmp)) {
            // 获取模板的相关问题和选项
            SurveyAndQuestionVo tmpSurveyDetailedById = tmpSurveyService
                    .getTmpSurveyDetailedById(surveyId, tmpQuestionService.getTmpQuestions(surveyId));
            // 判断是否为空
            if (ObjectUtil.isEmpty(tmpSurveyDetailedById)) {
                return Result.fail(ResponseCode.FAIL.val(), ResponseCode.FAIL.msg());
            }
            return Result.success(ResponseCode.SUCCESS.msg(), tmpSurveyDetailedById);
        }

        SurveyAndQuestionVo survey = surveyService.getSurveyDetailedById(surveyId, questionService.getQuestions(surveyId));
        // 判断是否为空
        if (ObjectUtil.isEmpty(survey)) {
            return Result.fail(ResponseCode.SURVEY_INVALID.val(), ResponseCode.SURVEY_INVALID.msg() + "不存在");
        }
        // 管理员直接查看
        if (tokenUtil.checkIsAdmin(request)) {
            return Result.success(ResponseCode.SUCCESS.msg(), survey);
        }

        // 判断是否个用户本人
        Long userId = tokenUtil.getUserIdFromToken(request);
        Survey surveyById = surveyService.getSurveyById(surveyId);
        if (!surveyById.getUserId().equals(userId)) {
            return Result.fail(ResponseCode.FORBIDDEN.val(), ResponseCode.FORBIDDEN.msg());
        }

        return Result.success(ResponseCode.SUCCESS.msg(), survey);
    }

    /**
     * 发布问卷
     *
     * @param survey
     * @return
     */
    @PostMapping("/publishSurvey")
    public Result publishSurvey(@RequestBody Survey survey, HttpServletRequest httpServletRequest) {

        // 获取用户id
        Long userId = tokenUtil.getUserIdFromToken(httpServletRequest);
        survey.setUserId(userId);
        // 获取问卷id
        Long surveyId = survey.getSurveyId();
        // 查询问卷状态
        Survey surveyById = surveyService.getSurveyById(surveyId);
        if (surveyById.getSurveyStatus() == SurveyStatus.PAUSED.getStatusId()) {
            // 处于暂停状态，只需要更新表状态和redis的数据即可
            surveyService.changeSurveyStatus(surveyId, SurveyStatus.PUBLISHED.getStatusId());
            return Result.success(ResponseCode.SUCCESS.val(), "开启问卷成功");
        } else {
            // 获取问卷的问题
            List<QuestionVo> questions = questionService.getQuestions(surveyId);
            // 金额设置
            survey.setSurveyBalance(surveyById.getSurveyBalance());
            // 回收总数设置
            survey.setSurveyCollectedLimit(surveyById.getSurveyCollectedLimit());
            Integer res = surveyService.publishSurvey(survey, questions);
            if (res != ResponseCode.SUCCESS.val()) {
                return Result.fail(res, ResponseCode.getMsgByVal(res));
            }
            if (surveyById.getSurveyStatus() == SurveyStatus.UN_STARTED.getStatusId()) {
                return Result.success(res, "问卷时间修改成功");
            }
        }
        return Result.success(ResponseCode.SUCCESS.val(), "问卷发布成功");
    }

    /**
     * 暂停问卷
     *
     * @param surveyId
     * @return
     */
    @PutMapping("/stopSurvey/{surveyId}")
    public Result stopSurvey(@PathVariable("surveyId") Long surveyId) {
        Survey surveyById = surveyService.getSurveyById(surveyId);
        // 检查状态是否可以暂停,只有发布中的问卷才可以暂停
        if (surveyById.getSurveyStatus() == SurveyStatus.PUBLISHED.getStatusId()) {
            surveyService.changeSurveyStatus(surveyId, SurveyStatus.PAUSED.getStatusId());
            return Result.success(ResponseCode.SUCCESS.val(), "已暂停当前问卷");
        }
        return Result.fail(ResponseCode.FAIL.val(), "当前问卷状态无法暂停");

    }


    /**
     * 删除问卷
     *
     * @param surveyId
     * @param httpServletRequest (获取userId进行对比。多余操作。有token验证，不需要)
     * @return
     */
    @DeleteMapping("/deleteSurvey/{surveyId}")
    public Result deleteSurvey(@NotBlank(message = ResponseConstants.INVALID_RESPONSE_CODE) @PathVariable("surveyId") Long surveyId
            , HttpServletRequest httpServletRequest) {

        Long userId = tokenUtil.getUserIdFromToken(httpServletRequest);
        Integer res = surveyService.deleteSurveyById(surveyId, userId);
        if (!res.equals(ResponseCode.SUCCESS.val())) {
            return Result.fail(ResponseCode.FAIL.val(), "问卷删除失败");
        }
        return Result.success(ResponseCode.SUCCESS.val(), "删除问卷成功");
    }

    /**
     * 批量删除完成问卷
     *
     * @param ids
     * @return
     */
    @PostMapping("/deleteByIds")
    public Result deleteByIds(@NotBlank(message = ResponseConstants.INVALID_RESPONSE_CODE) String ids) {
        return surveyService.deleteByIds(ids);
    }

    /**
     * 获取问卷一些数量信息
     *
     * @param request
     * @return
     */
    @GetMapping("/getSurveyCountData")
    public Result getSurveyCountData(HttpServletRequest request) {
        Long userId = tokenUtil.getUserIdFromToken(request);

        HashMap<String, Object> map = new HashMap<>();

        // 获取问卷的一些总统计数量
        SurveyCountDataVo surveyCountData = surveyService.getSurveyCountData(userId);

        // 获取每月发布问卷的数量
//        List<SurveyMonthlyCountDto> surveyMonthlyCount = surveyService.getSurveyMonthlyCount(userId);

        // 获取每月收集问卷的数量
        List<SurveyMonthlyCountVo> surveyMonthlyCount = surveyFinishLogService.selectSurveyFinishByMonth(userId);

        map.put("surveyCountData", surveyCountData);
        map.put("surveyMonthlyCount", surveyMonthlyCount);

        return Result.success(map);
    }

    /**
     * 获取当前问卷完成的选择题情况，即每道选择题选择的人次
     * 增加参数可带条件查询
     *
     * @param surveyId
     * @param questionId 条件：问题
     * @param optionId   条件：问题选项
     * @return
     */
    @GetMapping("/getSurveyAnswerCount/{surveyId}")
    public Result getSurveyAnswerCount(@PathVariable("surveyId") Long surveyId,
                                       @RequestParam("questionId") String questionId,
                                       @RequestParam("optionId") String optionId) {

        // 转化值
        questionId = questionId.equals("") ? null : questionId;
        optionId = optionId.equals("") ? null : optionId;

        // 判断条件是否为空，如果任意一个条件为空则都视为不带条件，尝试走redis获取数据
        if (ObjUtil.isNull(questionId) || ObjUtil.isNull(optionId)) {
            // 防止出现questionId为null，但是optionId不为null的情况，所以需要将optionId置空
            optionId = null;
            // 查询redis中是否有
            SurveyAnalysisVo surveyAnalysisFromRedis = surveyService.getSurveyAnalysisFromRedis(surveyId);
            if (!ObjUtil.isNull(surveyAnalysisFromRedis)) {
                // 从redis中获取
                return Result.success(surveyAnalysisFromRedis);
            }
        }

        // 获取题目和选项
        SurveyAndQuestionVo survey = surveyService.getSurveyDetailedById(surveyId, questionService.getQuestions(surveyId));

        // 获取选项统计结果
        List<AnswerChoiceAnalysisVo> answerCountBySurveyId = answerService.getAnswerCountBySurveyId(surveyId
                , ObjUtil.isNull(optionId) ? null : Long.parseLong(optionId));

        // 服务层整合成需要返回的数据
        SurveyAnalysisVo surveyAnalysisVo = surveyService.dealWithAnswerCount(survey, answerCountBySurveyId,
                ObjUtil.isNull(questionId) ? null : Long.parseLong(questionId),
                ObjUtil.isNull(optionId) ? null : Long.parseLong(optionId));

        return Result.success(surveyAnalysisVo);
    }

}
