package com.nekotaku.questionnairesystem.config;

import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.springframework.boot.autoconfigure.jackson.Jackson2ObjectMapperBuilderCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * 注册jackson-datatype-jsr310模块
 * 支持Java 8日期/时间类型
 * @Title:JacksonConfig
 * @Author:NekoTaku
 * @Date:2024/02/06 17:14
 * @Version:1.0
 */
@Configuration
public class JacksonConfig {

    @Bean
    public Jackson2ObjectMapperBuilderCustomizer jsonCustomizer() {
        return builder -> builder.modulesToInstall(new JavaTimeModule());
    }
}
