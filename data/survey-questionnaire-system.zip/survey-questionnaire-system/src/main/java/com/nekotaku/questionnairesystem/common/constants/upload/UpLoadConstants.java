package com.nekotaku.questionnairesystem.common.constants.upload;

/**
 * 上传文件作用常量
 *
 * @Title:UpLoadConstants
 * @Author:NekoTaku
 * @Date:2024/03/21 13:19
 * @Version:1.0
 */
public class UpLoadConstants {

    // 文章封面
    public static final String ARTICLE_COVER = "articleCoverImage:";

    // 文章内容
    public static final String ARTICLE_CONTENT_IMAGE = "articleImage:";

    // 头像
    public static final String AVATAR_IMAGE = "avatar:";

    // 导航图
    public static final String NAVI_IMAGE = "naviImage:";
}
