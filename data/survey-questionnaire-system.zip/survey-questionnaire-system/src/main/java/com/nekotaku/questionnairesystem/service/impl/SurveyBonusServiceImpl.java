package com.nekotaku.questionnairesystem.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.util.ObjUtil;
import cn.hutool.core.util.ReUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.OrderItem;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.nekotaku.questionnairesystem.common.R.ResponseCode;
import com.nekotaku.questionnairesystem.common.R.Result;
import com.nekotaku.questionnairesystem.common.page.QueryPageParam;
import com.nekotaku.questionnairesystem.entity.*;
import com.nekotaku.questionnairesystem.mapper.SurveyBonusMapper;
import com.nekotaku.questionnairesystem.service.SurveyBonusService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.nekotaku.questionnairesystem.service.SurveyService;
import com.nekotaku.questionnairesystem.service.UserService;
import com.nekotaku.questionnairesystem.utils.RegexPatterns;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Arrays;
import java.util.HashMap;

/**
 * <p>
 * 奖励记录表 服务实现类
 * </p>
 *
 * @author nekotaku
 * @since 2024-05-12
 */
@Service
public class SurveyBonusServiceImpl extends ServiceImpl<SurveyBonusMapper, SurveyBonus> implements SurveyBonusService {

    @Autowired
    private SurveyBonusMapper surveyBonusMapper;

    @Autowired
    private SurveyService surveyService;


    /**
     * 添加获取奖励记录
     *
     * @param surveyBonus
     * @return
     */
    @Override
    @Transactional
    public Integer addBonusLog(SurveyBonus surveyBonus) {

        // 支付宝手机号验证合法
        String phone = surveyBonus.getBonusAccount();
        if (!this.RegularVerification(phone, RegexPatterns.PHONE)) {
            return ResponseCode.PHONE_INVALID.val();
        }

        LambdaQueryWrapper<SurveyBonus> qw = new LambdaQueryWrapper<>();
        // 检验手机号是否重复领取(同一问卷ID和手机号即为重复领取)
        qw.eq(SurveyBonus::getSurveyId, surveyBonus.getSurveyId());
        qw.eq(SurveyBonus::getBonusAccount, surveyBonus.getBonusAccount());
        SurveyBonus selectOne = surveyBonusMapper.selectOne(qw);
        if (BeanUtil.isNotEmpty(selectOne)) {
            // 重复领取奖励，拒绝再次领取
            return ResponseCode.PHONE_REPAID.val();
        }

        // 问卷金额减少
        Survey surveyById = surveyService.getSurveyById(surveyBonus.getSurveyId());
        surveyById.setSurveyBalance(surveyById.getSurveyBalance().subtract(surveyBonus.getBonusAmount()));
        // 更新问卷金额
        surveyService.updateById(surveyById);

        // 保存用户ID
        surveyBonus.setUserId(surveyById.getUserId());

        // 添加记录
        this.saveOrUpdate(surveyBonus);

        return ResponseCode.SUCCESS.val();
    }

    /**
     * 分页查询奖励记录信息
     *
     * @param queryPageParam
     * @param userId
     * @return
     */
    @Override
    public Page<SurveyBonus> listSurveyBonus(QueryPageParam queryPageParam, Long userId) {

        Page<SurveyBonus> surveyBonusPage = new Page<>();

        // 设置当前页
        surveyBonusPage.setCurrent(queryPageParam.getPageNum());

        // 设置当前页面数量
        surveyBonusPage.setSize(queryPageParam.getPageSize());

        // 按照最新时间排序
        surveyBonusPage.setOrders(Arrays.asList(OrderItem.desc("create_time")));

        // 获取查询条件
        HashMap param = queryPageParam.getParam();

        String surveyTitle = param.get("surveyTitle").toString();

        LambdaQueryWrapper<SurveyBonus> qw = new LambdaQueryWrapper<>();

        // 按照条件查询
        // 标题(模糊查询)
        if (StrUtil.isNotBlank(surveyTitle) && !"null".equals(surveyTitle)) {
            qw.like(SurveyBonus::getSurveyTitle, surveyTitle);
        }

        // 匹配当前用户的
        qw.eq(SurveyBonus::getUserId, userId);

        return this.page(surveyBonusPage, qw);
    }


    /**
     * 利用hutool进行正则表达式验证
     *
     * @param value
     * @param regex
     * @return true：匹配，false：不匹配
     */
    private boolean RegularVerification(String value, String regex) {
        return ReUtil.isMatch(regex, value);
    }
}
