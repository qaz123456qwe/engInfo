package com.nekotaku.questionnairesystem.utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * 红包工具类
 *
 * @Title:RedPacket
 * @Author:NekoTaku
 * @Date:2024/05/12 21:44
 * @Version:1.0
 */
public class RedPacket {

    /**
     * 封装红包列表
     *
     * @param totalAmount 总金额（单位：分，避免浮点数计算问题；10000分=10元）
     * @param num 红包总数
     * @return 返回一个红包列表(每个红包多少元)
     */
    public static List<Integer> distributeRedPacket(Integer totalAmount, Integer num) {
        List<Integer> packets = new ArrayList<>();
        Random random = new Random();
        int remainingAmount = totalAmount;
        int remainingNum = num;

        for (int i = 0; i < num - 1; i++) {
            // 防止红包金额太小，设定一个最小金额，比如1分钱
            int max = remainingAmount - remainingNum + 1;
            // 随机生成当前红包金额
            int amount = random.nextInt(max) + 1;
            packets.add(amount);
            remainingAmount -= amount;
            remainingNum--;
        }
        // 最后一个红包，把剩余金额全部给出
        packets.add(remainingAmount);

        return packets;
    }
}
