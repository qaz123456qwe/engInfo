package com.nekotaku.questionnairesystem.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.nekotaku.questionnairesystem.common.R.ResponseConstants;
import com.nekotaku.questionnairesystem.utils.RegexPatterns;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

/**
 * <p>
 * 分类表
 * </p>
 *
 * @author nekotaku
 * @since 2023-12-10
 */
@Data
@EqualsAndHashCode(callSuper = false)
@ApiModel(value="Category对象", description="分类表")
public class Category implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "分类id")
    @TableId(value = "category_id")
    private Long categoryId;

    @ApiModelProperty(value = "分类名")
    @NotBlank(message = ResponseConstants.INVALID_CATEGORY_CODE)
    @Pattern(regexp = RegexPatterns.STRING_NO_SPACE,message = ResponseConstants.INVALID_CATEGORY_CODE)
    private String categoryName;

    @ApiModelProperty(value = "所属用户")
    private Long userId;

    @ApiModelProperty(value = "分类更新时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;


}
