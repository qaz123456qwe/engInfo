package com.nekotaku.questionnairesystem.mapper;

import com.nekotaku.questionnairesystem.vo.SurveyMonthlyCountVo;
import com.nekotaku.questionnairesystem.entity.SurveyFinishLog;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 问卷每完成一份的日志 Mapper 接口
 * </p>
 *
 * @author nekotaku
 * @since 2024-02-29
 */
@Mapper
public interface SurveyFinishLogMapper extends BaseMapper<SurveyFinishLog> {

    // 统计每月已收集问卷数量
    List<SurveyMonthlyCountVo> selectSurveyFinishByMonth(@Param("userId") Long userId);
}
