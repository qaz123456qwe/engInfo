package com.nekotaku.questionnairesystem.service;

import com.nekotaku.questionnairesystem.vo.QuestionTmpVo;
import com.nekotaku.questionnairesystem.entity.TmpQuestion;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 * 模板问卷问题表 服务类
 * </p>
 *
 * @author nekotaku
 * @since 2024-03-04
 */
public interface TmpQuestionService extends IService<TmpQuestion> {

    Integer saveQuestion(List<QuestionTmpVo> questionTmpVo);

    void deleteTmpQuestions(Long tmpId);

    List<QuestionTmpVo> getTmpQuestions(Long tmpId);
}
