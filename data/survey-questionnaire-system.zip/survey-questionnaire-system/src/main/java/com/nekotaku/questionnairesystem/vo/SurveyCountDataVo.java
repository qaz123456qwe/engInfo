package com.nekotaku.questionnairesystem.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Title:SurveyDataDto
 * @Author:NekoTaku
 * @Date:2024/02/22 15:06
 * @Version:1.0
 */
@Data
public class SurveyCountDataVo {

    @ApiModelProperty(value = "已经发布的问卷数量(包括暂停中，只要设定了发布时间的)")
    private Long surveyCount;

    @ApiModelProperty(value = "已经收集的问卷数量")
    private Long surveyCollectedCount;

    @ApiModelProperty(value = "已经完成的问卷数量")
    private Long surveyCompletedCount;

}
