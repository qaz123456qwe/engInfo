package com.nekotaku.questionnairesystem.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.nekotaku.questionnairesystem.common.page.QueryPageParam;
import com.nekotaku.questionnairesystem.entity.UserOrder;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.Map;

/**
 * <p>
 * 订单表 服务类
 * </p>
 *
 * @author nekotaku
 * @since 2024-05-12
 */
public interface UserOrderService extends IService<UserOrder> {

    void payAdd(Map<String, String> params);

    Page<UserOrder> listOrders(QueryPageParam queryPageParam);
}
