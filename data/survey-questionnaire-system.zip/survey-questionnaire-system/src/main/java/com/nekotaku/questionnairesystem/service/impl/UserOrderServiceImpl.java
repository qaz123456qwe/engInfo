package com.nekotaku.questionnairesystem.service.impl;

import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.OrderItem;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.nekotaku.questionnairesystem.common.page.QueryPageParam;
import com.nekotaku.questionnairesystem.entity.User;
import com.nekotaku.questionnairesystem.entity.UserOrder;
import com.nekotaku.questionnairesystem.mapper.UserOrderMapper;
import com.nekotaku.questionnairesystem.service.UserOrderService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.nekotaku.questionnairesystem.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * 订单表 服务实现类
 * </p>
 *
 * @author nekotaku
 * @since 2024-05-12
 */
@Service
public class UserOrderServiceImpl extends ServiceImpl<UserOrderMapper, UserOrder> implements UserOrderService {

    @Autowired
    private UserOrderMapper orderMapper;

    @Autowired
    private UserService userService;

    /**
     * 支付成功，订单表和用户表金额更新
     *
     * @param params
     */
    @Override
    @Transactional
    public void payAdd(Map<String, String> params) {

        // 获取用户名
        String[] subjects = params.get("subject").split(",");
        String username = subjects[subjects.length - 1];

        // 获取用户信息更新金额
        // 交易金额
        String amount = params.get("buyer_pay_amount");

        LambdaQueryWrapper<User> userQw = new LambdaQueryWrapper<>();
        User user = userService.getOne(userQw.eq(User::getUserName, username));
        // 原来的金额加上当前充值的金额
        BigDecimal oldBalance = user.getUserBalance();
        BigDecimal balance = oldBalance.add(new BigDecimal(amount));

        // 更新用户信息
        userService.updateBalance(user.getUserId(), balance);

        // 订单表更新
        UserOrder order = new UserOrder();
        order.setId(null);
        order.setOrderId(params.get("trade_no"));
        order.setOrderText("用户：" + username + ",充值金额：" + amount + ",上一次余额：" + oldBalance + ",本次余额：" + balance);
        order.setOrderBalance(new BigDecimal(amount));
        order.setUserName(username);

        this.saveOrUpdate(order);

//        System.out.println("交易名称: " + params.get("subject"));
//        System.out.println("交易状态: " + params.get("trade_status"));
//        System.out.println("支付宝交易凭证号: " + params.get("trade_no"));
//        System.out.println("商户订单号: " + params.get("out_trade_no"));
//        System.out.println("交易金额: " + params.get("total_amount"));
//        System.out.println("买家在支付宝唯一id: " + params.get("buyer_id"));
//        System.out.println("买家付款时间: " + params.get("gmt_payment"));
//        System.out.println("买家付款金额: " + params.get("buyer_pay_amount"));
    }

    /**
     * 分页查询所有充值记录
     *
     * @param queryPageParam
     * @return
     */
    @Override
    public Page<UserOrder> listOrders(QueryPageParam queryPageParam) {
        Page<UserOrder> userOrderPage = new Page<>();

        // 设置当前页
        userOrderPage.setCurrent(queryPageParam.getPageNum());

        // 设置当前页面数量
        userOrderPage.setSize(queryPageParam.getPageSize());

        // 按照最新时间排序
        userOrderPage.setOrders(Arrays.asList(OrderItem.desc("create_time")));

        // 获取查询条件
        HashMap param = queryPageParam.getParam();

        String orderId = param.get("orderId").toString();
        String username = param.get("username").toString();

        LambdaQueryWrapper<UserOrder> qw = new LambdaQueryWrapper<>();

        // 按照条件查询
        if (StrUtil.isNotBlank(orderId) && !"null".equals(orderId)) {
            // 订单号
            qw.eq(UserOrder::getOrderId, orderId);
        }

        if (StrUtil.isNotBlank(username) && !"null".equals(username)) {
            // 用户名
            qw.eq(UserOrder::getUserName, username);
        }


        return this.page(userOrderPage, qw);
    }
}
