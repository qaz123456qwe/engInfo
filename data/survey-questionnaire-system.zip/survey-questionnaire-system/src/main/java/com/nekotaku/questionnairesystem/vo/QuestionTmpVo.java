package com.nekotaku.questionnairesystem.vo;

import com.nekotaku.questionnairesystem.entity.TmpOption;
import com.nekotaku.questionnairesystem.entity.TmpQuestion;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

/**
 * @Title:QuestionTmpDto
 * @Author:NekoTaku
 * @Date:2024/03/04 14:24
 * @Version:1.0
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class QuestionTmpVo extends TmpQuestion {

    @ApiModelProperty(value = "模板选项列表")
    private List<TmpOption> option;

    @ApiModelProperty(value = "模板题类型")
    private String questionTypeValue;

}
