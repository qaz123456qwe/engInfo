package com.nekotaku.questionnairesystem.mapper;

import com.nekotaku.questionnairesystem.entity.QuestionOption;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * <p>
 * 选项表，对应问卷问题的选择题 Mapper 接口
 * </p>
 *
 * @author nekotaku
 * @since 2024-01-29
 */
@Mapper
public interface QuestionOptionMapper extends BaseMapper<QuestionOption> {

    List<QuestionOption> selectListByQuestionId(@Param("questionId") Long questionId);
}
