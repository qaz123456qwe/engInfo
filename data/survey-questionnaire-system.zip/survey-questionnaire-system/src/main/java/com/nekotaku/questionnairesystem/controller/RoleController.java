package com.nekotaku.questionnairesystem.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 用户角色表 前端控制器
 * </p>
 *
 * @author nekotaku
 * @since 2023-12-10
 */
@RestController
@RequestMapping("/role")
public class RoleController {

}
