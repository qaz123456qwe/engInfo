package com.nekotaku.questionnairesystem.controller;


import cn.hutool.core.util.ObjectUtil;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.nekotaku.questionnairesystem.common.R.ResponseCode;
import com.nekotaku.questionnairesystem.common.R.ResponseConstants;
import com.nekotaku.questionnairesystem.common.R.Result;
import com.nekotaku.questionnairesystem.common.page.QueryPageParam;
import com.nekotaku.questionnairesystem.entity.Article;
import com.nekotaku.questionnairesystem.service.ArticleService;
import com.nekotaku.questionnairesystem.utils.TokenUtil;
import com.nekotaku.questionnairesystem.vo.ArticleVo;
import com.nekotaku.questionnairesystem.vo.front.ArticleFrontVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.constraints.NotBlank;

/**
 * <p>
 * 文章表前端控制器
 * </p>
 *
 * @author nekotaku
 * @since 2024-03-19
 */
@RestController
@RequestMapping("/article")
public class ArticleController {

    @Autowired
    private ArticleService articleService;

    @Autowired
    private TokenUtil tokenUtil;


    /**
     * 新增或更新文章基本信息
     *
     * @param article
     * @param httpServletRequest
     * @return
     */
    @PostMapping("/saveOrUpdateArticle")
    public Result saveOrUpdateArticle(@RequestBody Article article,
                                      HttpServletRequest httpServletRequest) {
        Long userId = tokenUtil.getUserIdFromToken(httpServletRequest);
        article.setUserId(userId);

        // 调用保存服务
        Integer res = articleService.saveOrUpdateArticle(article);

        if (res != ResponseCode.SUCCESS.val()) {
            return Result.fail(res, ResponseCode.getMsgByVal(res));
        }
        return Result.success(res, "文章成功");
    }

    /**
     * 分页查询文章列表(可带条件查询)
     *
     * @param queryPageParam
     * @param httpServletRequest
     * @return
     */
    @PostMapping("/listArticle")
    public Result listArticle(@RequestBody QueryPageParam queryPageParam,
                              HttpServletRequest httpServletRequest) {
        Long userId = tokenUtil.getUserIdFromToken(httpServletRequest);

        Page<ArticleVo> res = articleService.listArticle(queryPageParam, userId);

        return Result.success(ResponseCode.SUCCESS.val(), ResponseCode.SUCCESS.msg(),
                res.getRecords(), res.getTotal());
    }

    /**
     * 分页查询文章列表 前台首页使用
     *
     * @param queryPageParam
     * @return
     */
    @PostMapping("/listArticleForFront")
    public Result listArticleForFront(@RequestBody QueryPageParam queryPageParam) {
        Page<ArticleFrontVo> res = articleService.listArticleForFront(queryPageParam);

        return Result.success(ResponseCode.SUCCESS.val(), ResponseCode.SUCCESS.msg(),
                res.getRecords(), res.getTotal());
    }

    /**
     * 更改文章状态
     *
     * @param articleId
     * @return
     */
    @PostMapping("/changeArticleStatus")
    public Result changeArticleStatus(@RequestParam("articleId") Long articleId) {

        Integer res = articleService.changeArticleStatus(articleId);

        if (!res.equals(ResponseCode.SUCCESS.val())) {
            return Result.fail(res, ResponseCode.getMsgByVal(res));
        }
        return Result.success(ResponseCode.SUCCESS.val(), ResponseCode.SUCCESS.msg());
    }

    /**
     * 删除文章
     *
     * @param articleId
     * @return
     */
    @DeleteMapping("/deleteArticle/{articleId}")
    public Result deleteArticle(@NotBlank(message = ResponseConstants.INVALID_RESPONSE_CODE)
                                @PathVariable("articleId") String articleId) {
        Integer res = articleService.deleteArticle(articleId);
        if (!res.equals(ResponseCode.SUCCESS.val())) {
            return Result.fail(ResponseCode.FAIL.val(), "文章删除失败");
        }
        return Result.success(ResponseCode.SUCCESS.val(), "删除文章成功");
    }

    /**
     * 根据id获取文章
     *
     * @param articleId
     * @return
     */
    @GetMapping("/getArticle/{articleId}")
    public Result getArticleVoById(@NotBlank(message = ResponseConstants.INVALID_RESPONSE_CODE)
                                   @PathVariable("articleId") String articleId) {
        ArticleVo articleVo = articleService.getArticleVoById(articleId);
        if (ObjectUtil.isNull(articleVo)) {
            return Result.fail(ResponseCode.FAIL.val(), "文章不存在");
        }
        return Result.success(articleVo);
    }

    /**
     * 根据id获取文章(管理员和个人查看用)
     *
     * @param articleId
     * @param request
     * @return
     */
    @GetMapping("/getArticleForCheck/{articleId}")
    public Result getArticleVoById(@NotBlank(message = ResponseConstants.INVALID_RESPONSE_CODE)
                                   @PathVariable("articleId") String articleId,
                                   HttpServletRequest request) {
        Long userId = tokenUtil.getUserIdFromToken(request);

        boolean isAdmin = tokenUtil.checkIsAdmin(request);

        ArticleVo articleVo = articleService.getArticleVoById(articleId, userId, isAdmin);
        if (ObjectUtil.isNull(articleVo)) {
            return Result.fail(ResponseCode.FAIL.val(), "文章不存在");
        }
        return Result.success(articleVo);
    }


    /**
     * 保存文章内容
     *
     * @param article
     * @return
     */
    @PostMapping("/saveArticleContent")
    public Result savaArticleContent(@RequestBody Article article, HttpServletRequest request) {

        Long userId = tokenUtil.getUserIdFromToken(request);
        article.setUserId(userId);

        Integer res = articleService.saveArticleContent(article);
        if (!res.equals(ResponseCode.SUCCESS.val())) {
            return Result.fail(ResponseCode.FAIL.val(), "文章保存失败");
        }
        return Result.success(ResponseCode.SUCCESS.val(), "保存文章成功");
    }

    /**
     * 更新浏览量
     *
     * @param articleId
     * @param request
     * @return
     */
    @PutMapping("/updateViews/{articleId}")
    public Result updateViews(@NotBlank(message = ResponseConstants.INVALID_RESPONSE_CODE)
                              @PathVariable("articleId") String articleId,
                              HttpServletRequest request) {

        Long userId = tokenUtil.getUserIdFromToken(request);

        Integer res = articleService.updateViews(articleId, userId);
        if (!res.equals(ResponseCode.SUCCESS.val())) {
            return Result.fail(ResponseCode.FAIL.val(), ResponseCode.FAIL.msg());
        }
        return Result.success(ResponseCode.SUCCESS.val(), ResponseCode.SUCCESS.msg());
    }
}
