package com.nekotaku.questionnairesystem.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 每月发布问卷数据统计
 *
 * @Title:SurveyMonthlyCountDto
 * @Author:NekoTaku
 * @Date:2024/02/28 14:59
 * @Version:1.0
 */
@Data
public class SurveyMonthlyCountVo {

    @ApiModelProperty(value = "年")
    private int year;

    @ApiModelProperty(value = "月")
    private int month;

    @ApiModelProperty(value = "问卷数量")
    private int surveyCount;
}
