package com.nekotaku.questionnairesystem.utils.redis;


import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.DependsOn;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Redis通用工具类(特殊bean处理)
 *
 * @Title:RedisUtil
 * @Author:NekoTaku
 * @Date:2024/03/16 18:50
 * @Version:1.0
 */
@Component
@Slf4j
@DependsOn("redisTemplate")
public class RedisBeanUtil {


    /**
     * 保存对象
     *
     * @param redisTemplate
     * @param key
     * @param value
     * @param <K>
     * @param <V>
     */
    @Async
    public <K, V> void set(RedisTemplate<K, V> redisTemplate, K key, V value) {
        redisTemplate.opsForValue().set(key, value);
    }

    /**
     * 保存列表
     *
     * @param redisTemplate
     * @param key
     * @param objectList
     * @param <K>
     * @param <V>
     */
    @Async
    public <K, V> void setList(RedisTemplate<K, V> redisTemplate, K key, List<V> objectList) {
        redisTemplate.opsForList().leftPushAll(key, objectList);
    }

    /**
     * 带过期时间的保存对象
     *
     * @param redisTemplate
     * @param key
     * @param value
     * @param timeout
     * @param unit
     * @param <K>
     * @param <V>
     */
    @Async
    public <K, V> void setTTL(RedisTemplate<K, V> redisTemplate, K key, V value, long timeout, TimeUnit unit) {
        redisTemplate.opsForValue().set(key, value, timeout, unit);
    }

    /**
     * 设置key过期时间
     *
     * @param redisTemplate
     * @param key
     * @param timeout
     * @param unit
     * @param <K>
     * @param <V>
     */
    @Async
    public <K, V> void setExpiration(RedisTemplate<K, V> redisTemplate, K key, long timeout, TimeUnit unit) {
        redisTemplate.expire(key, timeout, unit);
    }

    /**
     * 根据key获取值
     * 不能加@Async原因：需要立即获取结果并且依赖这个结果进行后续操作时,异步方法不适用
     *
     * @param redisTemplate
     * @param key
     * @param <K>
     * @param <V>
     * @return
     */
    public <K, V> V get(RedisTemplate<K, V> redisTemplate, K key) {
        try {
            // 执行 Redis 操作
            // 处理返回值
            log.info("从redis中获取数据");
            return redisTemplate.opsForValue().get(key);
        } catch (Exception e) {
            // Redis 连接异常，进行异常处理
            log.error("Redis 连接异常: {}", e.getMessage());
            return  null;
        }
    }

    /**
     * 根据key获取列表
     *
     * @param redisTemplate
     * @param key
     * @param <K>
     * @param <V>
     * @return
     */
    public <K, V> List<V> getList(RedisTemplate<K, V> redisTemplate, K key) {
        try {
            // 执行 Redis 操作
            // 处理返回值
            return redisTemplate.opsForList().range(key, 0, -1);
        } catch (Exception e) {
            // Redis 连接异常，进行异常处理
            log.error("Redis 连接异常: {}", e.getMessage());
            return  null;
        }
    }

    /**
     * 删除key
     *
     * @param redisTemplate
     * @param key
     * @param <K>
     * @param <V>
     */
    @Async
    public <K, V> void delete(RedisTemplate<K, V> redisTemplate, K key) {
        redisTemplate.delete(key);
    }

}
