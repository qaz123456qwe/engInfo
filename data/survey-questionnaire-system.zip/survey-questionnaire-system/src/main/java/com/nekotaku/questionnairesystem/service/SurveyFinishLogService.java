package com.nekotaku.questionnairesystem.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.nekotaku.questionnairesystem.common.page.QueryPageParam;
import com.nekotaku.questionnairesystem.vo.SurveyAndQuestionVo;
import com.nekotaku.questionnairesystem.vo.SurveyMonthlyCountVo;
import com.nekotaku.questionnairesystem.entity.Answer;
import com.nekotaku.questionnairesystem.entity.SurveyFinishLog;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 * 问卷每完成一份的日志 服务类
 * </p>
 *
 * @author nekotaku
 * @since 2024-02-29
 */
public interface SurveyFinishLogService extends IService<SurveyFinishLog> {

    List<SurveyMonthlyCountVo> selectSurveyFinishByMonth(Long userId);

    Page<SurveyFinishLog> listSurveyLog(QueryPageParam queryPageParam, Long userId);

    SurveyAndQuestionVo setAnswerForQuestion(SurveyAndQuestionVo surveyDetailedById, List<Answer> answerList);

    void deleteBySurveyId(Long reportSurveyId);
}
