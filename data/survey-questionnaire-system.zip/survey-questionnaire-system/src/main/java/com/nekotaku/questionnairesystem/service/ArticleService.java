package com.nekotaku.questionnairesystem.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.nekotaku.questionnairesystem.common.page.QueryPageParam;
import com.nekotaku.questionnairesystem.entity.Article;
import com.baomidou.mybatisplus.extension.service.IService;
import com.nekotaku.questionnairesystem.vo.ArticleVo;
import com.nekotaku.questionnairesystem.vo.front.ArticleFrontVo;

/**
 * <p>
 *  文章表服务类
 * </p>
 *
 * @author nekotaku
 * @since 2024-03-19
 */
public interface ArticleService extends IService<Article> {

    Integer saveOrUpdateArticle(Article article);

    Page<ArticleVo> listArticle(QueryPageParam queryPageParam, Long userId);

    Integer changeArticleStatus(Long articleId);

    Integer deleteArticle(String articleId);

    ArticleVo getArticleVoById(String articleId);

    ArticleVo getArticleVoById(String articleId,Long userId,boolean isAdmin);

    Integer saveArticleContent(Article article);

    Integer updateViews(String articleId,Long userId);

    Integer setReportResult(Long reportArticleId, Integer reportResult,String userEmail,Integer reportStatus);

    Page<ArticleFrontVo> listArticleForFront(QueryPageParam queryPageParam);
}
