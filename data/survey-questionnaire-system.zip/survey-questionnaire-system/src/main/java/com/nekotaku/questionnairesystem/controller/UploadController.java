package com.nekotaku.questionnairesystem.controller;

import com.nekotaku.questionnairesystem.common.R.ResponseCode;
import com.nekotaku.questionnairesystem.common.R.Result;
import com.nekotaku.questionnairesystem.utils.TokenUtil;
import com.nekotaku.questionnairesystem.utils.file.UploadUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;

/**
 * 文件上传控制器
 *
 * @Title:UploadController
 * @Author:NekoTaku
 * @Date:2024/03/20 10:18
 * @Version:1.0
 */
@RestController
@RequestMapping("/upload")
public class UploadController {

    @Autowired
    private UploadUtils uploadUtils;

    @Autowired
    private TokenUtil tokenUtil;

    /**
     * 图片文件上传
     * @param multipartFile
     * @param type 图片作用类型(用于文件名创建分类)
     * @param request
     * @return
     */
    @PostMapping("/uploadImage")
    public Result uploadCoverArticleImage(@RequestParam(value = "file") MultipartFile multipartFile,
                                          @RequestParam(value = "type") String type,
                                          HttpServletRequest request) {
        if (multipartFile.isEmpty()) {
            return Result.fail(ResponseCode.FILE_EMPTY.val(), ResponseCode.FILE_EMPTY.msg());
        }

        // 获取用户id
        Long userId = tokenUtil.getUserIdFromToken(request);

        // 调用上传工具类进行文件上传
        return uploadUtils.ImageFileUpload(multipartFile, userId, type);
    }
}
