package com.nekotaku.questionnairesystem.utils.file;

import cn.hutool.json.JSONUtil;
import com.nekotaku.questionnairesystem.common.R.ResponseCode;
import com.nekotaku.questionnairesystem.common.R.Result;
import com.nekotaku.questionnairesystem.common.constants.redis.RedisConstants;
import com.nekotaku.questionnairesystem.utils.redis.RedisData;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.UUID;

/**
 * 文件上传工具类
 *
 * @Title:UploadUtils
 * @Author:NekoTaku
 * @Date:2024/03/20 12:45
 * @Version:1.0
 */
@Slf4j
@Component
public class UploadUtils {

    // 图片虚拟路径(外部访问路径地址)
    @Value("${file.accessPath}")
    private String accessPath;

    // 图片临时存放的真实路径地址(存放图片的服务器或者主机地址)
    @Value("${file.uploadTempFolder}")
    private String realTempBasePath;

    // 图片真实路径地址(存放图片的服务器或者主机地址)
    @Value("${file.uploadFolder}")
    private String realBasePath;


    @Autowired
    private StringRedisTemplate redisTemplate;

    @Autowired
    private FileExtensionChecker fileExtensionChecker;

    /**
     * 图片上传
     *
     * @param file
     * @param userId
     * @param type   图片作用类型(例：头像headImage、文章封面articleCoverImage)
     * @return
     */
    public Result ImageFileUpload(MultipartFile file, Long userId, String type) {
        log.info("调用上传图片");

        //给上传的图片创建单独文件夹分类(按照:/基本路径/type/用户id/时间/)
        Date todayDate = new Date();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String today = dateFormat.format(todayDate);

        // 文件真实名
        String fileName = file.getOriginalFilename();

        // 判断图片格式是否正确(图片格式只支持jpg、png、jpeg)
        if (!fileExtensionChecker.isAllowedExtension(fileName)) {
            return Result.fail(ResponseCode.IMAGE_FORMAT_ERROR.val()
                    , ResponseCode.IMAGE_FORMAT_ERROR.msg());
        }
        // 后缀名
        String suffixName = fileName.substring(fileName.lastIndexOf("."));

        // 上传后的路径
        String filePath = realTempBasePath + type + "/" + userId + "/" + today + "/";
        // 新文件名
        fileName = UUID.randomUUID().toString().replaceAll("-", "") + suffixName;
        // 将临时路径存入redis
        saveToRedis(userId, fileName, type, filePath + fileName);
        File dest = new File(filePath + fileName);
        if (!dest.getParentFile().exists()) {
            dest.getParentFile().mkdirs();
        }
        try {

            // 存入磁盘
            file.transferTo(dest);
        } catch (IOException e) {
            e.printStackTrace();
        }
        //虚拟路径,链接访问用
        String fileUrl = accessPath + type + "/" + userId + "/" + today + "/" + fileName;

        return Result.success(fileUrl);
    }

    /**
     * 将临时文件路径存入redis中，实际提交保存时再存入真正的文件中
     *
     * @param userId
     * @param filename
     * @param type
     * @param realBasePath
     */
    private void saveToRedis(Long userId, String filename, String type, String realBasePath) {
        String key = RedisConstants.UPLOAD_FILE + type + ":" + userId + ":" + filename;

        // 设置逻辑过期
        RedisData redisData = new RedisData();
        redisData.setData(realBasePath);
        // 设置一天的过期时间
//        redisData.setExpireTime(LocalDateTime.now().plusSeconds(5L));
        redisData.setExpireTime(LocalDateTime.now().plusDays(1L));

        // 写入redis
        // redisTemplate.opsForValue().set(key, realBasePath);
        redisTemplate.opsForValue().set(key, JSONUtil.toJsonStr(redisData));
    }


    /**
     * 文件拷贝
     *
     * @param sourcePath
     * @param destinationPath
     * @throws IOException
     */
    public void copyFile(String sourcePath, String destinationPath) throws IOException {

        // 目标路径加上真实路径地址
        destinationPath = realBasePath + destinationPath;

        File sourceFile = new File(sourcePath);
        File destinationFile = new File(destinationPath);

        // 确保目标路径的父目录存在，如果不存在则创建
        File parentDirectory = destinationFile.getParentFile();
        if (!parentDirectory.exists()) {
            if (!parentDirectory.mkdirs()) {
                log.error("无法创建目标文件的父目录: " + parentDirectory.getPath());
                return;
            }
        }

        if (!sourceFile.exists()) {
            log.error("文件没有找到: " + sourcePath);
        }

        if (destinationFile.exists()) {
            log.error("路径已经存在 " + destinationPath);
        }
        try (InputStream inputStream = new FileInputStream(sourceFile);
             OutputStream outputStream = new FileOutputStream(destinationFile)) {

            byte[] buffer = new byte[1024];
            int length;

            while ((length = inputStream.read(buffer)) > 0) {
                outputStream.write(buffer, 0, length);
            }
        }
    }

    /**
     * 根据文件路径删除文件
     *
     * @param filePath 虚拟文件路径
     * @return 删除成功返回 true，否则返回 false
     */
    public boolean deleteFileByPath(String filePath) {

        String realFilePath = filePath;
        // 判断是否为虚拟路径
        if (filePath.startsWith(accessPath)) {
            // 将虚拟路径替换成实际路径
            realFilePath = filePath.replace(accessPath, realBasePath);
        }

        File file = new File(realFilePath);
        if (file.exists() && file.isFile()) {
            boolean deleted = file.delete();
            if (deleted) {
                // 删除文件成功，检查父文件夹是否为空，如果为空则删除父文件夹
                deleteEmptyParentFolder(file.getParentFile());
            }
            return deleted;
        } else {
            log.error("文件不存在或不是一个文件: " + filePath);
            return false;
        }
    }

    /**
     * 递归删除为空的父级文件夹
     *
     * @param folder
     */
    private void deleteEmptyParentFolder(File folder) {
        if (folder != null && folder.isDirectory() && folder.list().length == 0) {
            if (folder.delete()) {
                // 递归删除父文件夹
                deleteEmptyParentFolder(folder.getParentFile());
            } else {
                log.error("无法删除空文件夹: " + folder.getPath());
            }
        }
    }

    /**
     * 将临时文件夹的文件拷贝到正式文件夹下
     *
     * @param filePath 虚拟路径
     * @param type     文件作用
     * @param userId
     * @return
     */
    public void copyTempFile(String filePath, String type, Long userId) {
        // 获取文件名
        String fileName = subFileName(filePath);
        // 从redis中获取真实路径
        // key格式 ：upload:articleCoverImage:1730595089106980866:b7aa0877dcdf4c60993a84e249828dc7.jpg
        String key = RedisConstants.UPLOAD_FILE + type + userId + ":" + fileName;
        String realPathFromRedis = getRealPathFromRedis(key);

        // 目标路径(正式文件夹)拼接
        String desiredSubstring = type.replaceAll(":", "") + "/" + realPathFromRedis.substring(
                realPathFromRedis.indexOf(String.valueOf(userId)));
        // 使用拷贝
        try {
            copyFile(realPathFromRedis, desiredSubstring);
        } catch (IOException e) {
            log.error("文件拷贝异常{}", e);
        }
    }

    /**
     * 从获取虚拟路径中获取文件名
     *
     * @param path
     * @return
     */
    public String subFileName(String path) {
        return path.substring(path.lastIndexOf("/") + 1);
    }

    /**
     * 从redis中取出临时文件路径
     *
     * @param key
     * @return
     */
    private String getRealPathFromRedis(String key) {

        String data = redisTemplate.opsForValue().get(key);
        RedisData redisData = JSONUtil.toBean(data, RedisData.class);

        return redisData.getData().toString();
    }

}
