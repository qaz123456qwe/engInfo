package com.nekotaku.questionnairesystem.mapper;

import com.nekotaku.questionnairesystem.entity.UserOrder;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * 订单表 Mapper 接口
 * </p>
 *
 * @author nekotaku
 * @since 2024-05-12
 */
@Mapper
public interface UserOrderMapper extends BaseMapper<UserOrder> {

}
