package com.nekotaku.questionnairesystem.utils.redis;

import lombok.Data;

import java.time.LocalDateTime;

/**
 * redis 逻辑过期
 *
 * @Title:RedisData
 * @Author:NekoTaku
 * @Date:2024/03/27 12:17
 * @Version:1.0
 */
@Data
public class RedisData {
    //逻辑过期时间
    private LocalDateTime expireTime;
    private Object data;
}