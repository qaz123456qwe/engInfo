package com.nekotaku.questionnairesystem.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.nekotaku.questionnairesystem.vo.ArticleVo;
import com.nekotaku.questionnairesystem.vo.SurveyAndQuestionVo;
import com.nekotaku.questionnairesystem.vo.analysis.SurveyAnalysisVo;
import com.nekotaku.questionnairesystem.vo.analysis.TextQuestionAnalysisVo;
import org.springframework.cache.annotation.CachingConfigurerSupport;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.Jackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;

/**
 * Redis配置类
 *
 * @Title:RedisConfig
 * @Author:NekoTaku
 * @Date:2023/11/21 20:34
 * @Version:1.0
 */
@Configuration
public class RedisConfig extends CachingConfigurerSupport {

    @Bean(name = "defaultRedisTemplate")
    public RedisTemplate<Object, Object> redisTemplate(RedisConnectionFactory connectionFactory) {
        RedisTemplate<Object, Object> redisTemplate = new RedisTemplate<>();
        redisTemplate.setKeySerializer(new StringRedisSerializer());
        redisTemplate.setConnectionFactory(connectionFactory);
        return redisTemplate;
    }

    @Bean(name = "surveyRedisTemplate")
    public RedisTemplate<String, SurveyAndQuestionVo> surveyRedisTemplate(RedisConnectionFactory connectionFactory) {
        RedisTemplate<String, SurveyAndQuestionVo> redisTemplate = new RedisTemplate<>();
        redisTemplate.setConnectionFactory(connectionFactory);

        // 使用Jackson2JsonRedisSerializer将对象序列化为JSON格式
        Jackson2JsonRedisSerializer<SurveyAndQuestionVo> serializer = new Jackson2JsonRedisSerializer<>(SurveyAndQuestionVo.class);
        ObjectMapper objectMapper = new ObjectMapper();
        // 注册JavaTimeModule以支持Java 8日期/时间类型
        objectMapper.registerModule(new JavaTimeModule());
        serializer.setObjectMapper(objectMapper);

        redisTemplate.setKeySerializer(new StringRedisSerializer());
        redisTemplate.setValueSerializer(serializer);

        return redisTemplate;
    }

    @Bean(name = "surveyAnalysisRedisTemplate")
    public RedisTemplate<String, SurveyAnalysisVo> surveyAnalysisRedisTemplate(RedisConnectionFactory connectionFactory) {
        RedisTemplate<String, SurveyAnalysisVo> redisTemplate = new RedisTemplate<>();
        redisTemplate.setConnectionFactory(connectionFactory);

        // 使用Jackson2JsonRedisSerializer将对象序列化为JSON格式
        Jackson2JsonRedisSerializer<SurveyAnalysisVo> serializer = new Jackson2JsonRedisSerializer<>(SurveyAnalysisVo.class);
        ObjectMapper objectMapper = new ObjectMapper();
        // 注册JavaTimeModule以支持Java 8日期/时间类型
        objectMapper.registerModule(new JavaTimeModule());
        serializer.setObjectMapper(objectMapper);

        redisTemplate.setKeySerializer(new StringRedisSerializer());
        redisTemplate.setValueSerializer(serializer);

        return redisTemplate;
    }

    @Bean(name = "ObjectiveAnalysisRedisTemplate")
    public RedisTemplate<String, TextQuestionAnalysisVo> ObjectiveAnalysisRedisTemplate(RedisConnectionFactory connectionFactory) {
        RedisTemplate<String, TextQuestionAnalysisVo> redisTemplate = new RedisTemplate<>();
        redisTemplate.setConnectionFactory(connectionFactory);

        // 使用Jackson2JsonRedisSerializer将对象序列化为JSON格式
        Jackson2JsonRedisSerializer<TextQuestionAnalysisVo> serializer = new Jackson2JsonRedisSerializer<>(TextQuestionAnalysisVo.class);
        ObjectMapper objectMapper = new ObjectMapper();
        // 注册JavaTimeModule以支持Java 8日期/时间类型
        objectMapper.registerModule(new JavaTimeModule());
        serializer.setObjectMapper(objectMapper);

        redisTemplate.setKeySerializer(new StringRedisSerializer());
        redisTemplate.setValueSerializer(serializer);

        return redisTemplate;
    }

    @Bean(name = "articleRedisTemplate")
    public RedisTemplate<String, ArticleVo> articleRedisTemplate(RedisConnectionFactory connectionFactory) {
        RedisTemplate<String, ArticleVo> redisTemplate = new RedisTemplate<>();
        redisTemplate.setConnectionFactory(connectionFactory);

        // 使用Jackson2JsonRedisSerializer将对象序列化为JSON格式
        Jackson2JsonRedisSerializer<ArticleVo> serializer = new Jackson2JsonRedisSerializer<>(ArticleVo.class);
        ObjectMapper objectMapper = new ObjectMapper();
        // 注册JavaTimeModule以支持Java 8日期/时间类型
        objectMapper.registerModule(new JavaTimeModule());
        serializer.setObjectMapper(objectMapper);

        redisTemplate.setKeySerializer(new StringRedisSerializer());
        redisTemplate.setValueSerializer(serializer);

        return redisTemplate;
    }

    @Bean(name = "integerRedisTemplate")
    public RedisTemplate<String, Integer> integerRedisTemplate(RedisConnectionFactory connectionFactory) {
        RedisTemplate<String, Integer> redisTemplate = new RedisTemplate<>();
        redisTemplate.setConnectionFactory(connectionFactory);
        redisTemplate.setKeySerializer(new StringRedisSerializer());
        // 使用默认的序列化器，这里是JDK序列化器，对于整数来说足够了
        // 如果需要JSON序列化，可以自定义Jackson2JsonRedisSerializer
        // redisTemplate.setValueSerializer(new Jackson2JsonRedisSerializer<>(Integer.class));
        return redisTemplate;
    }
}
