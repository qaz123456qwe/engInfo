package com.nekotaku.questionnairesystem.vo.analysis;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @Title:SurveyAnalysisDto
 * @Author:NekoTaku
 * @Date:2024/03/12 12:34
 * @Version:1.0
 */
@Data
public class SurveyAnalysisVo implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "问卷id")
    private Long surveyId;

    @ApiModelProperty(value = "问卷标题")
    private String surveyTitle;

    @ApiModelProperty(value = "问卷回收数量")
    private Integer surveyCollected;

    @ApiModelProperty(value = "问卷问题和对应选项列表)")
    private List<QuestionAnalysisVo> questions;
}
