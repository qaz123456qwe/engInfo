package com.nekotaku.questionnairesystem.service.impl;

import cn.hutool.core.util.ObjUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.OrderItem;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.nekotaku.questionnairesystem.common.R.ResponseCode;
import com.nekotaku.questionnairesystem.common.R.Result;
import com.nekotaku.questionnairesystem.common.exception.CustomException;
import com.nekotaku.questionnairesystem.common.page.QueryPageParam;
import com.nekotaku.questionnairesystem.entity.Category;
import com.nekotaku.questionnairesystem.entity.Survey;
import com.nekotaku.questionnairesystem.mapper.CategoryMapper;
import com.nekotaku.questionnairesystem.mapper.SurveyMapper;
import com.nekotaku.questionnairesystem.service.CategoryService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

/**
 * <p>
 * 分类表 服务实现类
 * </p>
 *
 * @author nekotaku
 * @since 2023-12-10
 */
@Service
@Slf4j
public class CategoryServiceImpl extends ServiceImpl<CategoryMapper, Category> implements CategoryService {


    @Autowired
    private CategoryMapper categoryMapper;

    @Autowired
    private SurveyMapper surveyMapper;

    /**
     * 添加或者更新分类
     *
     * @param category
     * @return
     */
    @Override
    public Integer saveOrUpdateCategory(Category category) {

        log.info("添加或更新分类名服务");

        // 将分类名去除空格
        category.setCategoryName(category.getCategoryName().trim());

        // 验证当前用户的分类是否存在
        LambdaQueryWrapper<Category> qw = new LambdaQueryWrapper<>();
        // 根据用户id和分类名对比
        qw.eq(Category::getUserId, category.getUserId());
        qw.eq(Category::getCategoryName, category.getCategoryName());
        // 判断是否为修改，修改时排除自身重复判断的情况
        if(!ObjUtil.isNull(category.getCategoryId())){
            qw.ne(Category::getCategoryId,category.getCategoryId());
        }
        if (categoryMapper.selectCount(qw) > 0) {
            return ResponseCode.CATEGORY_EXIST.val();
        }
        // 保存分类
//        int insert = categoryMapper.insert(category);
        boolean res = this.saveOrUpdate(category);
        if (res) {
            return ResponseCode.SUCCESS.val();
        }

        return ResponseCode.FAIL.val();
    }

    /**
     * 查询并分页当前用户的分类(可带条件查询)
     *
     * @param queryPageParam
     * @return
     */
    @Override
    public Page<Category> listCategory(QueryPageParam queryPageParam,Long userId) {
        log.info("查询分类服务");
        Page<Category> categoryPage = new Page<>();
        // 设置当前页
        categoryPage.setCurrent(queryPageParam.getPageNum());
        // 设置当前页面数量
        categoryPage.setSize(queryPageParam.getPageSize());

        // 按照最新数据查询(从后往前面查询)
        categoryPage.setOrders(Arrays.asList(OrderItem.desc("update_time")));

        // 获取条件(判断是否带条件查询)
        HashMap param = queryPageParam.getParam();
        String categoryName = param.get("categoryName").toString();
        LambdaQueryWrapper<Category> qw = new LambdaQueryWrapper<>();
        if (StringUtils.isNotBlank(categoryName) && !"null".equals(categoryName)) {
            // 模糊查询
            qw.like(Category::getCategoryName, categoryName);
        }
        qw.eq(Category::getUserId,userId);

        return this.page(categoryPage, qw);
    }

    /**
     * 删除分类
     *
     * @param id
     * @return
     */
    @Override
    public Integer deleteCategory(String id) {
        log.info("删除分类服务");
        Long categoryId = 0L;
        try {
            // id值转换,检验是否规范
            categoryId = Long.parseLong(id);
        } catch (Exception e) {
            throw new CustomException(ResponseCode.VALUE_INVALID.msg());
        }
        // 检测分类是否被使用
        if (categoryIsUse(categoryId)) {
            // 存在使用分类的问卷 不能删除
            return ResponseCode.CATEGORY_DELETE_FAILED.val();
        }
        LambdaQueryWrapper<Category> qwCategory = new LambdaQueryWrapper<>();
        qwCategory.eq(Category::getCategoryId, categoryId);
        if (categoryMapper.delete(qwCategory) > 0) {
            return ResponseCode.SUCCESS.val();
        }
        return ResponseCode.FAIL.val();
    }

    /**
     * 批量删除分类
     *
     * @param ids
     * @return
     */
    @Override
    @Transactional
    public Result deleteByIds(String ids) {
        log.info("批量删除分类服务");
        // 将ids值转换为Long数组
        List<Long> collect = Arrays.stream(ids.split(","))
                .map(Long::parseLong)
                .collect(Collectors.toList());
        // 检测分类id是否被使用,找到哪些id被使用，返回其分类名信息
//        List<Survey> surveys = surveyMapper.selectBatchIds(collect);
        LambdaQueryWrapper<Survey> qw = new LambdaQueryWrapper<>();
        qw.in(Survey::getSurveyCategoryId,collect);
        List<Survey> surveys = surveyMapper.selectList(qw);
        // 检测分类是否被使用
        if (surveys.size() > 0) {
            LinkedHashSet<Long> longs = new LinkedHashSet<>();
            for (Survey survey : surveys) {
                longs.add(survey.getSurveyCategoryId());
            }
            ArrayList<Long> list = new ArrayList<>(longs);
            // 获取哪些分类名被使用
            List<Category> categories = categoryMapper.selectBatchIds(list);
            List<String> strCategories = categories.stream().map(Category::getCategoryName).collect(Collectors.toList());
            return Result.fail(ResponseCode.CATEGORY_DELETE_FAILED.val(),
                    strCategories + ResponseCode.CATEGORY_DELETE_FAILED.msg());
        }
        // 批量删除分类
        int res = categoryMapper.deleteBatchIds(collect);
        if (res > 0) {
            return Result.success(ResponseCode.SUCCESS.val(), "批量删除分类成功");
        }
        return Result.fail(ResponseCode.FAIL.val(), ResponseCode.FAIL.msg());
    }

    /**
     * 根据用户id获取分类列表
     * @param userId
     * @return
     */
    @Override
    public List<Category> getCategoriesByUserId(Long userId) {
        List<Category> categories = categoryMapper.selectList(new LambdaQueryWrapper<Category>()
                .eq(Category::getUserId, userId));
        return categories;
    }

    /**
     * 判断分类是否被使用，如果被使用不能被随意删除
     *
     * @param categoryId
     * @return
     */
    private boolean categoryIsUse(Long categoryId) {
        LambdaQueryWrapper<Survey> qw = new LambdaQueryWrapper<>();
        // 单个
        qw.eq(Survey::getSurveyCategoryId, categoryId);
        Integer count = surveyMapper.selectCount(qw);
        return count > 0;
    }
}
