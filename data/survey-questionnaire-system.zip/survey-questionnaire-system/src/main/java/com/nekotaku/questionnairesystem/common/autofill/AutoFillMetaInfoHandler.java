package com.nekotaku.questionnairesystem.common.autofill;

import com.baomidou.mybatisplus.core.handlers.MetaObjectHandler;
import com.nekotaku.questionnairesystem.common.enums.ArticleStatus;
import com.nekotaku.questionnairesystem.common.enums.ReportResult;
import com.nekotaku.questionnairesystem.common.enums.ReportStatus;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.reflection.MetaObject;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 自动填充器，填充插入数据时所需要的字段
 *
 * @Title:AutoFillMetaInfoHandler
 * @Author:NekoTaku
 * @Date:2023/12/01 22:25
 * @Version:1.0
 */
@Component
@Slf4j
public class AutoFillMetaInfoHandler implements MetaObjectHandler {

    @Override
    public void insertFill(MetaObject metaObject) {
        this.setFieldValByName("createTime", LocalDateTime.now(), metaObject);
        this.setFieldValByName("updateTime", LocalDateTime.now(), metaObject);

        // 余额填充默认0.00
        this.setFieldValByName("userBalance",BigDecimal.ZERO, metaObject);

        // 填充文章浏览量(0)
        this.setFieldValByName("articleViews", 0L, metaObject);

        // 文章基本状态（初始创建时，都是未撰写内容的默认为-1）
        this.setFieldValByName("articleIsOpen", ArticleStatus.NOT_WRITTEN.getStatusId(), metaObject);

        // 举报次数(首次填充1)
        this.setFieldValByName("reportCount", 1L, metaObject);

        // 举报状态(待审核)
        this.setFieldValByName("reportStatus", ReportStatus.TO_BE_REVIEWED.getStatusId(), metaObject);

        // 举报结果(待处置)
        this.setFieldValByName("reportResult", ReportResult.NO_DISPOSE.getStatusId(), metaObject);
    }

    @Override
    public void updateFill(MetaObject metaObject) {
        this.setFieldValByName("updateTime", LocalDateTime.now(), metaObject);
    }
}
