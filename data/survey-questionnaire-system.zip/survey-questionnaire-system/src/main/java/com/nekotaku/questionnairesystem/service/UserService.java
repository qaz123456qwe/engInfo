package com.nekotaku.questionnairesystem.service;

import com.nekotaku.questionnairesystem.common.R.Result;
import com.nekotaku.questionnairesystem.entity.User;
import com.baomidou.mybatisplus.extension.service.IService;
import com.nekotaku.questionnairesystem.vo.email.EmailVo;

import java.math.BigDecimal;
import java.util.HashMap;

/**
 * <p>
 * 调查问卷系统用户表 服务类
 * </p>
 *
 * @author nekotaku
 * @since 2023-11-20
 */
public interface UserService extends IService<User> {


    Integer getEmailCode(String email,String type);

    Integer register(User user,String code,String type);

    Result login(String account,String password);

    Integer updatePassword(Long userId, String oldPassword, String newPassword);

    Integer changeEmail(Long userId, EmailVo emailVo);

    Integer updateUserInfo(Long userId, String avatar, String nickName);

    HashMap<String, Object> getUserVoMap(Long userId);

    Integer validationCodeForReset(String email, String code);

    Integer resetPassword(String email, String code, String newPassword);

    boolean updateBalance(Long userId, BigDecimal balance);
}
