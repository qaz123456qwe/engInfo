package com.nekotaku.questionnairesystem.entity;

import cn.hutool.core.annotation.Alias;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 模板选项表
 * </p>
 *
 * @author nekotaku
 * @since 2024-03-04
 */
@Data
@EqualsAndHashCode(callSuper = false)
@ApiModel(value="TmpOption对象", description="模板选项表")
public class TmpOption implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "模板选项主键")
    @TableId(value = "tmp_option_id", type = IdType.AUTO)
    @Alias("optionId")
    private Long tmpOptionId;

    @ApiModelProperty(value = "模板问题id")
    @Alias("questionId")
    private Long tmpQuestionId;

    @ApiModelProperty(value = "模板选项内容")
    @Alias("optionContent")
    private String tmpOptionContent;

    @ApiModelProperty(value = "模板选项顺序")
    @Alias("optionSort")
    private Integer tmpOptionSort;


}
