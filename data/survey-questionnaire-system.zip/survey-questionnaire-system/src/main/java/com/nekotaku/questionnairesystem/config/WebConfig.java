package com.nekotaku.questionnairesystem.config;

import com.nekotaku.questionnairesystem.config.interceptor.AuthHandlerInterceptor;
import com.nekotaku.questionnairesystem.utils.JacksonObjectMapper;
import lombok.SneakyThrows;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.util.List;

/**
 * web相关配置类
 *
 * @Title:WebConfig
 * @Author:NekoTaku
 * @Date:2023/11/20 19:19
 * @Version:1.0
 */
@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Autowired
    AuthHandlerInterceptor authHandlerInterceptor;

    @Value("${file.staticAccessPath}")
    private String staticAccessPath;
    @Value("${file.uploadFolder}")
    private String uploadFolder;

    // 图片临时存放的真实路径地址(存放图片的服务器或者主机地址)
    @Value("${file.uploadTempFolder}")
    private String realTempBasePath;

    /**
     * 自定义静态资源的访问路径
     * @param registry
     */
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler(staticAccessPath)
                .addResourceLocations("file:" + uploadFolder)
                .addResourceLocations("file:" + realTempBasePath);
    }

    /**
     * 配置拦截器,拦截转向到 authHandlerInterceptor
     * 接口请求需要验证token
     * 排除一下可以直接访问的接口
     */
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(authHandlerInterceptor)
                .addPathPatterns("/**")
                .excludePathPatterns(
                        "/swagger-resources/**","/webjars/**","/v2/**","/swagger-ui.html/**",
                        "/druid/**",
                        "/user/login","/user/sendEmail",
                        "/user/register", "/user/validationCodeForReset",
                        "/user/resetPassword","/static/**","/asset/**",
                        "/survey/surveyDetailed/{surveyId}","/answer/submit","/survey/listSurveysForFront",
                        "/article/getArticle/{articleId}","/article/update/{articleId}","/article/updateViews/{articleId}","/article/listArticleForFront",
                        "/report-article/report","/report-survey/report",
                        "/front-ad/getOpenNaviImage",
                        "/alipay/**","/survey-bonus/addBonusLog");
    }

    /**
     * 扩展mvc框架的消息转换器
     *
     * @param converters
     */
    @SneakyThrows
    @Override
    public void extendMessageConverters(List<HttpMessageConverter<?>> converters) {
        //创建消息转换器对象
        MappingJackson2HttpMessageConverter messageConverter = new MappingJackson2HttpMessageConverter();
        //设置对象转换器，底层使用Jackson将Java对象转为json
        messageConverter.setObjectMapper(new JacksonObjectMapper());
        //将上面的消息转换器对象追加到mvc框架的转换器集合中
        converters.add(0, messageConverter);
    }

    /**
     * 解决前后端分离跨域问题
     *
     * @param registry
     */
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")
                // 是否发送Cookie
                .allowCredentials(true)
                // 放行哪些原始域
                .allowedOriginPatterns("*")
                // 放行哪些请求方式
                .allowedMethods("GET", "POST", "PUT", "DELETE")
                // 放行哪些原始请求头部信息
                .allowedHeaders("*")
                // 暴露哪些头部信息
                .exposedHeaders("*");
    }
}
