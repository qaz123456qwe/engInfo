package com.nekotaku.questionnairesystem.common.scheduler;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.json.JSONUtil;
import com.nekotaku.questionnairesystem.common.constants.redis.RedisConstants;
import com.nekotaku.questionnairesystem.utils.file.UploadUtils;
import com.nekotaku.questionnairesystem.utils.redis.RedisData;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.Cursor;
import org.springframework.data.redis.core.RedisCallback;
import org.springframework.data.redis.core.ScanOptions;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * 清理临时图片的定时器
 *
 * @Title:ImageTempDelScheduler
 * @Author:NekoTaku
 * @Date:2024/03/27 14:19
 * @Version:1.0
 */
@Component
@Slf4j
public class ImageTempDelScheduler {

    @Autowired
    private UploadUtils uploadUtils;

    @Autowired
    private StringRedisTemplate redisTemplate;


    /**
     * 本地临时图片清理定时器
     * 每天四点清理
     * 表达式从左到右含义
     * 秒：0
     * 分：0
     * 时：4
     * 日期：* （每一天）
     * 月份：* （每个月）
     * 星期：?
     */
    @Scheduled(cron = "0 0 4 * * ?")
//    @Scheduled(fixedRate = 10000)
    @Async("myAsyncExecutor")
    public void checkExpireTime() {
        LocalDateTime currentDateTime = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String formattedTime = currentDateTime.format(formatter);
        log.info("临时图片定时任务执行了:" + formattedTime);

        String pattern = RedisConstants.UPLOAD_FILE + "*";

        // Redis版本2.8.0 以上，使用 SCAN 命令来代替 keys() 方法，
        // 因为SCAN命令是非阻塞的，它可以逐步迭代整个键空间，避免了一次性返回所有匹配键带来的性能问题
        // 模糊匹配查询key
//        Set<String> keys = redisTemplate.keys(pattern);
        Set<String> keys = new LinkedHashSet<>();
        StringRedisSerializer redisSerializer = new StringRedisSerializer();
        redisTemplate.execute((RedisCallback<Void>) connection -> {
            try (Cursor<byte[]> cursor = connection
                    .scan(ScanOptions.scanOptions()
                            .count(Long.MAX_VALUE)
                            .match(pattern).build())) {
                while (cursor.hasNext()) {
                    byte[] next = cursor.next();
                    keys.add(redisSerializer.deserialize(next));
                }
                return null;
            }
        });
        if (!CollUtil.isEmpty(keys) && keys.size() > 0) {
            // 创建自定义线程池
            ExecutorService executorService = Executors.newFixedThreadPool(4);
            for (String key : keys) {
                executorService.submit(() -> {
                    // 取出所有key
                    String data = redisTemplate.opsForValue().get(key);
                    RedisData redisData = JSONUtil.toBean(data, RedisData.class);
                    // 判断key是否过期(当前本地时间大于逻辑过期时间即为过期key)
                    if (LocalDateTime.now().isAfter(redisData.getExpireTime())) {
                        log.info("临时图片定时器清理过期图片路径:{}", redisData.getData().toString());
                        // 清理图片
                        uploadUtils.deleteFileByPath(redisData.getData().toString());
                        // 清理key
                        redisTemplate.delete(key);
                    }
                });
            }
            // 关闭线程池
            executorService.shutdown();
            try {
                // 等待线程池中的任务完成（最多等待 10 分钟）
                if (!executorService.awaitTermination(10, TimeUnit.MINUTES)) {
                    executorService.shutdownNow(); // 超时后强制关闭
                }
            } catch (InterruptedException e) {
                log.info("线程池任务执行超时，强制关闭线程池");
                executorService.shutdownNow(); // 中断异常后强制关闭
            }
        }

    }


}
