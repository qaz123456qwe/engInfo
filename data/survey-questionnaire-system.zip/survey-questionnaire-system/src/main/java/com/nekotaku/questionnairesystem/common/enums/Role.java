package com.nekotaku.questionnairesystem.common.enums;

/**
 * 用户角色
 *
 * @Title:ReportStatus
 * @Author:NekoTaku
 * @Date:2024/04/01 14:09
 * @Version:1.0
 */
public enum Role {

    GENERAL_USER(2, "普通用户"),
    ADMIN_USER(1, "管理员");


    private final int statusId;
    private final String statusName;

    Role(int statusId, String statusName) {
        this.statusId = statusId;
        this.statusName = statusName;
    }

    public int getStatusId() {
        return statusId;
    }

    public String getStatusName() {
        return statusName;
    }

    public static Role getByStatusId(int statusId) {
        for (Role role : values()) {
            if (role.getStatusId() == statusId) {
                return role;
            }
        }
        throw new IllegalArgumentException("无效状态id: " + statusId);
    }

}
