package com.nekotaku.questionnairesystem.utils;

import cn.hutool.core.util.StrUtil;
import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.Claim;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.nekotaku.questionnairesystem.common.enums.Role;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Map;

/**
 * 基于JWT的通用的处理类TokenUtil，负责创建和验证Token
 *
 * @Title:TokenUtil
 * @Author:NekoTaku
 * @Date:2023/11/20 20:17
 * @Version:1.0
 */
@Component
public class TokenUtil {

    // Token密钥
    @Value("${token.secretKey}")
    private String secretKey;

    /**
     * 加密token
     */
    public String getToken(String userId, Integer userRoleId) {
        //这个是放到负载payLoad里面,值可以使用常量类进行封装.
        String token = JWT
                .create()
                .withClaim("userId", userId)
                .withClaim("userRoleId", userRoleId.toString())
                .withClaim("timeStamp", System.currentTimeMillis())
                .sign(Algorithm.HMAC256(secretKey));
        return token;
    }

    /**
     * 解析token
     */
    public Map<String, String> parseToken(String token) {
        token = token.substring(7);
        HashMap<String, String> map = new HashMap<String, String>();
        DecodedJWT decodedjwt = JWT.require(Algorithm.HMAC256(secretKey))
                .build().verify(token);
        Claim userId = decodedjwt.getClaim("userId");
        Claim userRole = decodedjwt.getClaim("userRoleId");
        Claim timeStamp = decodedjwt.getClaim("timeStamp");
        map.put("userId", userId.asString());
        map.put("userRoleId", userRole.asString());
        map.put("timeStamp", timeStamp.asLong().toString());
        return map;
    }

    /**
     * 根据HttpServletRequest携带的token获取用户id
     *
     * @param httpServletRequest
     * @return
     */
    public Long getUserIdFromToken(HttpServletRequest httpServletRequest) {
        String token = httpServletRequest.getHeader("Authorization");
        if (token == null || token.isEmpty()) {
            // 处理 token 为空的情况，例如抛出异常或返回默认值
            return null;
        }
        Map<String, String> map = parseToken(token);
        if (map == null || map.isEmpty()) {
            // 处理解析 token 失败的情况，例如抛出异常或返回默认值
            return null;
        }
        String userIdStr = map.get("userId");
        if (userIdStr == null || userIdStr.isEmpty()) {
            // 处理 "userId" 键不存在的情况，例如抛出异常或返回默认值
            return null;
        }
        try {
            return Long.parseLong(userIdStr);
        } catch (NumberFormatException e) {
            // 处理 "userId" 不是数字的情况，例如抛出异常或返回默认值
            return null;
        }
    }

    /**
     * 根据携带的token检测是否为管理员
     * 如果没有携带token依旧检测为非管理员
     *
     * @param httpServletRequest
     * @return
     */
    public boolean checkIsAdmin(HttpServletRequest httpServletRequest) {
        String token = httpServletRequest.getHeader("Authorization");
        return StrUtil.isNotBlank(token) &&
                Integer.parseInt(parseToken(token).get("userRoleId"))
                        == Role.ADMIN_USER.getStatusId();
    }
}
