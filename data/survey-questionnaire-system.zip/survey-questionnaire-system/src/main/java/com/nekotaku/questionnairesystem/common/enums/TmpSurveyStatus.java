package com.nekotaku.questionnairesystem.common.enums;

public enum TmpSurveyStatus {

    DESIGNED(1, "已设计"),

    UN_DESIGNED(0, "未设计");

    private final int statusId;
    private final String statusName;

    TmpSurveyStatus(int statusId, String statusName) {
        this.statusId = statusId;
        this.statusName = statusName;
    }

    public int getStatusId() {
        return statusId;
    }

    public String getStatusName() {
        return statusName;
    }

    public static TmpSurveyStatus getByStatusId(int statusId) {
        for (TmpSurveyStatus status : values()) {
            if (status.getStatusId() == statusId) {
                return status;
            }
        }
        throw new IllegalArgumentException("无效状态id: " + statusId);
    }
}
