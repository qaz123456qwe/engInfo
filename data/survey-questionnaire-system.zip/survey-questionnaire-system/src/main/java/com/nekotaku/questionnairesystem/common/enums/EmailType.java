package com.nekotaku.questionnairesystem.common.enums;

/**
 * 邮箱作用枚举
 */
public enum EmailType {

    // 注册
    REGISTER("register"),

    // 邮箱换绑(旧邮箱验证码)
    CHANGE_EMAIL_OLD("changeEmailOld"),

    // 邮箱换绑(新邮箱验证码)
    CHANGE_EMAIL_NEW("changeEmailNew"),

    // 密码重置
    RESET_PASSWORD("resetPassword"),

    // 封禁
    BAN("Ban"),

    // 申述
    APPEAL("Appeal"),

    // 申诉成功
    APPEAL_SUCCESS("AppealSuccess"),

    // 申诉失败
    APPEAL_FALSE("AppealFalse");


    private final String typeName;

    EmailType(String typeName) {
        this.typeName = typeName;
    }

    public String getTypeName() {
        return typeName;
    }
}
