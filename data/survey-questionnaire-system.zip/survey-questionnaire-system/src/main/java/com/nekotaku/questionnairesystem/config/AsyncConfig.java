package com.nekotaku.questionnairesystem.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.Executor;

/**
 * 自定义@Async异步注解的线程池
 *
 * @Title:AsyncConfig
 * @Author:NekoTaku
 * @Date:2024/04/30 8:46
 * @Version:1.0
 */
@Configuration
public class AsyncConfig {

    @Bean(name = "myAsyncExecutor")
    public Executor myAsyncExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(5); // 核心线程数
        executor.setMaxPoolSize(10); // 最大线程数
        executor.setQueueCapacity(25); // 队列容量
        executor.setThreadNamePrefix("MyAsync-"); // 线程名称前缀
        executor.initialize();
        return executor;
    }
}
