package com.nekotaku.questionnairesystem.common.enums;

/**
 * 问卷状态枚举
 *
 * @Title:SurveyStatus
 * @Author:NekoTaku
 * @Date:2024/01/29 16:28
 * @Version:1.0
 */
public enum SurveyStatus {
    PUBLISHED(1, "发布中"),
    COMPLETED(2, "完成"),
    UN_PUBLISHED(0, "未发布"),
    PAUSED(-1, "暂停"),
    UN_DESIGNED(-2, "未设计"),
    UN_STARTED(3, "未开始"),

    SURVEY_BAN(4, "被封禁"),
    SURVEY_AUDIT(5,"待审核"),
    SURVEY_APPEAL_SUCCESS(6,"审核通过");

    private final int statusId;
    private final String statusName;

    SurveyStatus(int statusId, String statusName) {
        this.statusId = statusId;
        this.statusName = statusName;
    }

    public int getStatusId() {
        return statusId;
    }

    public String getStatusName() {
        return statusName;
    }

    public static SurveyStatus getByStatusId(int statusId) {
        for (SurveyStatus status : values()) {
            if (status.getStatusId() == statusId) {
                return status;
            }
        }
        throw new IllegalArgumentException("无效状态id: " + statusId);
    }
}
