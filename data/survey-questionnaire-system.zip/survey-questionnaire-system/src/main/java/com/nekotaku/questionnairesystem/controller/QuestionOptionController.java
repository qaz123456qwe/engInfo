package com.nekotaku.questionnairesystem.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 选项表，对应问卷问题的选择题 前端控制器
 * </p>
 *
 * @author nekotaku
 * @since 2024-01-29
 */
@RestController
@RequestMapping("/question-option")
public class QuestionOptionController {

}
