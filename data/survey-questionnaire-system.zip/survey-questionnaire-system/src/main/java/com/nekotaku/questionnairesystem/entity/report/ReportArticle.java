package com.nekotaku.questionnairesystem.entity.report;

import java.io.Serializable;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 文章举报表
 * </p>
 *
 * @author nekotaku
 * @since 2024-04-01
 */
@Data
@EqualsAndHashCode(callSuper = false)
@ApiModel(value="ReportArticle对象", description="")
public class ReportArticle extends BaseReport implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "被举报的文章id")
    private Long reportArticleId;

    @ApiModelProperty(value = "被举报的文章标题")
    private String reportArticleTitle;



}
