package com.nekotaku.questionnairesystem.mapper;

import com.nekotaku.questionnairesystem.entity.FrontAd;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author nekotaku
 * @since 2024-05-12
 */
@Mapper
public interface FrontAdMapper extends BaseMapper<FrontAd> {

}
