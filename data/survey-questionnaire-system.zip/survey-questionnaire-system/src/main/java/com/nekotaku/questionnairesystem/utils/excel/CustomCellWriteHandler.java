package com.nekotaku.questionnairesystem.utils.excel;

import com.alibaba.excel.metadata.CellData;
import com.alibaba.excel.metadata.Head;
import com.alibaba.excel.write.handler.CellWriteHandler;
import com.alibaba.excel.write.metadata.holder.WriteSheetHolder;
import com.alibaba.excel.write.metadata.holder.WriteTableHolder;
import com.alibaba.excel.write.style.AbstractCellStyleStrategy;
import org.apache.poi.ss.usermodel.*;

import java.util.List;

/**
 * 自定义拦截，写入头部样式
 *
 * @Title:CustomCellWriteHandler
 * @Author:NekoTaku
 * @Date:2024/03/16 17:33
 * @Version:1.0
 */
public class CustomCellWriteHandler extends AbstractCellStyleStrategy implements CellWriteHandler {
    Workbook workbook;

    @Override
    public void beforeCellCreate(WriteSheetHolder writeSheetHolder, WriteTableHolder writeTableHolder, Row row, Head head, Integer columnIndex, Integer relativeRowIndex, Boolean isHead) {
        super.beforeCellCreate(writeSheetHolder, writeTableHolder, row, head, columnIndex, relativeRowIndex, isHead);
    }

    @Override
    public void afterCellDispose(WriteSheetHolder writeSheetHolder, WriteTableHolder writeTableHolder, List<CellData> cellDataList, Cell cell, Head head, Integer relativeRowIndex, Boolean isHead) {
        super.afterCellDispose(writeSheetHolder, writeTableHolder, cellDataList, cell, head, relativeRowIndex, isHead);

        Sheet sheet = writeSheetHolder.getSheet();

        // 获取当前列的索引
        int columnIndex = cell.getColumnIndex();

        // 获取当前列的内容
        String cellValue = cell.getStringCellValue();

        // 如果内容为空，则不调整列宽
        if (cellValue == null || cellValue.isEmpty()) {
            return;
        }

        // 获取当前列的宽度
        // 每个英文字符的宽度为256,中文字符是2倍
        int contentWidth = cellValue.getBytes().length * 256 * 2;

        // 如果当前列的宽度大于已记录的宽度，则更新宽度
        int currentColumnWidth = sheet.getColumnWidth(columnIndex);
        if (currentColumnWidth < contentWidth) {
            sheet.setColumnWidth(columnIndex, contentWidth);
        }
    }

    @Override
    public void afterCellCreate(WriteSheetHolder writeSheetHolder, WriteTableHolder writeTableHolder, Cell cell, Head head, Integer relativeRowIndex, Boolean isHead) {
        this.initCellStyle(writeSheetHolder.getSheet().getWorkbook());
        this.setHeadCellStyle(cell, head, relativeRowIndex);
    }

    @Override
    protected void initCellStyle(Workbook workbook) {
        this.workbook = workbook;
    }

    @Override
    protected void setHeadCellStyle(Cell cell, Head head, Integer integer) {
        //第一行样式
        if (cell.getRowIndex() == 0) {
            cell.setCellStyle(EasyExcelUtils.getColumnTopStyle(workbook, 20));
        }
        //大于第二行的
        if (cell.getRowIndex() >= 1) {
            cell.setCellStyle(EasyExcelUtils.getColumnContentStyle(workbook, 14));
        }

        // 设置左右居中
        cell.getCellStyle().setAlignment(HorizontalAlignment.CENTER);
        // 设置上下居中
        cell.getCellStyle().setVerticalAlignment(VerticalAlignment.CENTER);

    }

    @Override
    protected void setContentCellStyle(Cell cell, Head head, Integer integer) {
    }
}
