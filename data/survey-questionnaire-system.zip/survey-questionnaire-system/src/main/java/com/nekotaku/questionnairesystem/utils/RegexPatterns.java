package com.nekotaku.questionnairesystem.utils;

/**
 * @Title:RegexPatterns
 * @Author:NekoTaku
 * @Date:2023/11/29 23:44
 * @Version:1.0
 */
public abstract class RegexPatterns {

    /**
     * 用户名正则
     */
    public static final String USERNAME_REGEX = "^(?=.{6,})(?!.*\\s).*$";

    /**
     * 密码正则
     */
    public static final String PASSWORD_REGEX = "^(?=.*\\d)(?=.*[a-zA-Z]).{6,18}$";

    /**
     * 字符串不能有空格
     */
    public static final String STRING_NO_SPACE = "^\\S*$";

    /**
     * 匹配<img>标签的src属性 找到图片路径
     */
    public static final String IMG_REGEX = "<img\\s+[^>]*src\\s*=\\s*['\"]([^'\"]+)['\"][^>]*>";


    /**
     * 匹配手机号
     */
    public static final String PHONE = "^1[3-9]\\d{9}$";


}
