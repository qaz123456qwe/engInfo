package com.nekotaku.questionnairesystem.service;

import com.nekotaku.questionnairesystem.entity.QuestionOption;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 * 选项表，对应问卷问题的选择题 服务类
 * </p>
 *
 * @author nekotaku
 * @since 2024-01-29
 */
public interface QuestionOptionService extends IService<QuestionOption> {

    List<QuestionOption> getQuestionOptionsByQuestionId(Long questionId);

    void deleteOptionsByQuestionId(Long questionId);
}
