package com.nekotaku.questionnairesystem.vo.analysis;

import com.nekotaku.questionnairesystem.entity.QuestionOption;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 选择题答案分析基本信息，包含问题和选项内容以及每个选项选择的数量
 *
 * @Title:AnswerAnalysisDto
 * @Author:NekoTaku
 * @Date:2024/03/12 11:04
 * @Version:1.0
 */
@Data
public class OptionAnalysisVo extends QuestionOption {

    @ApiModelProperty(value = "选项选择的数量")
    private Integer AnswerCount;
}
