package com.nekotaku.questionnairesystem.vo.excel;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.nekotaku.questionnairesystem.utils.excel.EasyExcelLocalDateTimeConverter;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * 实现excel表一对多关系
 *
 * @Title:ExcelAnswerVo
 * @Author:NekoTaku
 * @Date:2024/03/16 16:25
 * @Version:1.0
 */
@Data
public class ExcelAnswerVo {

    @ColumnWidth(50)
    @ExcelProperty(value = "回答")
    private String answerContext;

    @ColumnWidth(50)
    @ExcelProperty(value = "完成时间",converter = EasyExcelLocalDateTimeConverter.class)
    private LocalDateTime createTime;
}
