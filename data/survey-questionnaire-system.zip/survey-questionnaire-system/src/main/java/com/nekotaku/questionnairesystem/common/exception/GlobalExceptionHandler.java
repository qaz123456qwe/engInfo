package com.nekotaku.questionnairesystem.common.exception;

import com.nekotaku.questionnairesystem.common.R.ResponseCode;
import com.nekotaku.questionnairesystem.common.R.Result;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.BindException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * 全局异常处理器
 * 当控制器方法的参数校验失败时抛出
 *
 * @Title:GlobalExceptionHandler
 * @Author:NekoTaku
 * @Date:2023/11/29 22:51
 * @Version:1.0
 */
@RestControllerAdvice
@Slf4j
public class GlobalExceptionHandler {

    // <1> 处理 form data方式调用接口校验失败抛出的异常
    @ExceptionHandler(BindException.class)
    public Result bindExceptionHandler(BindException e) {
        List<FieldError> fieldErrors = e.getBindingResult().getFieldErrors();
        List<String> collect = fieldErrors.stream()
                .map(o -> o.getDefaultMessage())
                .collect(Collectors.toList());
        return returnHandler(collect.get(0));
    }

    // <2> 处理 json 请求体调用接口校验失败抛出的异常
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public Result methodArgumentNotValidExceptionHandler(MethodArgumentNotValidException e) {
        List<FieldError> fieldErrors = e.getBindingResult().getFieldErrors();
        List<String> collect = fieldErrors.stream()
                .map(o -> o.getDefaultMessage())
                .collect(Collectors.toList());
        return returnHandler(collect.get(0));
    }

    // <3> 处理单个参数校验失败抛出的异常
    @ExceptionHandler(ConstraintViolationException.class)
    public Result constraintViolationExceptionHandler(ConstraintViolationException e) {
        Set<ConstraintViolation<?>> constraintViolations = e.getConstraintViolations();
        List<String> collect = constraintViolations.stream()
                .map(o -> o.getMessage())
                .collect(Collectors.toList());
        return returnHandler(collect.get(0));
    }

    // 处理自定义异常
    @ExceptionHandler(value = CustomException.class)
    public Result exceptionHandler(CustomException e) {
        // 获取异常值
        int exCode = Integer.parseInt(e.getMessage());
        // 根据异常值，获取具体异常信息
        String msg = ResponseCode.getMsgByVal(exCode);
        log.warn(msg);
        return Result.fail(exCode, msg);
    }


    // 全局异常捕获处理
    @ExceptionHandler(Exception.class)
    public Result handleException(Exception e) {
        log.error(e.getMessage());
        return Result.fail(ResponseCode.FAIL.val(), ResponseCode.FAIL.msg());
    }

    // 处理错误信息code
    private Result returnHandler(String code) {
        int resCode = Integer.parseInt(code);
        return Result.fail(resCode, ResponseCode.getMsgByVal(resCode));
    }

}
