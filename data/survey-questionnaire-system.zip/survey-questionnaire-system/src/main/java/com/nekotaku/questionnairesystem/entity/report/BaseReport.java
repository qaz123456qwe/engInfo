package com.nekotaku.questionnairesystem.entity.report;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * <p>
 * 举报信息基础父类
 * </p>
 *
 * @author nekotaku
 * @since 2024-04-01
 */
@Data
@EqualsAndHashCode(callSuper = false)
@ApiModel(value = "BaseReport对象", description = "基础举报父类")
public class BaseReport implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "举报id")
    @TableId(value = "report_id", type = IdType.AUTO)
    protected Long reportId;

    @ApiModelProperty(value = "被举报者的用户名")
    protected String userName;

    @ApiModelProperty(value = "被举报的次数")
    @TableField(fill = FieldFill.INSERT)
    protected Long reportCount;

    @ApiModelProperty(value = "举报的理由")
    protected String reportReason;

    @ApiModelProperty(value = "举报审核状态(0：待审核，1：已审核处置，2：作者整改重申)")
    @TableField(fill = FieldFill.INSERT)
    protected Integer reportStatus;

    @ApiModelProperty(value = "审核处置结果(1：正常，2：封禁)")
    @TableField(fill = FieldFill.INSERT)
    protected Integer reportResult;

    @ApiModelProperty(value = "创建和更新时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
    @TableField(fill = FieldFill.INSERT_UPDATE)
    protected LocalDateTime updateTime;

}
