package com.nekotaku.questionnairesystem.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.OrderItem;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.nekotaku.questionnairesystem.common.enums.QuestionType;
import com.nekotaku.questionnairesystem.common.page.QueryPageParam;
import com.nekotaku.questionnairesystem.vo.QuestionVo;
import com.nekotaku.questionnairesystem.vo.SurveyAndQuestionVo;
import com.nekotaku.questionnairesystem.vo.SurveyMonthlyCountVo;
import com.nekotaku.questionnairesystem.entity.Answer;
import com.nekotaku.questionnairesystem.entity.SurveyFinishLog;
import com.nekotaku.questionnairesystem.mapper.SurveyFinishLogMapper;
import com.nekotaku.questionnairesystem.service.SurveyFinishLogService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

/**
 * <p>
 * 问卷每完成一份的日志 服务实现类
 * </p>
 *
 * @author nekotaku
 * @since 2024-02-29
 */
@Service
public class SurveyFinishLogServiceImpl extends ServiceImpl<SurveyFinishLogMapper, SurveyFinishLog> implements SurveyFinishLogService {

    @Autowired
    private SurveyFinishLogMapper surveyFinishLogMapper;

    /**
     * 统计每月收集的问卷份数
     *
     * @param userId
     * @return
     */
    @Override
    public List<SurveyMonthlyCountVo> selectSurveyFinishByMonth(Long userId) {
        return surveyFinishLogMapper.selectSurveyFinishByMonth(userId);
    }

    /**
     * 分页查询所有记录
     *
     * @param queryPageParam
     * @param userId
     * @return
     */
    @Override
    public Page<SurveyFinishLog> listSurveyLog(QueryPageParam queryPageParam, Long userId) {

        Page<SurveyFinishLog> surveyFinishLogPage = new Page<>();
        // 设置当前页
        surveyFinishLogPage.setCurrent(queryPageParam.getPageNum());
        // 设置当前页面数量
        surveyFinishLogPage.setSize(queryPageParam.getPageSize());

        // 按照最新数据查询(从后往前面查询)
        surveyFinishLogPage.setOrders(Arrays.asList(OrderItem.desc("create_time")));

        // 条件判断
        HashMap param = queryPageParam.getParam();
        String surveyFinishStartTime = param.get("surveyFinishStartTime").toString();
        String surveyFinishEndTime = param.get("surveyFinishEndTime").toString();

        LambdaQueryWrapper<SurveyFinishLog> qw = new LambdaQueryWrapper<>();

        // 定义日期时间格式
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

        // 按照时间条件查询
        if (StringUtils.isNotBlank(surveyFinishStartTime) && !"null".equals(surveyFinishStartTime)) {
            // 将字符串解析为LocalDateTime对象
            LocalDateTime dateTime = LocalDateTime.parse(surveyFinishStartTime, formatter);
            // 大于等于开始时间的记录
            qw.ge(SurveyFinishLog::getCreateTime, dateTime);
        }

        if (StringUtils.isNotBlank(surveyFinishEndTime) && !"null".equals(surveyFinishEndTime)) {
            LocalDateTime dateTime = LocalDateTime.parse(surveyFinishEndTime, formatter);
            // 小于等于结束时间的记录
            qw.le(SurveyFinishLog::getCreateTime, dateTime);
        }

        // 问卷id
        String surveyId = param.get("surveyId").toString();
        if (StringUtils.isNotBlank(surveyId) && !"null".equals(surveyId)) {
            qw.eq(SurveyFinishLog::getSurveyId, Long.parseLong(surveyId));
        }

        return this.page(surveyFinishLogPage, qw);
    }

    /**
     * 为完成的问卷设置对应的用户填写的答案
     *
     * @param surveyDetailedById
     * @return
     */
    @Override
    public SurveyAndQuestionVo setAnswerForQuestion(SurveyAndQuestionVo surveyDetailedById, List<Answer> answerList) {

        // 获取问题列表
        List<QuestionVo> questions = surveyDetailedById.getQuestions();

        for (QuestionVo question : questions) {
            // 通过问题id查询对应选择的答案,使用JDK8新特性 stream流
            List<Answer> answers = answerList.stream()
                    .filter(answer -> question.getQuestionId()
                            .equals(answer.getQuestionId())).collect(Collectors.toList());
            // 单选题
            if (question.getQuestionType() == QuestionType.SINGLE_CHOICE.getTypeId()) {
                // 只需要取list第一个元素即可，因为只有一个数据，设置选择的选项id
                question.setAnswerContext(answers.get(0).getOptionId().toString());
            }
            // 客观题与单选题同理，设置选择的选项内容
            if (question.getQuestionType() == QuestionType.TEXTAREA.getTypeId()) {
                // 只需要取list第一个元素即可，因为只有一个数据，设置选择的选项id
                question.setAnswerContext(answers.get(0).getAnswerContext());
            }
            // 多选题，需要设置多个选择的选项，放入一个list
            if (question.getQuestionType() == QuestionType.MULTIPLE_CHOICE.getTypeId()) {
                List<Long> longs = new ArrayList<>();
                for (Answer answer : answers) {
                    longs.add(answer.getOptionId());
                }
                // 设置多选答案
                question.setAnswersContext(longs);
            }
        }
        // 重新设置并返回
        surveyDetailedById.setQuestions(questions);
        return surveyDetailedById;
    }

    /**
     * 根据文件id批量删除问卷完成表
     *
     * @param reportSurveyId
     */
    @Override
    public void deleteBySurveyId(Long reportSurveyId) {
        LambdaQueryWrapper<SurveyFinishLog> qw = new LambdaQueryWrapper<>();
        qw.eq(SurveyFinishLog::getSurveyId,reportSurveyId);
        surveyFinishLogMapper.delete(qw);
    }

}
