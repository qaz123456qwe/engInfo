package com.nekotaku.questionnairesystem.vo.excel.dto;

import lombok.Data;

import java.util.List;


/**
 * 带选择题的答案的导出ExcelDto类
 *
 * @Title:BaseMore
 * @Author:NekoTaku
 * @Date:2024/03/30 17:38
 * @Version:1.0
 */
@Data
public class ExportDto {

    private Long surveyFinishLogId;

    private List<ExportDataBase> bases;
}
