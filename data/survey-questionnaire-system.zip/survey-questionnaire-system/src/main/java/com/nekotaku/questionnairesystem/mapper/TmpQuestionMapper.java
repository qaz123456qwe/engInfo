package com.nekotaku.questionnairesystem.mapper;

import com.nekotaku.questionnairesystem.vo.QuestionTmpVo;
import com.nekotaku.questionnairesystem.entity.TmpQuestion;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * <p>
 * 模板问卷问题表 Mapper 接口
 * </p>
 *
 * @author nekotaku
 * @since 2024-03-04
 */
@Mapper
public interface TmpQuestionMapper extends BaseMapper<TmpQuestion> {

    List<QuestionTmpVo> getQuestionsAndOptionsByTmpId(Long tmpId);

}
