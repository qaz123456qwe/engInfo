package com.nekotaku.questionnairesystem.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.nekotaku.questionnairesystem.common.page.QueryPageParam;
import com.nekotaku.questionnairesystem.entity.report.ReportArticle;
import com.nekotaku.questionnairesystem.entity.report.ReportSurvey;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 问卷举报信息表 服务类
 * </p>
 *
 * @author nekotaku
 * @since 2024-04-05
 */
public interface ReportSurveyService extends IService<ReportSurvey> {

    Integer saveOrUpdateArticleReport(ReportSurvey reportSurvey, boolean isAdmin);

    Page<ReportSurvey> listReportSurvey(QueryPageParam queryPageParam);

    Integer appealSurvey(Long userId, Long surveyId);

    Integer delReportSurvey(Long surveyId);
}
