package com.nekotaku.questionnairesystem.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;

import com.nekotaku.questionnairesystem.common.R.ResponseConstants;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotBlank;

/**
 * <p>
 * 问卷问题表
 * </p>
 *
 * @author nekotaku
 * @since 2024-01-27
 */
@Data
@EqualsAndHashCode(callSuper = false)
@ApiModel(value="Question对象", description="问卷问题表")
public class Question implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "问题id")
    @TableId(value = "question_id")
    private Long questionId;

    @ApiModelProperty(value = "所属的问卷id")
    private Long surveyId;

    @ApiModelProperty(value = "问卷类型id(1单选、2多选、3客观题)")
    private Integer questionType;

    @ApiModelProperty(value = "问题内容")
    private String questionContent;

    @ApiModelProperty(value = "题目序号")
    private Integer questionSort;

}
