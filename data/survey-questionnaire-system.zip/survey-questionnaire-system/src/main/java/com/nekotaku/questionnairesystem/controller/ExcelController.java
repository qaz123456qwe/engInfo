package com.nekotaku.questionnairesystem.controller;

import com.alibaba.excel.EasyExcel;
import com.nekotaku.questionnairesystem.utils.excel.CustomCellWriteHandler;
import com.nekotaku.questionnairesystem.utils.excel.ExcelFillCellMergeStrategy;
import com.nekotaku.questionnairesystem.vo.analysis.TextQuestionAnalysisVo;
import com.nekotaku.questionnairesystem.service.AnswerService;
import com.nekotaku.questionnairesystem.vo.excel.ExcelWithChoiceVo;
import com.nekotaku.questionnairesystem.vo.excel.dto.ExportDataBase;
import com.nekotaku.questionnairesystem.vo.excel.dto.ExportDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * @Title:ExcelController
 * @Author:NekoTaku
 * @Date:2024/03/16 14:38
 * @Version:1.0
 */
@RestController
@RequestMapping("/excel")
public class ExcelController {

    @Autowired
    private AnswerService answerService;

    /**
     * 将客观题详细回答列表导出成excel (基本导出)
     *
     * @param surveyId
     * @param response
     * @return
     * @throws IOException
     */
    @GetMapping("/exportTextAnalysis/{surveyId}")
    public void exportTextAnalysis(@PathVariable("surveyId") Long surveyId, HttpServletResponse response)
            throws IOException {
        List<TextQuestionAnalysisVo> textAnswerList = answerService.getTextAnswerContextList(surveyId);
        if (textAnswerList.isEmpty()) {
            response.setStatus(HttpStatus.BAD_REQUEST.value());
            response.getWriter().write("当前问卷无客观题回答，无法导出Excel文件");
            return;
        }
        // 设置响应头
        response.setContentType("application/vnd.ms-excel");
        // 设置字符编码
        response.setCharacterEncoding("utf-8");
        // 设置响应头
        String fileName = new String("客观题分析.xlsx".getBytes(), StandardCharsets.ISO_8859_1);
        response.setHeader("Content-disposition", "attachment;filename=" + fileName);

        // 需要合并的列
        int[] mergeColumnIndex = {0};
        // 需要从第一行开始，列头第一行
        int mergeRowIndex = 1;

        // 导出excel
        EasyExcel.write(response.getOutputStream(), TextQuestionAnalysisVo.class)
                .sheet("客观题列表")
                // 自定义的表头拦截
                .registerWriteHandler(new CustomCellWriteHandler())
                // 合并单元格拦截器
                .registerWriteHandler(new ExcelFillCellMergeStrategy(mergeRowIndex, mergeColumnIndex))
                .doWrite(textAnswerList);
    }

    /**
     * 将客观题和选择题详细回答列表导出成excel (高级导出)
     *  只有问卷有选择题存在的时候才可以使用
     * @param surveyId
     * @param response
     * @return
     * @throws IOException
     */
    @GetMapping("/exportTextWithChoice/{surveyId}")
    public void exportTextWithChoice(@PathVariable("surveyId") Long surveyId, HttpServletResponse response)
            throws IOException {

        // 获取选择题和客观题的问题和答案选项
        List<ExcelWithChoiceVo> textWithChoiceAnswer = answerService.getTextWithChoiceAnswer(surveyId);

        // 检查是否有选择题，如果没有选择题不能导出带选择题的Excel
        boolean isHasChoice = textWithChoiceAnswer.stream().anyMatch(e -> e.getOptionContents() != null);
        if (!isHasChoice) {
            // 没有选择题
            response.setStatus(HttpStatus.BAD_REQUEST.value());
            response.getWriter().write("当前问卷无选择题，无法导出Excel文件");
            return;
        }

        // 转换为DTO
        List<ExportDto> exportDtos = answerService.ExcelWithChoiceVoConvertToExportDto(textWithChoiceAnswer);

        // 设置响应头
        response.setContentType("application/vnd.ms-excel");
        // 设置字符编码
        response.setCharacterEncoding("utf-8");
        // 设置响应头
        String fileName = new String("客观题(包括选择题)详细分析.xlsx".getBytes(), StandardCharsets.ISO_8859_1);
        response.setHeader("Content-disposition", "attachment;filename=" + fileName);

        // 导出
        EasyExcel.write(response.getOutputStream())
                .sheet("客观题(包括选择题)详细分析")
                .head(getHead(exportDtos))
                .registerWriteHandler(new CustomCellWriteHandler())
                .doWrite(convertToExportDataList(exportDtos));
    }

    /**
     * 获取需要设置的表头：动态设置Excel表头
     *
     * @param exportDtos
     * @return
     */
    public static List<List<String>> getHead(List<ExportDto> exportDtos) {
        List<List<String>> head = new ArrayList<>();
        if (!exportDtos.isEmpty()) {
            List<ExportDataBase> bases = exportDtos.get(0).getBases();
            for (ExportDataBase basis : bases) {
                ArrayList<String> strings = new ArrayList<>();
                strings.add(basis.getQuestionContent());
                head.add(strings);
            }
        }
        return head;
    }

    /**
     * 将嵌套的列表数据转换成适合导出的数据格式
     *
     * @param dataList
     * @return
     */
    private static List<List<String>> convertToExportDataList(List<ExportDto> dataList) {
        List<List<String>> list = new ArrayList<>();
        if (!dataList.isEmpty()) {
            for (int i = 0; i < dataList.size(); i++) {
                List<String> firstRow = new ArrayList<>();
                for (ExportDataBase base : dataList.get(i).getBases()) {
                    firstRow.add(base.getAnswerContent());
                }
                list.add(firstRow);
            }
        }
        return list;
    }


}
