package com.nekotaku.questionnairesystem.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.nekotaku.questionnairesystem.common.page.QueryPageParam;
import com.nekotaku.questionnairesystem.entity.FrontAd;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author nekotaku
 * @since 2024-05-12
 */
public interface FrontAdService extends IService<FrontAd> {

    Integer saveOrUpdateAdInfo(FrontAd frontAd,Long userId);

    Page<FrontAd> listFrontAdList(QueryPageParam queryPageParam);

    Integer openNaviImage(FrontAd frontAd);

    List<FrontAd> getOpenNaviImage();

    Integer deleteAdInfo(String adId);
}
