package com.nekotaku.questionnairesystem.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.nekotaku.questionnairesystem.common.page.QueryPageParam;
import com.nekotaku.questionnairesystem.entity.SurveyBonus;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 奖励记录表 服务类
 * </p>
 *
 * @author nekotaku
 * @since 2024-05-12
 */
public interface SurveyBonusService extends IService<SurveyBonus> {

    Integer addBonusLog(SurveyBonus surveyBonus);

    Page<SurveyBonus> listSurveyBonus(QueryPageParam queryPageParam, Long userId);
}
