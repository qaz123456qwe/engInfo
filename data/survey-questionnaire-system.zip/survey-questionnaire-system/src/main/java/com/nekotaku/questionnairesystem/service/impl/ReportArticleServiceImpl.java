package com.nekotaku.questionnairesystem.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.OrderItem;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.nekotaku.questionnairesystem.common.R.ResponseCode;
import com.nekotaku.questionnairesystem.common.enums.ArticleStatus;
import com.nekotaku.questionnairesystem.common.enums.ReportResult;
import com.nekotaku.questionnairesystem.common.enums.ReportStatus;
import com.nekotaku.questionnairesystem.common.page.QueryPageParam;
import com.nekotaku.questionnairesystem.entity.Article;
import com.nekotaku.questionnairesystem.entity.report.ReportArticle;
import com.nekotaku.questionnairesystem.entity.User;
import com.nekotaku.questionnairesystem.mapper.ReportArticleMapper;
import com.nekotaku.questionnairesystem.service.ArticleService;
import com.nekotaku.questionnairesystem.service.ReportArticleService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.nekotaku.questionnairesystem.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Arrays;
import java.util.HashMap;

/**
 * <p>
 * 文章举报表 服务实现类
 * </p>
 *
 * @author nekotaku
 * @since 2024-04-01
 */
@Service
public class ReportArticleServiceImpl extends ServiceImpl<ReportArticleMapper, ReportArticle> implements ReportArticleService {

    @Autowired
    private ReportArticleMapper reportArticleMapper;

    @Autowired
    private ArticleService articleService;

    @Autowired
    private UserService userService;

    /**
     * 文章举报信息
     * 加synchronized保证线程同步，防止举报时，已经审核ban了之后的同时，又重新举报
     * 注意：synchronized关键字加在方法上，会锁住整个方法，如果并发量高，可能会影响性能
     * （实际上涉及到高并发操作应该使用乐观锁和悲观锁之类的方案来解决）
     *
     * @param reportArticle
     * @param reportArticle isAdmin 是否是管理员操作审核
     * @return
     */
    @Override
    @Transactional
    public synchronized Integer saveOrUpdateArticleReport(ReportArticle reportArticle, Boolean isAdmin) {

        // 管理员进行审核操作
        if (isAdmin && BeanUtil.isNotEmpty(reportArticle.getReportId())) {
            return this.approvalArticle(reportArticle);
        }

        // 判断举报文章是否存在，是否已经被封禁
        Article byId = articleService.getById(reportArticle.getReportArticleId());
        if (BeanUtil.isEmpty(byId) || byId.getArticleIsOpen().equals(ArticleStatus.ARTICLE_BAN.getStatusId())) {
            // 文章已经被删除或者封禁
            return ResponseCode.ARTICLE_IS_BAN_OR_DEL.val();
        }

        // 设置用户名
        reportArticle.setUserName(userService.getById(byId.getUserId()).getUserName());

        LambdaQueryWrapper<ReportArticle> qw = new LambdaQueryWrapper<>();

        ReportArticle articleReportInfo = reportArticleMapper.selectOne(qw.eq(ReportArticle::getReportArticleId, reportArticle.getReportArticleId()));
        // 判断是否已经审核通过了，并且审核通过后的文章内容没有修改
        if (BeanUtil.isNotEmpty(articleReportInfo)
                && articleReportInfo.getUpdateTime().isAfter(byId.getUpdateTime())
                && articleReportInfo.getReportResult() == ReportResult.PASS.getStatusId()) {
            // 直接返回成功结果，不做任何操作
            return ResponseCode.SUCCESS.val();
        }

        // (举报时) 根据举报文章id查询举报信息（如果存在则拼接理由和更新举报次数）
        if (BeanUtil.isNotEmpty(articleReportInfo)
                && BeanUtil.isEmpty(reportArticle.getReportId())) {
            // 如果状态还是待审核就更新一下举报次数和理由
            Integer reportStatus = articleReportInfo.getReportStatus();
            if (reportStatus.equals(ReportStatus.TO_BE_REVIEWED.getStatusId())) {
                // 不为空时，拼接理由和更新举报次数
                String reportReason = reportArticle.getReportReason();
                if (StrUtil.isNotBlank(reportReason) || !reportReason.equals("")) {
                    // 理由不一定有，只有有理由才会拼接
                    articleReportInfo.setReportReason(articleReportInfo.getReportReason() + "," + reportReason);
                }
                // 举报次数+1
                articleReportInfo.setReportCount(articleReportInfo.getReportCount() + 1);
                // 更新数据库
                saveOrUpdate(articleReportInfo);
                return ResponseCode.SUCCESS.val();
            }

            // 已经审核完了，并且通过审核之后，又被举报，将之前的审核记录重新更新为待审核状态,重置举报理由和举报次数
            if (reportStatus.equals(ReportStatus.AUDITED.getStatusId())) {
                articleReportInfo.setReportStatus(ReportStatus.TO_BE_REVIEWED.getStatusId());
                String reportReason = reportArticle.getReportReason();
                if (StrUtil.isNotBlank(reportReason) || !reportReason.equals("")) {
                    articleReportInfo.setReportReason(reportReason);
                } else {
                    articleReportInfo.setReportReason(null);
                }
                articleReportInfo.setReportReason("");
                articleReportInfo.setReportCount(0L);
                // 更新数据库
                saveOrUpdate(articleReportInfo);
                return ResponseCode.SUCCESS.val();
            }
        }
        // 第一次添加举报信息，直接更新
        // 更新数据库
        this.saveOrUpdate(reportArticle);

        return ResponseCode.SUCCESS.val();
    }

    /**
     * 分页查询文章举报信息列表
     *
     * @param queryPageParam
     * @return
     */
    @Override
    public Page<ReportArticle> listReportArticle(QueryPageParam queryPageParam) {

        Page<ReportArticle> reportArticlePage = new Page<>();

        // 设置当前页
        reportArticlePage.setCurrent(queryPageParam.getPageNum());

        // 设置当前页面数量
        reportArticlePage.setSize(queryPageParam.getPageSize());

        // 按照最新数据查询(按照update_time字段)
        reportArticlePage.setOrders(Arrays.asList(OrderItem.desc("update_time")));

        // 获取查询条件
        HashMap param = queryPageParam.getParam();
        String status = param.get("status").toString();
        String result = param.get("result").toString();
        String articleName = param.get("articleName").toString();

        LambdaQueryWrapper<ReportArticle> qw = new LambdaQueryWrapper<>();
        // 进度
        if (StringUtils.isNotBlank(status) && !"null".equals(status)) {
            qw.eq(ReportArticle::getReportStatus, Integer.parseInt(status));
        }
        // 结果
        if (StringUtils.isNotBlank(result) && !"null".equals(result)) {
            qw.eq(ReportArticle::getReportResult, Integer.parseInt(result));
        }
        // 标题
        if (StringUtils.isNotBlank(articleName) && !"null".equals(articleName)) {
            qw.like(ReportArticle::getReportArticleTitle, articleName);
        }

        return this.page(reportArticlePage, qw);
    }

    /**
     * 文章申述
     *
     * @param userId
     * @param articleId
     * @return
     */
    @Override
    public Integer appealArticle(Long userId, Long articleId) {

        // 查找是否有这一条需要申述的文章信息(状态为封禁)
        LambdaQueryWrapper<ReportArticle> qw = new LambdaQueryWrapper<>();
        qw.eq(ReportArticle::getReportArticleId, articleId);
        qw.eq(ReportArticle::getReportResult,ReportResult.BAN.getStatusId());
        ReportArticle reportArticle = reportArticleMapper.selectOne(qw);

        // 文章不需要申述的情况(没有举报信息，举报处置结果为通过或者待审核)
        if (BeanUtil.isEmpty(reportArticle)
                || reportArticle.getReportResult() == ReportResult.PASS.getStatusId()
                || reportArticle.getReportResult() == ReportResult.NO_DISPOSE.getStatusId()) {
            return ResponseCode.ARTICLE_NOT_REPORT.val();
        }

        // 用户名比对
        User byId = userService.getById(userId);
        if (!byId.getUserName().equals(reportArticle.getUserName())) {
            // 非当前用户申述，请求拒绝
            return ResponseCode.FORBIDDEN.val();
        }

        // 先处理文章的状态结果
        Integer res = articleService.setReportResult(reportArticle.getReportArticleId()
                , ReportResult.NO_DISPOSE.getStatusId(), byId.getUserEmail(), reportArticle.getReportStatus());


        // 处理基本结果状态
        reportArticle.setReportStatus(ReportStatus.RESTATE_PENDING_REVIEW.getStatusId());

        // 更新
        if (!res.equals(ResponseCode.SUCCESS.val())) {
            return res;
        }
        saveOrUpdate(reportArticle);

        return res;
    }

    /**
     * 删除举报文章信息(仅限已审核，并且已经通过的审核，封禁结果暂时无法删除)
     * 如果文章已经被删除也可以删除
     *
     * @param articleId
     * @return
     */
    @Override
    @Transactional
    public Integer delReportArticle(Long articleId) {
        // 获取文章
        Article byId = articleService.getById(articleId);

        // 获取举报信息
        ReportArticle reportArticle = reportArticleMapper.selectOne(new LambdaQueryWrapper<ReportArticle>()
                .eq(ReportArticle::getReportArticleId, articleId));

        // 判断举报信息状态(如果文章通过审核并且处置结果为正常通过才可删除)
        if (reportArticle.getReportStatus() == ReportStatus.AUDITED.getStatusId()
                && reportArticle.getReportResult() == ReportResult.PASS.getStatusId()
                && BeanUtil.isNotEmpty(reportArticle)) {
            // 删除举报信息
            int res = reportArticleMapper.deleteById(reportArticle.getReportId());
            return res > 0 ? ResponseCode.SUCCESS.val() : ResponseCode.FAIL.val();
        }

        // 如果文章已经被删除,则直接删除
        if (!BeanUtil.isNotEmpty(byId)) {
            int res = reportArticleMapper.deleteById(reportArticle.getReportId());
            return res > 0 ? ResponseCode.SUCCESS.val() : ResponseCode.FAIL.val();
        }

        return ResponseCode.REPORT_ARTICLE_DEL_FAIL.val();
    }


    /**
     * 文章审批
     *
     * @param reportArticle
     * @return
     */
    @Transactional
    public Integer approvalArticle(ReportArticle reportArticle) {

        // 获取邮箱
        String userEmail = userService
                .getOne(new LambdaQueryWrapper<User>()
                        .eq(User::getUserName, reportArticle.getUserName())).getUserEmail();

        // 先处理文章的状态结果
        Integer res = articleService.setReportResult(reportArticle.getReportArticleId()
                , reportArticle.getReportResult(), userEmail, reportArticle.getReportStatus());

        // 处理基本结果状态
        reportArticle.setReportStatus(ReportStatus.AUDITED.getStatusId());

        // 更新
        if (!res.equals(ResponseCode.SUCCESS.val())) {
            return res;
        }
        saveOrUpdate(reportArticle);

        return res;
    }
}
