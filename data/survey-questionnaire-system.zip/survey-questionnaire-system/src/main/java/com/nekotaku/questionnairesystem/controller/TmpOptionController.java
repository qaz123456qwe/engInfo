package com.nekotaku.questionnairesystem.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 模板选项表 前端控制器
 * </p>
 *
 * @author nekotaku
 * @since 2024-03-04
 */
@RestController
@RequestMapping("/tmp-option")
public class TmpOptionController {

}
