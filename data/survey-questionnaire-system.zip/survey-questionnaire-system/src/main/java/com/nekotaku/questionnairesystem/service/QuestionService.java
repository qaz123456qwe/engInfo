package com.nekotaku.questionnairesystem.service;

import com.nekotaku.questionnairesystem.vo.QuestionVo;
import com.nekotaku.questionnairesystem.entity.Question;
import com.baomidou.mybatisplus.extension.service.IService;
import com.nekotaku.questionnairesystem.entity.Survey;

import java.util.List;

/**
 * <p>
 * 问卷问题表 服务类
 * </p>
 *
 * @author nekotaku
 * @since 2024-01-27
 */
public interface QuestionService extends IService<Question> {

    Integer saveQuestion(List<QuestionVo> questionsDto);

    List<QuestionVo> getQuestions(Long surveyId);

    Integer saveForTempSurvey(Survey survey, Long tmpId);

    List<QuestionVo> getSingleQuestions(Long surveyId);
}
