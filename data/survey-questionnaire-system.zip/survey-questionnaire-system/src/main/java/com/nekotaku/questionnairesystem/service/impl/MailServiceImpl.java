package com.nekotaku.questionnairesystem.service.impl;

import com.nekotaku.questionnairesystem.service.MailService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

/**
 * 邮件发送服务，通过qq邮箱服务器转发
 *
 * @Title:MailServiceImpl
 * @Author:NekoTaku
 * @Date:2023/11/21 18:58
 * @Version:1.0
 */
@Service
@Slf4j
public class MailServiceImpl implements MailService {

    @Resource
    private JavaMailSender mailSender;

    @Value("${spring.mail.username}")
    private String from;//发送者

    @Override
    public void sendMail(String email, String subject, String content) {
        log.info("使用邮件发送服务");
        MimeMessage message;
        message = mailSender.createMimeMessage();
        try {
            MimeMessageHelper helper = new MimeMessageHelper(message, true);
            helper.setFrom(from);
            helper.setSubject(subject);
            helper.setTo(email);
            helper.setText(content, true);
            mailSender.send(message);
            log.info("邮箱发送成功");
        } catch (MessagingException e) {
            log.info("邮箱发送失败", e);
        }
    }
}
