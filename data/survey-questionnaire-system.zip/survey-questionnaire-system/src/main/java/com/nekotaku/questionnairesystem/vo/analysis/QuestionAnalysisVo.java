package com.nekotaku.questionnairesystem.vo.analysis;

import com.nekotaku.questionnairesystem.entity.Question;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;


/**
 * @Title:QuestionDto
 * @Author:NekoTaku
 * @Date:2024/01/27 14:39
 * @Version:1.0
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class QuestionAnalysisVo extends Question {

    @ApiModelProperty(value = "选项列表")
    private List<OptionAnalysisVo> option;

    @ApiModelProperty(value = "题类型")
    private String questionTypeValue;


}
