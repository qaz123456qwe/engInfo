package com.nekotaku.questionnairesystem.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.date.LocalDateTimeUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.RandomUtil;
import cn.hutool.core.util.ReUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.nekotaku.questionnairesystem.common.R.ResponseCode;
import com.nekotaku.questionnairesystem.common.R.ResponseConstants;
import com.nekotaku.questionnairesystem.common.R.Result;
import com.nekotaku.questionnairesystem.common.constants.upload.UpLoadConstants;
import com.nekotaku.questionnairesystem.common.enums.EmailType;
import com.nekotaku.questionnairesystem.common.exception.CustomException;
import com.nekotaku.questionnairesystem.common.lock.TimeoutLock;
import com.nekotaku.questionnairesystem.service.RoleService;
import com.nekotaku.questionnairesystem.utils.RegexPatterns;
import com.nekotaku.questionnairesystem.utils.file.UploadUtils;
import com.nekotaku.questionnairesystem.vo.UserVo;
import com.nekotaku.questionnairesystem.entity.User;
import com.nekotaku.questionnairesystem.mapper.UserMapper;
import com.nekotaku.questionnairesystem.service.MailService;
import com.nekotaku.questionnairesystem.service.UserService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.nekotaku.questionnairesystem.utils.Argon2PasswordEncoder;
import com.nekotaku.questionnairesystem.utils.TokenUtil;
import com.nekotaku.questionnairesystem.vo.email.EmailVo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * <p>
 * 调查问卷系统用户表 服务实现类
 * </p>
 *
 * @author nekotaku
 * @since 2023-11-20
 */
@Slf4j
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService {

    @Autowired
    private StringRedisTemplate redisTemplate;

    @Autowired
    private MailService mailService;

    @Autowired
    private RoleService roleService;

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private TokenUtil tokenUtil;

    @Autowired
    private UploadUtils uploadUtils;

    //虚拟路径
    @Value("${file.accessPath}")
    private String accessPath;

    // 默认头像文件名
    @Value("${default.avatar}")
    private String defaultAvatarName;


    private final TimeoutLock timeoutLock;

    @Autowired
    public UserServiceImpl() {
        // 设置锁超时时间 5秒 传参单位：毫秒
        this.timeoutLock = new TimeoutLock(5000L);
    }


    /**
     * 邮箱验证码服务
     *
     * @param email
     * @param type
     * @return
     */
    @Override
    public Integer getEmailCode(String email, String type) {

        String key = type + ":" + email;
        Long time = redisTemplate.opsForValue().getOperations().getExpire(key, TimeUnit.SECONDS);
        if (time > 240L) {
            // 判断发送是否过于频繁
            return ResponseCode.CODE_FREQUENT.val();
        }
        // 判断邮箱验证码作用
        if (type.equals(EmailType.REGISTER.getTypeName())) {
            // 判断当前邮箱是否被使用
            User userByEmail = getUserByEmail(email);
            if (!ObjectUtil.isEmpty(userByEmail)) {
                return ResponseCode.EMAIL_EXIST.val();
            }
            // 生成随机码
            String code = RandomUtil.randomNumbers(6);
            // 邮件主题
            String subject = "调查问卷平台";
            // 邮件信息
            String message = "<h3>欢迎注册【调查问卷平台】</h3><br/>你的验证码为:" +
                    "<span style='color:red'>" + code + "</span>,有效时间为<span style='color:red'>5</span>分钟(若不是本人操作，请忽略该条邮件)";
            log.info("验证码" + code);

            // 发送邮件
            try {
                mailService.sendMail(email, subject, message);
                // 将验证码存入redis，并且设置5分钟过期时间
                redisTemplate.opsForValue().set(key, code, 5, TimeUnit.MINUTES);
                return ResponseCode.SUCCESS.val();
            } catch (Exception e) {
                return ResponseCode.FAIL.val();
            }
        }

        // 更换邮箱，旧邮箱验证
        if (type.equals(EmailType.CHANGE_EMAIL_OLD.getTypeName())) {
            // 生成随机码
            String code = RandomUtil.randomNumbers(6);
            // 邮件主题
            String subject = "调查问卷平台";
            // 邮件信息
            String message = "<h3>旧邮箱验证【调查问卷平台】</h3><br/>你的验证码为:" +
                    "<span style='color:red'>" + code + "</span>,有效时间为<span style='color:red'>5</span>分钟(若不是本人操作，请忽略该条邮件)";
            log.info("验证码" + code);

            // 发送邮件
            try {
                mailService.sendMail(email, subject, message);
                // 将验证码存入redis，并且设置5分钟过期时间
                redisTemplate.opsForValue().set(key, code, 5, TimeUnit.MINUTES);
                return ResponseCode.SUCCESS.val();
            } catch (Exception e) {
                return ResponseCode.FAIL.val();
            }
        }

        // 更换邮箱，新邮箱验证
        if (type.equals(EmailType.CHANGE_EMAIL_NEW.getTypeName())) {
            // 生成随机码
            String code = RandomUtil.randomNumbers(6);
            // 邮件主题
            String subject = "调查问卷平台";
            // 邮件信息
            String message = "<h3>邮箱换绑【调查问卷平台】</h3><br/>你的验证码为:" +
                    "<span style='color:red'>" + code + "</span>,有效时间为<span style='color:red'>5</span>分钟(若不是本人操作，请忽略该条邮件)";
            log.info("验证码" + code);

            // 发送邮件
            try {
                mailService.sendMail(email, subject, message);
                // 将验证码存入redis，并且设置5分钟过期时间
                redisTemplate.opsForValue().set(key, code, 5, TimeUnit.MINUTES);
                return ResponseCode.SUCCESS.val();
            } catch (Exception e) {
                return ResponseCode.FAIL.val();
            }
        }

        // 重置密码
        if (type.equals(EmailType.RESET_PASSWORD.getTypeName())) {
            // 生成随机码
            String code = RandomUtil.randomNumbers(6);
            // 邮件主题
            String subject = "调查问卷平台";
            // 邮件信息
            String message = "<h3>重置密码【调查问卷平台】</h3><br/>你的验证码为:" +
                    "<span style='color:red'>" + code + "</span>,有效时间为<span style='color:red'>5</span>分钟(若不是本人操作，请忽略该条邮件)";
            log.info("验证码" + code);

            // 发送邮件
            try {
                mailService.sendMail(email, subject, message);
                // 将验证码存入redis，并且设置5分钟过期时间
                redisTemplate.opsForValue().set(key, code, 5, TimeUnit.MINUTES);
                return ResponseCode.SUCCESS.val();
            } catch (Exception e) {
                return ResponseCode.FAIL.val();
            }
        }

        return ResponseCode.FAIL.val();
    }

    /**
     * 用户注册服务，数据库用户表+1
     *
     * @param user
     * @return
     */
    @Override
    public Integer register(User user, String code, String type) {

        log.info("调用用户注册服务");

        User userByName = getUserByName(user.getUserName());
        // 1.验证用户名是否被占用
        if (!ObjectUtil.isEmpty(userByName)) {
            return ResponseCode.USERNAME_EXIST.val();
        }
        // 2.查询redis取出邮箱验证码比对
        String key = type + ":" + user.getUserEmail();
        String verifyCode = redisTemplate.opsForValue().get(key);
        log.info(verifyCode);
        // 验证验证码
        Integer codeRes = checkCode(verifyCode, code, ResponseCode.CODE_INVALID.val());
        if (!codeRes.equals(ResponseCode.SUCCESS.val())) {
            return codeRes;
        }

        // 销毁key
        redisTemplate.delete(key);

        // 3.向数据库中插入一条数据
        // 对密码进行加密
        user.setUserPassword(Argon2PasswordEncoder.encode(user.getUserPassword()));
        // 设置默认头像路径
        user.setUserAvatarPath(accessPath + "avatar/default/defaultAvatar.jpg");
        int insertRes = userMapper.insert(user);
        return insertRes > 0 ? ResponseCode.SUCCESS.val() : ResponseCode.FAIL.val();
    }

    /**
     * 用户登录
     *
     * @param account
     * @param password
     * @return
     */
    @Override
    public Result login(String account, String password) {
        log.info("用户登录服务");
        // 根据用户名获取用户
        User user = getUserByName(account);
        User getUserByEmail = getUserByEmail(account);

        // 验证是否存在当前用户(先验证用户名)
        if (ObjectUtil.isEmpty(user)) {
            // 是否通过邮箱登录验证邮箱
            if (ObjectUtil.isEmpty(getUserByEmail)) {
                // 无效的用户名
                return Result.fail(ResponseCode.USER_INVALID.val(),
                        ResponseCode.USER_INVALID.msg());
            }
            // 邮箱登录通过
            user = getUserByEmail;
        }

        // 验证密码，因为密码是加密的所以需要单独处理
        if (!Argon2PasswordEncoder.matches(user.getUserPassword(), password)) {
            // 密码不匹配
            return Result.fail(ResponseCode.USER_INVALID.val(),
                    ResponseCode.USER_INVALID.msg());
        }

        // 通过用户名密码验证，根据用户id和用户角色id生成token
        String token = tokenUtil.getToken(user.getUserId().toString(), user.getUserRoleId());
        // 需要返回的数据
        HashMap<String, Object> map = getUserVoMap(user.getUserId());
        map.put("token", token);

//        UserVo userVo = new UserVo();
//        // 对象拷贝
//        BeanUtil.copyProperties(userByName, userVo);
//        // 获取用户角色名
//        String roleName = roleService.getById(userByName.getUserRoleId()).getRoleName();
//        userVo.setRole(roleName);
//        userVo.setLoginTime(LocalDateTimeUtil.now());
//        map.put("user", userVo);

        return Result.success("登录成功", map);
    }

    /**
     * 更新密码
     *
     * @param userId
     * @param oldPassword
     * @param newPassword
     * @return
     */
    @Override
    public Integer updatePassword(Long userId, String oldPassword, String newPassword) {
        User user = userMapper.selectById(userId);
        // 旧密码比对
        if (!Argon2PasswordEncoder.matches(user.getUserPassword(), oldPassword)) {
            return ResponseCode.PASSWORD_NO_MATCH.val();
        }
        // 通过旧密码验证，验证新密码是否合法
        boolean isPass = RegularVerification(newPassword, RegexPatterns.PASSWORD_REGEX);
        if (isPass) {
            // 符合规则，更新密码
            user.setUserPassword(Argon2PasswordEncoder.encode(newPassword));
            return userMapper.updateById(user) > 0 ? ResponseCode.SUCCESS.val() : ResponseCode.FAIL.val();
        }
        return Integer.parseInt(ResponseConstants.INVALID_RESPONSE_CODE);
    }

    /**
     * 邮箱换绑
     *
     * @param userId
     * @param emailVo
     * @return
     */
    @Override
    public Integer changeEmail(Long userId, EmailVo emailVo) {
        // 获取用户信息
        User user = userMapper.selectById(userId);
        // 旧邮箱比对
        if (!user.getUserEmail().equals(emailVo.getUserEmail())) {
            return ResponseCode.EMAIL_NO_MATCH.val();
        }

        // 从redis获取验证码
        // 旧邮箱验证码
        String oldKey = EmailType.CHANGE_EMAIL_OLD.getTypeName() + emailVo.getUserEmail();
        String oldCode = redisTemplate.opsForValue().get(oldKey);

        // 旧邮箱验证验证码
        Integer oldCodeRes = checkCode(oldCode, emailVo.getCode(), ResponseCode.OLD_EMAIL_CODE_NO_MATCH.val());
        if (!oldCodeRes.equals(ResponseCode.SUCCESS.val())) {
            return oldCodeRes;
        }

        // 新邮箱验证码
        String newKey = EmailType.CHANGE_EMAIL_NEW.getTypeName() + emailVo.getNewEmail();
        String newCode = redisTemplate.opsForValue().get(newKey);

        // 新邮箱验证验证码
        Integer newCodeRes = checkCode(newCode, emailVo.getNewCode(), ResponseCode.NEW_EMAIL_CODE_NO_MATCH.val());
        if (!newCodeRes.equals(ResponseCode.SUCCESS.val())) {
            return newCodeRes;
        }

        // 销毁key
        redisTemplate.delete(oldKey);
        redisTemplate.delete(newKey);

        // 更换邮箱信息
        user.setUserEmail(emailVo.getNewEmail());
        return userMapper.updateById(user) > 0 ? ResponseCode.SUCCESS.val() : ResponseCode.FAIL.val();
    }

    /**
     * 更改用户基本信息
     *
     * @param userId
     * @param avatar
     * @param nickName
     * @return
     */
    @Override
    public Integer updateUserInfo(Long userId, String avatar, String nickName) {

        // 信息改变
        boolean infoIsChange = false;
        // 头像改变
        boolean imgIsChange = false;
        // 是否默认头像改变
        boolean imgIsFirst = false;

        String tempImgSrc = "";

        // 获取旧用户信息
        User user = userMapper.selectById(userId);

        // 检查信息是否变化
        if (!user.getUserNickname().equals(nickName)) {
            infoIsChange = true;
            user.setUserNickname(nickName);
        }
        if (!user.getUserAvatarPath().equals(avatar)) {
            tempImgSrc = user.getUserAvatarPath();
            infoIsChange = true;
            imgIsChange = true;
            // 旧头像是否为默认头像，如果是默认头像则不用删除文件
            if (uploadUtils.subFileName(tempImgSrc).equals(defaultAvatarName)) {
                imgIsFirst = true;
            }
            user.setUserAvatarPath(avatar);
        }

        // 更新数据库
        if (infoIsChange) {
            int res = userMapper.updateById(user);
            if (res > 0) {
                // 检查头像是变化(并且旧头像不是默认头像时)
                if (imgIsChange && !imgIsFirst) {
                    // 删除旧头像
                    uploadUtils.deleteFileByPath(tempImgSrc);
                }
                if (imgIsChange) {
                    // 将临时文件的头像拷贝到正式文件
                    uploadUtils.copyTempFile(user.getUserAvatarPath(), UpLoadConstants.AVATAR_IMAGE, userId);
                }
                return ResponseCode.SUCCESS.val();
            }
        } else {
            return ResponseCode.SUCCESS.val();
        }

        return ResponseCode.FAIL.val();
    }

    /**
     * 获取userVo map
     *
     * @param userId
     * @return
     */
    @Override
    public HashMap<String, Object> getUserVoMap(Long userId) {

        HashMap<String, Object> map = new HashMap<>();
        User byId = userMapper.selectById(userId);
        UserVo userVo = new UserVo();
        BeanUtil.copyProperties(byId, userVo);
        // 角色id
        String roleName = roleService.getById(byId.getUserRoleId()).getRoleName();
        userVo.setLoginTime(LocalDateTimeUtil.now());
        userVo.setRole(roleName);

        // 用户余额
        userVo.setUserBalance(byId.getUserBalance());

        map.put("user", userVo);
        return map;
    }

    /**
     * 重置密码的邮箱验证
     *
     * @param email
     * @param code
     * @return
     */
    @Override
    public Integer validationCodeForReset(String email, String code) {
        User userByEmail = getUserByEmail(email);
        // 查询是否存在用户
        if (!BeanUtil.isNotEmpty(userByEmail)) {
            return ResponseCode.EMAIL_NOT_USER.val();
        }
        // 从redis中取出验证码
        String key = EmailType.RESET_PASSWORD.getTypeName() + ":" + email;
        String codeForeRedis = redisTemplate.opsForValue().get(key);

        // 验证码比对
        Integer codeRes = checkCode(codeForeRedis, code, ResponseCode.CODE_INVALID.val());
        if (!codeRes.equals(ResponseCode.SUCCESS.val())) {
            return codeRes;
        }

        // 更新redis缓存时间,重置密码时还要校验一次
        redisTemplate.expire(key, 5, TimeUnit.MINUTES);

        return ResponseCode.SUCCESS.val();
    }

    /**
     * 重置密码
     *
     * @param email
     * @param code
     * @param newPassword
     * @return
     */
    @Override
    public Integer resetPassword(String email, String code, String newPassword) {
        // 根据邮箱获取用户
        User userByEmail = getUserByEmail(email);
        // 基本验证：邮箱是否有用户、验证码二次验证、密码正则表达式验证
        if (!BeanUtil.isNotEmpty(userByEmail)) {
            return ResponseCode.EMAIL_NOT_USER.val();
        }
        String key = EmailType.RESET_PASSWORD.getTypeName() + ":" + email;
        String codeForeRedis = redisTemplate.opsForValue().get(key);
        Integer codeRes = checkCode(codeForeRedis, code, ResponseCode.CODE_INVALID.val());
        if (!codeRes.equals(ResponseCode.SUCCESS.val())) {
            return codeRes;
        }
        boolean isPass = RegularVerification(newPassword, RegexPatterns.PASSWORD_REGEX);
        if (isPass) {
            // 通过所有验证，更新密码
            userByEmail.setUserPassword(Argon2PasswordEncoder.encode(newPassword));
            return userMapper.updateById(userByEmail) > 0 ? ResponseCode.SUCCESS.val() : ResponseCode.FAIL.val();
        }

        return Integer.parseInt(ResponseConstants.INVALID_RESPONSE_CODE);
    }

    /**
     * 更新余额
     *
     * @param userId 用户id
     * @param balance 余额
     * @return
     */
    @Override
    public boolean updateBalance(Long userId, BigDecimal balance) {
        // 获取锁
        if (timeoutLock.tryLock()) {
            try {
                // 更新金额
                LambdaUpdateWrapper<User> updateWrapper = new LambdaUpdateWrapper<>();
                updateWrapper.set(User::getUserBalance, balance).eq(User::getUserId, userId);
                // 更新数据库
                boolean update = this.update(updateWrapper);
                return update;
            } finally {
                // 确保锁释放
                timeoutLock.unlock();
            }
        } else {
            log.info("更新余额，获取锁超时");
            throw new CustomException("发送未知错误");
        }
    }

    /**
     * 利用hutool进行正则表达式验证
     *
     * @param value
     * @param regex
     * @return
     */
    private boolean RegularVerification(String value, String regex) {
        return ReUtil.isMatch(regex, value);
    }


    /**
     * 根据用户名获取用户
     *
     * @param userName
     * @return
     */
    private User getUserByName(String userName) {
        LambdaQueryWrapper<User> qw = new LambdaQueryWrapper<>();
        qw.eq(User::getUserName, userName);
        // 使用 apply 方法添加区分大小写条件
        qw.apply("BINARY user_name = {0}", userName);
        return userMapper.selectOne(qw);
    }


    /**
     * 更具邮箱获取用户
     *
     * @param email
     * @return
     */
    private User getUserByEmail(String email) {
        LambdaQueryWrapper<User> qw = new LambdaQueryWrapper<>();
        qw.eq(User::getUserEmail, email);
        return userMapper.selectOne(qw);
    }

    /**
     * 验证码匹配
     *
     * @param verifyCode redis中的验证码
     * @param code       输入的验证码
     * @param matchType  验证类型
     * @return
     */
    private Integer checkCode(String verifyCode, String code, Integer matchType) {
        // 判断是否过期，如果为空，验证码过期
        if (!StrUtil.hasEmpty(verifyCode)) {
            // 匹配验证
            if (StrUtil.isNotBlank(code)) {
                if (!verifyCode.equals(code)) {
                    return matchType;
                } else {
                    return ResponseCode.SUCCESS.val();
                }
            } else {
                return ResponseCode.VALUE_INVALID.val();
            }
        } else {
            // 验证码过期失效
            return ResponseCode.CODE_TIMEOUT.val();
        }
    }

}
