package com.nekotaku.questionnairesystem.controller;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.nekotaku.questionnairesystem.common.R.ResponseCode;
import com.nekotaku.questionnairesystem.common.R.Result;
import com.nekotaku.questionnairesystem.common.page.QueryPageParam;
import com.nekotaku.questionnairesystem.entity.SurveyBonus;
import com.nekotaku.questionnairesystem.service.SurveyBonusService;
import com.nekotaku.questionnairesystem.utils.TokenUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * <p>
 * 奖励记录表 前端控制器
 * </p>
 *
 * @author nekotaku
 * @since 2024-05-12
 */
@RestController
@RequestMapping("/survey-bonus")
public class SurveyBonusController {

    @Autowired
    private SurveyBonusService surveyBonusService;

    @Autowired
    private TokenUtil tokenUtil;

    /**
     * 增加奖励记录信息
     *
     * @param surveyBonus
     * @return
     */
    @PostMapping("/addBonusLog")
    public Result addBonusLog(@RequestBody SurveyBonus surveyBonus) {

        Integer res = surveyBonusService.addBonusLog(surveyBonus);

        if (res != ResponseCode.SUCCESS.val()) {
            return Result.fail(res, ResponseCode.getMsgByVal(res));
        }

        return Result.success(res, "奖励将在1-3个工作日内发放！");
    }

    /**
     * 分页查询奖励记录
     *
     * @param queryPageParam
     * @param request
     * @return
     */
    @PostMapping("/listBonusLog")
    public Result listSurveyBonus(@RequestBody QueryPageParam queryPageParam,
                                  HttpServletRequest request) {

        Long userId = tokenUtil.getUserIdFromToken(request);

        Page<SurveyBonus> res = surveyBonusService.listSurveyBonus(queryPageParam, userId);

        // 脱敏领奖手机号
        List<SurveyBonus> records = res.getRecords();
        for (SurveyBonus record : records) {
            record.setBonusAccount(null);
        }

        res.setRecords(records);

        return Result.success(ResponseCode.SUCCESS.val(), ResponseCode.SUCCESS.msg(),
                res.getRecords(), res.getTotal());
    }
}
