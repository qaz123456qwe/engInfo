package com.nekotaku.questionnairesystem.controller;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.nekotaku.questionnairesystem.common.R.ResponseCode;
import com.nekotaku.questionnairesystem.common.R.Result;
import com.nekotaku.questionnairesystem.common.page.QueryPageParam;
import com.nekotaku.questionnairesystem.vo.SurveyAndQuestionVo;
import com.nekotaku.questionnairesystem.entity.Answer;
import com.nekotaku.questionnairesystem.entity.SurveyFinishLog;
import com.nekotaku.questionnairesystem.service.AnswerService;
import com.nekotaku.questionnairesystem.service.QuestionService;
import com.nekotaku.questionnairesystem.service.SurveyFinishLogService;
import com.nekotaku.questionnairesystem.service.SurveyService;
import com.nekotaku.questionnairesystem.utils.TokenUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * <p>
 * 问卷每完成一份的日志 前端控制器
 * </p>
 *
 * @author nekotaku
 * @since 2024-02-29
 */
@RestController
@RequestMapping("/survey-finish-log")
@Slf4j
public class SurveyFinishLogController {

    @Autowired
    private SurveyFinishLogService surveyFinishLogService;

    @Autowired
    private QuestionService questionService;

    @Autowired
    private SurveyService surveyService;

    @Autowired
    private AnswerService answerService;

    @Autowired
    private TokenUtil tokenUtil;

    /**
     * 分页查询已完成问卷的记录
     *
     * @param queryPageParam
     * @param httpServletRequest
     * @return
     */
    @PostMapping("/getSurveyLog")
    public Result getSurveyLog(@RequestBody QueryPageParam queryPageParam
            , HttpServletRequest httpServletRequest) {
        Long userId = tokenUtil.getUserIdFromToken(httpServletRequest);

        Page<SurveyFinishLog> res = surveyFinishLogService.listSurveyLog(queryPageParam, userId);
        return Result.success(ResponseCode.SUCCESS.val(), ResponseCode.SUCCESS.msg(),
                res.getRecords(), res.getTotal());
    }

    /**
     * 查询用户答题的详细情况
     *
     * @param logId
     * @param httpServletRequest
     * @return
     */
    @GetMapping("/getSurveyWithAnswer/{logId}")
    public Result getSurveyWithAnswer(@PathVariable("logId") Long logId
            , HttpServletRequest httpServletRequest) {

        Long userId = tokenUtil.getUserIdFromToken(httpServletRequest);

        // 获取问卷Id
        SurveyFinishLog logById = surveyFinishLogService.getById(logId);
        Long surveyId = logById.getSurveyId();

        // 判断是否为当前用户
        if (userId.equals(logById.getUserId())) {
            // 获取为问题和选项
            SurveyAndQuestionVo surveyDetailedById = surveyService
                    .getSurveyDetailedById(surveyId, questionService.getQuestions(surveyId));

            // 获取答案
            List<Answer> answerList = answerService.getAnswerByLogId(logById.getId());

            surveyDetailedById = surveyFinishLogService.setAnswerForQuestion(surveyDetailedById, answerList);
            return Result.success(ResponseCode.SUCCESS.val(), ResponseCode.SUCCESS.msg(), surveyDetailedById);
        }

        return Result.fail(ResponseCode.FAIL.val(), "当前无权查看本条问卷信息");
    }
}
