package com.nekotaku.questionnairesystem.vo.excel;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;


/**
 * 生成带选择题的选项回答的excel
 *
 * @Title:ExcelWithChoiceVo
 * @Author:NekoTaku
 * @Date:2024/03/30 15:38
 * @Version:1.0
 */
@Data
public class ExcelWithChoiceVo {

    @ApiModelProperty(value = "问卷完成日志id")
    private Long surveyFinishLogId;

    @ApiModelProperty(value = "客观题输入内容")
    private String answerContext;

    @ApiModelProperty(value = "选项内容")
    private String optionContents;

    @ApiModelProperty(value = "问题内容")
    private String questionContent;
}
