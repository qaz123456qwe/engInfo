package com.nekotaku.questionnairesystem.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.nekotaku.questionnairesystem.common.R.Result;
import com.nekotaku.questionnairesystem.common.page.QueryPageParam;
import com.nekotaku.questionnairesystem.entity.Category;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 * 分类表 服务类
 * </p>
 *
 * @author nekotaku
 * @since 2023-12-10
 */
public interface CategoryService extends IService<Category> {

    Integer saveOrUpdateCategory(Category category);

    Page<Category> listCategory(QueryPageParam queryPageParam,Long userId);

    Integer deleteCategory(String id);

    Result deleteByIds(String idsStr);

    List<Category> getCategoriesByUserId(Long userId);
}
