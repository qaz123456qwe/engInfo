package com.nekotaku.questionnairesystem.mapper;

import com.nekotaku.questionnairesystem.vo.QuestionVo;
import com.nekotaku.questionnairesystem.entity.Question;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * <p>
 * 问卷问题表 Mapper 接口
 * </p>
 *
 * @author nekotaku
 * @since 2024-01-27
 */
@Mapper
public interface QuestionMapper extends BaseMapper<Question> {

    // 做自定义连接查询
    List<QuestionVo> getQuestionsAndOptionsBySurveyId(Long surveyId);
}
