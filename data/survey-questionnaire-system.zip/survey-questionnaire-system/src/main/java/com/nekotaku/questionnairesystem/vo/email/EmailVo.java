package com.nekotaku.questionnairesystem.vo.email;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Title:EmailVo
 * @Author:NekoTaku
 * @Date:2024/03/18 9:43
 * @Version:1.0
 */
@Data
public class EmailVo {

    @ApiModelProperty(value = "用户旧邮箱")
    private String userEmail;

    @ApiModelProperty(value = "旧邮箱验证码")
    private String code;

    @ApiModelProperty(value = "用户新邮箱")
    private String newEmail;

    @ApiModelProperty(value = "新邮箱验证码")
    private String newCode;
}
