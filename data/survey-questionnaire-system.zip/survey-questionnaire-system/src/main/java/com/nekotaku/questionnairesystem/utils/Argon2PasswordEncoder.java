package com.nekotaku.questionnairesystem.utils;

import de.mkammerer.argon2.Argon2;
import de.mkammerer.argon2.Argon2Factory;

/**
 * 基于ARGON2id的加密工具
 *
 * @Title:Argon2PasswordEncoder
 * @Author:NekoTaku
 * @Date:2023/11/30 22:17
 * @Version:1.0
 */
public class Argon2PasswordEncoder {
    /*
     * 设置默认推荐参数
     */
    // Argon2算法在哈希密码时要执行的迭代次数。
    // 迭代次数越多，哈希的安全性就越高，但计算哈希所需的时间也会增加
    private static final int ITERATIONS = 2;

    // Argon2算法在哈希密码时使用的内存（以字节为单位）数量。
    // 更多的内存会提高哈希的安全性，但也会增加内存使用量
    private static final int MEMORY = 65536;

    // Argon2算法在哈希密码时使用的线程数。
    // 并行度越高，计算哈希的速度就越快，但同时也会消耗更多的计算资源。
    private static final int PARALLELISM = 1;

    /*
     * 推荐 argon2id,类型共有三种类型可选（ARGON2i,ARGON2d,ARGON2id;）
     */
    public static final Argon2Factory.Argon2Types TYPE = Argon2Factory.Argon2Types.ARGON2id;

    /*
     * 工厂模式获取单例Argon2对象
     */
    private static final Argon2 INSTANCE = Argon2Factory.create(TYPE);

    /**
     * 使用Argon2id加密密码
     *
     * @param password 原始密码
     * @return 加密后密码
     */
    public static String encode(String password) {
        return INSTANCE.hash(ITERATIONS, MEMORY, PARALLELISM, password.toCharArray());
    }

    /**
     * 使用Argon2id算法验证密码是否正确
     *
     * @param encodedPassword 加密后密码
     */
    public static boolean matches(String encodedPassword, String password) {
        return INSTANCE.verify(encodedPassword, password.toCharArray());
    }

}
