package com.nekotaku.questionnairesystem.controller;


import cn.hutool.core.bean.BeanUtil;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.nekotaku.questionnairesystem.common.R.ResponseCode;
import com.nekotaku.questionnairesystem.common.R.Result;
import com.nekotaku.questionnairesystem.common.page.QueryPageParam;
import com.nekotaku.questionnairesystem.entity.report.ReportArticle;
import com.nekotaku.questionnairesystem.service.ReportArticleService;
import com.nekotaku.questionnairesystem.utils.TokenUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.constraints.NotBlank;

/**
 * <p>
 * 文章举报表 前端控制器
 * </p>
 *
 * @author nekotaku
 * @since 2024-04-01
 */
@RestController
@RequestMapping("/report-article")
public class ReportArticleController {

    @Autowired
    private ReportArticleService reportArticleService;

    @Autowired
    private TokenUtil tokenUtil;

    /**
     * 增加或者修改一条举报信息(修改主要针对于多个用户对同一篇文章的举报)
     *
     * @param reportArticle
     * @return
     */
    @PostMapping("/report")
    public Result saveOrUpdate(@RequestBody ReportArticle reportArticle,
                               HttpServletRequest request) {
        // 是否管理员操作
        boolean isAdminUser = tokenUtil.checkIsAdmin(request);

        Integer res = isAdminUser ? reportArticleService.saveOrUpdateArticleReport(reportArticle, true)
                : reportArticleService.saveOrUpdateArticleReport(reportArticle, false);

        if (res != ResponseCode.SUCCESS.val()) {
            return Result.fail(res, ResponseCode.getMsgByVal(res));
        }

        String msg = (BeanUtil.isNotEmpty(reportArticle.getReportId()) && isAdminUser) ?
                "已完成文章：" + reportArticle.getReportArticleTitle() + " 的审批"
                : "我们已经收到您的举报，我们将尽快审核此文章，感谢您的支持和配合";
        return Result.success(res, msg);
    }

    /**
     * 分页查询举报文章信息列表(可带条件查询)
     *
     * @param queryPageParam
     * @param request
     * @return
     */
    @PostMapping("/listReportArticle")
    public Result listReportArticle(@RequestBody QueryPageParam queryPageParam,
                                    HttpServletRequest request) {
        // 判断是否为管理员操作
        boolean isAdminUser = tokenUtil.checkIsAdmin(request);
        if (!isAdminUser) {
            // 非管理员用户拒绝访问
            return Result.fail(ResponseCode.FORBIDDEN.val(),
                    ResponseCode.FORBIDDEN.msg());
        }
        // 分页查询
        Page<ReportArticle> res = reportArticleService.listReportArticle(queryPageParam);

        return Result.success(ResponseCode.SUCCESS.val(), ResponseCode.SUCCESS.msg(),
                res.getRecords(), res.getTotal());
    }

    /**
     * 文章申述
     *
     * @param request
     * @param ArticleId
     * @return
     */
    @PutMapping("/appealArticle/{ArticleId}")
    public Result appealArticle(HttpServletRequest request, @PathVariable("ArticleId") Long ArticleId) {
        // 获取用户id
        Long userId = tokenUtil.getUserIdFromToken(request);

        // 申述
        Integer res = reportArticleService.appealArticle(userId, ArticleId);

        if (res != ResponseCode.SUCCESS.val()) {
            return Result.fail(res, ResponseCode.getMsgByVal(res));
        }

        return Result.success(res, "申述已经提交，我们将尽快对此文章进行审核，感谢您的支持和配合");
    }

    /**
     * 删除文章举报信息(仅限已经审核完成并且通过的举报信息)
     *
     * @param request
     * @param ArticleId
     * @return
     */
    @DeleteMapping("/delReportArticle/{ArticleId}")
    public Result delReportArticle(HttpServletRequest request,
                                   @NotBlank @PathVariable("ArticleId") Long ArticleId) {

        // 检查是否为管理员操作
        boolean isAdmin = tokenUtil.checkIsAdmin(request);

        if(!isAdmin){
            // 非管理员操作，拒接接口访问403
            return Result.fail(ResponseCode.FORBIDDEN.val(), ResponseCode.FORBIDDEN.msg());
        }

        Integer res = reportArticleService.delReportArticle(ArticleId);

        if (res != ResponseCode.SUCCESS.val()) {
            return Result.fail(res, ResponseCode.getMsgByVal(res));
        }

        return Result.success(res, "删除举报文章信息成功");
    }

}
