package com.nekotaku.questionnairesystem.common.enums;

/**
 * 问题类型枚举
 *
 * @Title:QuestionType
 * @Author:NekoTaku
 * @Date:2024/01/29 16:25
 * @Version:1.0
 */
public enum QuestionType {
    SINGLE_CHOICE(1, "单选", "radio"),
    MULTIPLE_CHOICE(2, "多选", "checkbox"),
    TEXTAREA(3, "文本框", "textarea");

    private final int typeId;
    private final String typeName;
    private final String typeValue;

    QuestionType(int typeId, String typeName, String typeValue) {
        this.typeId = typeId;
        this.typeName = typeName;
        this.typeValue = typeValue;
    }

    public int getTypeId() {
        return typeId;
    }

    public String getTypeName() {
        return typeName;
    }

    public String getTypeValue() {
        return typeValue;
    }

    public static QuestionType getByTypeId(int typeId) {
        for (QuestionType type : values()) {
            if (type.getTypeId() == typeId) {
                return type;
            }
        }
        throw new IllegalArgumentException("Invalid typeId: " + typeId);
    }
}
