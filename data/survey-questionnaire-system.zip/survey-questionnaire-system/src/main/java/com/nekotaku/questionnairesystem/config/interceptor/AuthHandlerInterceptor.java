package com.nekotaku.questionnairesystem.config.interceptor;

import com.nekotaku.questionnairesystem.common.R.ResponseCode;
import com.nekotaku.questionnairesystem.common.exception.CustomException;
import com.nekotaku.questionnairesystem.utils.TokenUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Map;

/**
 * 拦截器AuthHandlerInterceptor，负责拦截所有Http请求，验证Token是否有效
 *
 * @Title:AuthHandlerInterceptor
 * @Author:NekoTaku
 * @Date:2023/12/03 15:33
 * @Version:1.0
 */
@Slf4j
@Component
public class AuthHandlerInterceptor implements HandlerInterceptor {

    @Autowired
    TokenUtil tokenUtil;

    @Value("${token.refreshTime}")
    private Long refreshTime; // 刷新时间
    @Value("${token.expiresTime}")
    private Long expiresTime; // 过期时间

    /**
     * 权限认证的拦截操作.
     */
    @Override
    public boolean preHandle(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object object) throws Exception {
        // 获取请求的路径
        String requestURI = httpServletRequest.getRequestURI();
        log.info("=======进入拦截器========");
        log.info("请求路径："+ requestURI);

        // 排除静态资源路径
        if (requestURI.startsWith("/avatar")) {
            // 允许访问静态资源
            return true;
        }

        // 如果不是映射到方法直接通过,可以访问资源.
        if (!(object instanceof HandlerMethod)) {
            return true;
        }
        // 检验token合法性
        String token = httpServletRequest.getHeader("Authorization");
        log.info("拦截器token:"+token);
        if ((token == null || token.length() == 0) || !token.startsWith("Bearer ")) {
            log.warn("token无效");
            throw new CustomException(String.valueOf(ResponseCode.TOKEN_INVALID.val()));
        }
        // token合法
//        log.info("==============token:" + token);
        Map<String, String> map = tokenUtil.parseToken(token);
//        log.info("token解析数据："+map);
        String userId = map.get("userId");
        Integer userRoleId = Integer.parseInt(map.get("userRoleId"));
        long timeOfUse = System.currentTimeMillis() - Long.parseLong(map.get("timeStamp"));
        //1.判断 token 是否过期
        // 还没有超过刷新时间，直接通过验证
        if (timeOfUse < refreshTime) {
            log.info("token验证成功");
            return true;
        }
        //超过token刷新时间，并且没有达到过期时间，刷新token
        else if (timeOfUse >= refreshTime && timeOfUse < expiresTime) {
            httpServletResponse.setHeader("Authorization", tokenUtil.getToken(userId, userRoleId));
            log.info("token刷新成功：" + tokenUtil.getToken(userId, userRoleId));
            return true;
        }
        //token过期就返回 token 无效.
        else {
            log.info("token过期");
            throw new CustomException(String.valueOf(ResponseCode.TOKEN_INVALID.val()));
        }
    }

}
