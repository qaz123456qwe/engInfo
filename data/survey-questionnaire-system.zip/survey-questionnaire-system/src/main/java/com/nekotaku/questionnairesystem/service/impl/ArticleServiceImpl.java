package com.nekotaku.questionnairesystem.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.bean.copier.CopyOptions;
import cn.hutool.core.util.ObjUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.OrderItem;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.extension.conditions.update.LambdaUpdateChainWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.nekotaku.questionnairesystem.common.R.ResponseCode;
import com.nekotaku.questionnairesystem.common.constants.redis.RedisConstants;
import com.nekotaku.questionnairesystem.common.constants.upload.UpLoadConstants;
import com.nekotaku.questionnairesystem.common.enums.ArticleStatus;
import com.nekotaku.questionnairesystem.common.enums.EmailType;
import com.nekotaku.questionnairesystem.common.enums.ReportResult;
import com.nekotaku.questionnairesystem.common.page.QueryPageParam;
import com.nekotaku.questionnairesystem.entity.Article;
import com.nekotaku.questionnairesystem.mapper.ArticleMapper;
import com.nekotaku.questionnairesystem.service.ArticleService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.nekotaku.questionnairesystem.service.CategoryService;
import com.nekotaku.questionnairesystem.service.MailService;
import com.nekotaku.questionnairesystem.utils.RegexPatterns;
import com.nekotaku.questionnairesystem.utils.file.UploadUtils;
import com.nekotaku.questionnairesystem.utils.redis.RedisBeanUtil;
import com.nekotaku.questionnairesystem.vo.ArticleVo;
import com.nekotaku.questionnairesystem.vo.front.ArticleFrontVo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.util.HtmlUtils;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * <p>
 * 文章服务实现类
 * </p>
 *
 * @author nekotaku
 * @since 2024-03-19
 */
@Service
@Slf4j
public class ArticleServiceImpl extends ServiceImpl<ArticleMapper, Article> implements ArticleService {

    @Autowired
    private ArticleMapper articleMapper;

    @Autowired
    private RedisBeanUtil redisBeanUtil;

    @Autowired
    @Qualifier("articleRedisTemplate")
    private RedisTemplate<String, ArticleVo> articleVoRedisTemplate;

    @Autowired
    private UploadUtils uploadUtils;

    @Autowired
    private CategoryService categoryService;

    @Autowired
    private MailService mailService;

    @Value("${back.ipAddress}")
    private String ipAddress;


    /**
     * 新增或者修改文章基本信息
     *
     * @param article
     * @return
     */
    @Override
    @Transactional
    public Integer saveOrUpdateArticle(Article article) {

        // 图片路径是否相同的flag
        boolean isSameImg = false;

        // 如果更新了封面图，删除旧封面图用
        String tempImgUrl = null;

        // 将文章名去除空格
        article.setArticleTitle(article.getArticleTitle().trim());

        // 验证当前用户的标题是否存在
        LambdaQueryWrapper<Article> qw = new LambdaQueryWrapper<>();
        qw.eq(Article::getUserId, article.getUserId());
        qw.eq(Article::getArticleTitle, article.getArticleTitle());

        // 判断articleId是否存在，如果存在则表示更新操作
        if (!ObjUtil.isNull(article.getArticleId())) {
            qw.ne(Article::getArticleId, article.getArticleId());
            // 判断封面图是否更新了
            tempImgUrl = articleMapper.selectById(article.getArticleId()).getArticleImage();
            if (tempImgUrl.equals(article.getArticleImage())) {
                isSameImg = true;
            }
        }
        // 标题重复
        if (articleMapper.selectCount(qw) > 0) {
            return ResponseCode.ARTICLE_TITLE_EXIST.val();
        }

        // 保存文章基本信息
        boolean res = this.saveOrUpdate(article);
        if (res) {
            // 更新redis信息
            ArticleVo articleVoFromRedis = getArticleVoFromRedis(article.getArticleId());
            if (BeanUtil.isNotEmpty(articleVoFromRedis)) {
                // 判断分类是否修改
                if (!articleVoFromRedis.getCategoryId().equals(article.getCategoryId())) {
                    articleVoFromRedis.setCategoryName(categoryService.getById(article.getCategoryId()).getCategoryName());
                }
                // 标签处理
                List<String> tags = Arrays.asList(article.getArticleTag().split(","));
                articleVoFromRedis.setTags(tags);

                // 原本的内容(审核改变状态时，带了内容字段)
                String articleContent = articleVoFromRedis.getArticleContent();
                // 排除null字段(信息修改时不带内容字段)
                CopyOptions options = new CopyOptions().setIgnoreNullValue(true);
                BeanUtil.copyProperties(article, articleVoFromRedis, options);

                if(StrUtil.isNotBlank(articleContent)){
                    // 审核改变状态时，不改变原有的内容字段
                    articleVoFromRedis.setArticleContent(articleContent);
                }
                setArticleVoForRedis(article.getArticleId(), articleVoFromRedis);
            }
            // 是否是更新操作，并且图片是否更新了
            if (isSameImg) {
                // 更新操作切图片相同,不用再处理图片
                log.info("更新文章基本信息，封面图未更新");
                return ResponseCode.SUCCESS.val();
            } else if (!ObjUtil.isNull(tempImgUrl)) {
                // 更新操作，并且图片更新了，需要删除旧图片
                uploadUtils.deleteFileByPath(tempImgUrl);
            }
            // 处理封面图的具体存放位置(将临时文件拷贝到具体存放的映射目录)
            String articleImage = article.getArticleImage();
            uploadUtils.copyTempFile(articleImage, UpLoadConstants.ARTICLE_COVER, article.getUserId());

            return ResponseCode.SUCCESS.val();
        }

        return ResponseCode.FAIL.val();
    }

    /**
     * 分页查询文章列表
     *
     * @param queryPageParam 条件参数
     * @param userId
     * @return
     */
    @Override
    public Page<ArticleVo> listArticle(QueryPageParam queryPageParam, Long userId) {

        Page<Article> articlePage = new Page<>();

        // 设置当前页
        articlePage.setCurrent(queryPageParam.getPageNum());

        // 设置当前页面数量
        articlePage.setSize(queryPageParam.getPageSize());

        // 按照最新数据查询(从后往前面查询)
        articlePage.setOrders(Arrays.asList(OrderItem.desc("update_time")));

        // 获取条件(判断是否带条件查询)
        HashMap param = queryPageParam.getParam();
        LambdaQueryWrapper<Article> qw = new LambdaQueryWrapper<>();
        String articleTitle = param.get("articleTitle").toString();
        String status = param.get("status").toString();
        String categoryId = param.get("categoryId").toString();

        // 按照条件查询
        // 标题(模糊查询)
        if (StrUtil.isNotBlank(articleTitle) && !"null".equals(articleTitle)) {
            qw.like(Article::getArticleTitle, articleTitle);
        }
        // 状态
        if (StrUtil.isNotBlank(status) && !"null".equals(status)) {
            qw.eq(Article::getArticleIsOpen, Integer.parseInt(status));
        }
        // 分类
        if (StrUtil.isNotBlank(categoryId) && !"null".equals(categoryId)) {
            qw.eq(Article::getCategoryId, Long.parseLong(categoryId));
        }

        // 根据用户id匹配，得到当前用户的文章列表
        qw.eq(Article::getUserId, userId);

        // 原型查询结果
        Page<Article> res = this.page(articlePage, qw);

        // 拷贝成vo对象
        Page<ArticleVo> resVo = new Page<>();
        resVo.setSize(res.getSize());
        resVo.setCurrent(res.getCurrent());
        resVo.setTotal(res.getTotal());
        // 标签处理、分类处理和状态处理
        List<Article> articles = res.getRecords();
        List<ArticleVo> articleVos = new ArrayList<>();
        for (int i = 0; i < articles.size(); i++) {
            Article article = articles.get(i);
            // 拷贝成VO对象
            ArticleVo articleVo = this.copyArticle(article);
            articleVo.setArticleStatus(articleVo.getArticleIsOpen());
            // 添加到集合
            articleVos.add(articleVo);
        }
        resVo.setRecords(articleVos);

        return resVo;
    }

    /**
     * 改变文章状态
     *
     * @param articleId
     * @return
     */
    @Override
    public Integer changeArticleStatus(Long articleId) {

        Article article = articleMapper.selectById(articleId);

        Integer articleIsOpen = article.getArticleIsOpen();

        if (articleIsOpen == ArticleStatus.NOT_WRITTEN.getStatusId()) {
            // 还没有攥写内容，不可修改状态
            return ResponseCode.ARTICLE_NOT_WRITTEN.val();
        }

        // 文章被封禁，需要重新更改审核
        if (articleIsOpen == ArticleStatus.ARTICLE_BAN.getStatusId()) {
            return ResponseCode.ARTICLE_IS_BAN.val();
        }
        //  文章封禁审核中
        if (articleIsOpen == ArticleStatus.ARTICLE_AUDIT.getStatusId()) {
            return ResponseCode.ARTICLE_IS_AUDIT.val();
        }

        // 判断状态改变成另一个
        if (articleIsOpen == ArticleStatus.PRIVATE.getStatusId()) {
            // 不可浏览-》可浏览
            article.setArticleIsOpen(ArticleStatus.OPEN.getStatusId());
        } else if (articleIsOpen == ArticleStatus.OPEN.getStatusId()) {
            // 可浏览-》不可浏览
            article.setArticleIsOpen(ArticleStatus.PRIVATE.getStatusId());
        } else {
            return ResponseCode.FAIL.val();
        }

        int res = articleMapper.updateById(article);

        // 更新redis缓存
        ArticleVo articleVoFromRedis = getArticleVoFromRedis(articleId);
        if (BeanUtil.isNotEmpty(articleVoFromRedis)) {
            articleVoFromRedis.setArticleIsOpen(article.getArticleIsOpen());
            articleVoFromRedis.setUpdateTime(article.getUpdateTime());
            setArticleVoForRedis(articleId, articleVoFromRedis);
        }

        if (res > 0) {
            return ResponseCode.SUCCESS.val();
        }
        return ResponseCode.FAIL.val();
    }

    /**
     * 删除文章
     *
     * @param articleId
     * @return
     */
    @Override
    public Integer deleteArticle(String articleId) {

        // 获取文章封面图路径
        if (BeanUtil.isNotEmpty(articleId)) {
            String articleCover = articleMapper.selectById(Long.parseLong(articleId)).getArticleImage();
            //  根据id删除文章
            int res = articleMapper.deleteById(articleId);
            if (res > 0) {
                // 删除封面图
                uploadUtils.deleteFileByPath(articleCover);
                // 删除redis中缓存
                delArticleVoForRedis(Long.parseLong(articleId));
                return ResponseCode.SUCCESS.val();
            }
        }
        return ResponseCode.FAIL.val();
    }

    /**
     * 根据id获取文章
     *
     * @param articleId
     * @return
     */
    @Override
    @Transactional
    public ArticleVo getArticleVoById(String articleId) {

        long id = Long.parseLong(articleId);

        // 查看redis中是否有，有的话直接返回
        ArticleVo articleVoFromRedis = getArticleVoFromRedis(id);
        if (BeanUtil.isNotEmpty(articleVoFromRedis)) {
            return articleVoFromRedis;
        }

        Article article = articleMapper.selectById(articleId);
        ArticleVo articleVo = this.copyArticle(article);

        // 内容解码
        String articleContent = articleVo.getArticleContent();
        if (StrUtil.isNotBlank(articleContent)) {
            articleVo.setArticleContent(HtmlUtils.htmlUnescape(articleContent));
            // 保存到redis中
            setArticleVoForRedis(id, articleVo);
        }
        return articleVo;
    }

    /**
     * 根据id获取文章，管理员或者个人查看用
     *
     * @param articleId
     * @param userId
     * @param isAdmin
     * @return
     */
    @Override
    public ArticleVo getArticleVoById(String articleId, Long userId, boolean isAdmin) {

        Article article = articleMapper.selectById(Long.parseLong(articleId));

        // 判断是否是自己或者管理员查看
        if (article.getUserId().equals(userId) || isAdmin) {
            ArticleVo articleVo = this.copyArticle(article);
            // 内容解码
            String articleContent = articleVo.getArticleContent();
            if (StrUtil.isNotBlank(articleContent)) {
                articleVo.setArticleContent(HtmlUtils.htmlUnescape(articleContent));
            }
            return articleVo;
        }

        return null;
    }

    /**
     * 保存文章内容
     *
     * @param article
     * @return
     */
    @Override
    @Transactional
    public Integer saveArticleContent(Article article) {

        // 获取文章的图片路径
        List<String> contentAllImageSrc = this.getContentAllImageSrc(article.getArticleContent());

        // 将内容进行编码转义
        String articleContent = HtmlUtils.htmlEscape(article.getArticleContent(), "UTF-8");

        // 获取旧的内容
        Article selectById = articleMapper.selectById(article.getArticleId());

        // 解码获取真实内容
        String articleOldContent = "";
        if (StrUtil.isNotBlank(selectById.getArticleContent())) {
            // 不是第一次撰写，获取旧内容的解码
            articleOldContent = HtmlUtils.htmlUnescape(selectById.getArticleContent());
        }

        // 获取旧内容的所有图片路径
        List<String> contentAllOldImageSrc = this.getContentAllImageSrc(articleOldContent);

        // 检查是否没有更改
        if (StrUtil.isNotBlank(articleOldContent)
                && articleOldContent.equals(article.getArticleContent())) {
            // 没有发生任何改变
            return ResponseCode.SUCCESS.val();
        }

        // 移除没有更新的图片
        List<String> updateImageSrc = new ArrayList<>(contentAllImageSrc);
        updateImageSrc.removeIf(contentAllOldImageSrc::contains);

        // 更改状态，变为可浏览(所有第一次发表的文章都变为可浏览状态)
        if (article.getArticleIsOpen() == ArticleStatus.NOT_WRITTEN.getStatusId()) {
            article.setArticleIsOpen(ArticleStatus.OPEN.getStatusId());
        }

        // 更新数据库内容，指定固定的值更新(指定更新会影响自动填充器，所以手动更新时间)
        LocalDateTime now = LocalDateTime.now();
        LambdaUpdateChainWrapper<Article> uwq = new LambdaUpdateChainWrapper<>(articleMapper);
        boolean updateRes = uwq.eq(Article::getArticleId, article.getArticleId())
                .set(Article::getArticleIsOpen, article.getArticleIsOpen())
                .set(Article::getArticleContent, articleContent)
                .set(Article::getUpdateTime, now).update();

        // 更新完成，处理图片文件
        if (updateRes) {
            // 将临时文件夹的图片拷贝到正式文件夹下
            if (!updateImageSrc.isEmpty()) {
                for (String src : updateImageSrc) {
                    uploadUtils.copyTempFile(src, UpLoadConstants.ARTICLE_CONTENT_IMAGE, article.getUserId());
                }
            }
            // 删除旧内容的照片
            if (!contentAllOldImageSrc.isEmpty()) {
                // 找到旧内容没有使用的照片
                List<String> oldImage = this.findOldImage(contentAllImageSrc, contentAllOldImageSrc);
                if (!oldImage.isEmpty()) {
                    // 进行删除操作
                    for (String src : oldImage) {
                        uploadUtils.deleteFileByPath(src);
                    }
                }
            }
            // 更新redis
            ArticleVo articleVoFromRedis = getArticleVoFromRedis(article.getArticleId());
            // 判断是否为空，缓存只有第一次查看的时候才会加入。第一次撰写内容保存不会加入缓存
            if (BeanUtil.isNotEmpty(articleVoFromRedis)) {
                articleVoFromRedis.setArticleContent(article.getArticleContent());
                articleVoFromRedis.setUpdateTime(now);
                setArticleVoForRedis(article.getArticleId(), articleVoFromRedis);
            }
            return ResponseCode.SUCCESS.val();
        }

        return ResponseCode.FAIL.val();
    }

    /**
     * 更新浏览量
     *
     * @param articleId
     * @param userId
     * @return
     */
    @Override
    public Integer updateViews(String articleId, Long userId) {

        Article article = articleMapper.selectById(articleId);

        // 排除自己查看
        if (BeanUtil.isNotEmpty(userId) && article.getUserId().equals(userId)) {
            // 自己查看排除
            return ResponseCode.SUCCESS.val();
        }

        LambdaUpdateChainWrapper<Article> uwq = new LambdaUpdateChainWrapper<>(articleMapper);

        if (!article.getArticleIsOpen().equals(ArticleStatus.NOT_WRITTEN.getStatusId())) {
            // 更新浏览数量
            boolean updateRes = uwq.eq(Article::getArticleId, articleId)
                    .set(Article::getArticleViews, article.getArticleViews() + 1).update();
            if (updateRes) {
                log.info("文章id：{},更新浏览量成功", articleId);
                // 更新redis
                long id = Long.parseLong(articleId);
                ArticleVo articleVoFromRedis = getArticleVoFromRedis(id);
                if (BeanUtil.isNotEmpty(articleVoFromRedis)) {
                    articleVoFromRedis.setArticleViews(article.getArticleViews() + 1);
                    setArticleVoForRedis(id, articleVoFromRedis);
                }
                return ResponseCode.SUCCESS.val();
            }
        }
        log.info("文章id：{},更新浏览量失败", articleId);
        return ResponseCode.FAIL.val();
    }

    /**
     * 文章审批改变状态
     *
     * @param reportArticleId
     * @param reportResult
     * @param userEmail
     * @param reportStatus
     * @return
     */
    @Override
    @Transactional
    public Integer setReportResult(Long reportArticleId, Integer reportResult, String userEmail, Integer reportStatus) {
        // 确认文章是否存在
        Article article = articleMapper.selectById(reportArticleId);

        if (BeanUtil.isEmpty(article)) {
            // 文章已经不存在
            return ResponseCode.ARTICLE_IS_EMPTY.val();
        }
        // 文章存在，判断结果
        if (reportResult == ReportResult.PASS.getStatusId()) {
            // 文章如果是待审核或者封禁状态，重审解除封禁
            if (article.getArticleIsOpen() == ArticleStatus.ARTICLE_BAN.getStatusId() ||
                    article.getArticleIsOpen() == ArticleStatus.ARTICLE_AUDIT.getStatusId()) {

                // 如果是申述解封发送邮件
                if (article.getArticleIsOpen() == ArticleStatus.ARTICLE_AUDIT.getStatusId()) {
                    this.sendEmail(EmailType.APPEAL_SUCCESS.getTypeName(), userEmail, article.getArticleTitle());
                }
                // 解封
                article.setArticleIsOpen(ArticleStatus.OPEN.getStatusId());
                // 更新文章状态
                return this.saveOrUpdateArticle(article);
            }
            return ResponseCode.SUCCESS.val();
        } else if (reportResult == ReportResult.BAN.getStatusId()) {
            // 实施封禁
            Integer articleBeforeStatus = article.getArticleIsOpen();
            // 更新文章,设置状态为ban
            article.setArticleIsOpen(ArticleStatus.ARTICLE_BAN.getStatusId());
            // 发送邮件通知
            if ((articleBeforeStatus == ArticleStatus.OPEN.getStatusId()
                    || articleBeforeStatus == ArticleStatus.PRIVATE.getStatusId())
                    && reportStatus == ReportResult.NO_DISPOSE.getStatusId()) {
                // 首次封禁
                this.sendEmail(EmailType.BAN.getTypeName(), userEmail, article.getArticleTitle());
            }
            if (articleBeforeStatus == ArticleStatus.ARTICLE_AUDIT.getStatusId()) {
                // 审核不通过
                this.sendEmail(EmailType.APPEAL_FALSE.getTypeName(), userEmail, article.getArticleTitle());
            }
            // 更新文章状态
            return this.saveOrUpdateArticle(article);
        } else if (reportResult == ReportResult.NO_DISPOSE.getStatusId()) {
            // 文章申述(设置文章状态为待审核)
            article.setArticleIsOpen(ArticleStatus.ARTICLE_AUDIT.getStatusId());
            // 邮件通知
            this.sendEmail(EmailType.APPEAL.getTypeName(), userEmail, article.getArticleTitle());
            // 更新文章状态
            return this.saveOrUpdateArticle(article);
        } else {
            return ResponseCode.FAIL.val();
        }
    }

    /**
     * 分页查询所有文章，前台首页用
     *
     * @param queryPageParam 条件参数
     * @return 分页数据
     */
    @Override
    public Page<ArticleFrontVo> listArticleForFront(QueryPageParam queryPageParam) {

        Page<ArticleFrontVo> articlePage = new Page<ArticleFrontVo>();

        // 设置当前页
        articlePage.setCurrent(queryPageParam.getPageNum());

        // 设置当前页面数量
        articlePage.setSize(queryPageParam.getPageSize());

        // 获取条件,进行条件查询
        HashMap param = queryPageParam.getParam();
        QueryWrapper<ArticleFrontVo> qw = new QueryWrapper<>();

        String articleName = param.get("articleName").toString();
        String sort = param.get("sort").toString();
        // 判断条件是否存在
        if (StringUtils.isNotBlank(articleName) && !"null".equals(articleName)) {
            // 模糊查询文章标题
            qw.like("A.article_title", articleName);
        }

        if (StringUtils.isNotBlank(sort) && !"null".equals(sort)) {
            // 按照时间排序
            if(sort.equals("time")){
                // 按照最新数据查询(从后往前排序查询)
                articlePage.setOrders(Arrays.asList(OrderItem.desc("A.update_time")));
            }
            // 按照热度排序
            if(sort.equals("views")){
                articlePage.setOrders(Arrays.asList(OrderItem.desc("A.article_views")));
            }
        }

        // 只显示公开的文章
        qw.eq("A.article_is_open",ArticleStatus.OPEN.getStatusId());


        return articleMapper.selectArticleFront(articlePage,qw);
    }

    /**
     * 审核结果通知
     *
     * @param type 邮件作用
     * @param userEmail 作者邮箱
     * @param articleTitle 文章标题
     */
    @Async
    public void sendEmail(String type, String userEmail, String articleTitle) {

        // 邮件主题
        String subject = "调查问卷平台";
        // 邮件内容
        String message = "";

        // 文章被ban通知
        if (type.equals(EmailType.BAN.getTypeName())) {
            // 邮件信息
            message = "<h3>【调查问卷平台】</h3><br/><p>我们收到了关于您的文章:"
                    + "<span style='color:red'>" + articleTitle + "</span>的举报，并经过核实后发现其内容存在违规行为。基于此，我们不得不对您的文章进行封禁处理。</p>" +
                    "<p>封禁是为了维护我们社区的良好秩序和规范，我们希望每一篇文章都能符合我们的准则和政策。为了重新提交您的文章进行审核，您需要对其内容进行修改，" +
                    "确保其符合我们的规范。请检查并修改您的文章后，重新提交审核，我们将尽快处理您的请求。</p>" +
                    "<p>如有任何疑问或需要进一步帮助，请随时联系我们的客服团队。</p>" +
                    "<p>谢谢您的理解与合作。</p>";
        }

        // 文章申述
        if (type.equals(EmailType.APPEAL.getTypeName())) {
            message = "<h3>【调查问卷平台】</h3><br/><p>我们收到了关于您的文章:"
                    + "<span style='color:red'>" + articleTitle + "</span>的申述，感谢您提交的文章申述。</p>" +
                    "<p>我们将会重新审视您的文章，并尽快作出决定。请您耐心等待，我们会在处理完毕后及时向您反馈结果。</p>" +
                    "<p>如果您有任何其他问题或需要进一步解释，请随时联系我们的客服团队，我们将竭诚为您服务。</p>" +
                    "<p>谢谢您的理解与合作。</p>";
        }

        // 文章申述通过审核
        if (type.equals(EmailType.APPEAL_SUCCESS.getTypeName())) {
            message = "<h3>【调查问卷平台】</h3><br/><p>我们收到了关于您的文章:"
                    + "<span style='color:red'>" + articleTitle + "</span>的申述，感谢您重新提交的文章。我们很高兴地通知您，您的文章已经通过审核，重新上线了！</p>" +
                    "<p>您的文章已经符合了我们的准则和政策，我们相信它将为我们的社区带来价值和启发。再次感谢您的合作和理解。" +
                    "<p>如有任何疑问或需要进一步帮助，请随时联系我们的客服团队。</p>" +
                    "<p>期待您未来更多的优质内容！</p>";
        }

        // 文章申述未通过审核
        if (type.equals(EmailType.APPEAL_FALSE.getTypeName())) {
            message = "<h3>【调查问卷平台】</h3><br/><p>我们收到了关于您的文章:"
                    + "<span style='color:red'>" + articleTitle + "</span>的申述，感谢您提交的文章申述。经过我们再次审核后，很抱歉地通知您，您的申述未能通过审核。</p>" +
                    "<p>在重新审查过程中，我们仔细考虑了您提出的观点，但我们仍然认为您的文章存在违规行为，因此我们必须维持之前的封禁决定。</p>" +
                    "<p>我们非常理解您可能对此感到失望，但我们的审核标准非常严格，我们需要确保每篇文章都符合我们的准则和政策，以维护我们社区的良好秩序。</p>" +
                    "<p>如果您有任何其他问题或需要进一步解释，请随时联系我们的客服团队，我们将竭诚为您服务。</p>" +
                    "<p>谢谢您的理解与合作。</p>";
        }

        // 发送邮件
        try {
            mailService.sendMail(userEmail, subject, message);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 拷贝成vo对象
     *
     * @param article
     * @return
     */
    private ArticleVo copyArticle(Article article) {
        ArticleVo articleVo = new ArticleVo();
        BeanUtils.copyProperties(article, articleVo);
        // 标签切割(以“,”分割)
        List<String> tags = Arrays.asList(article.getArticleTag().split(","));
        articleVo.setTags(tags);
        // 分类名查询
        articleVo.setCategoryName(categoryService.getById(article.getCategoryId()).getCategoryName());

        return articleVo;
    }


    /**
     * 用正则表达式获取文章内容的所有img图片的src路径
     *
     * @param content
     * @return
     */
    private List<String> getContentAllImageSrc(String content) {

        // 编译正则表达式
        Pattern pattern = Pattern.compile(RegexPatterns.IMG_REGEX);
        // 创建 Matcher 对象并进行匹配
        Matcher matcher = pattern.matcher(content);

        // 创建列表来存储所有的src内容
        List<String> srcList = new ArrayList<>();

        // 循环匹配，获取所有的src内容
        while (matcher.find()) {
            // 提取第一个捕获组的内容
            String src = matcher.group(1);
            // 去除路径前面的服务器地址
            // 路径格式："http://localhost:8127/asset/articleImage/1730595089106980866/2024-03-24/68ea20ca96e1455ba6a4aa1d55af34ca.jpg"
            src = src.replace(ipAddress, "");
            // 将匹配到的src添加到列表中
            srcList.add(src.trim());
        }
        return srcList;
    }

    /**
     * 找到没有使用的文章内容图片文件
     *
     * @param newImageList
     * @param oldImageList
     * @return
     */
    private List<String> findOldImage(List<String> newImageList, List<String> oldImageList) {
        List<String> list = new ArrayList<>();
        // 如果新内容没有图片了，直接返回旧的内容图片
        if (newImageList.isEmpty()) {
            return oldImageList;
        }
        for (String oldImage : oldImageList) {
            // 对比新图片列表和旧图片列表，如果旧图片不在新图片列表中，则说明没有使用，将其添加到list中
            if (!newImageList.contains(oldImage)) {
                list.add(oldImage);
            }
        }
        return list;
    }

    /**
     * 从redis中获取文章
     *
     * @param articleId
     * @return
     */
    private ArticleVo getArticleVoFromRedis(Long articleId) {
        String key = RedisConstants.ARTICLE + articleId;
        ArticleVo articleVoFromRedis = redisBeanUtil.get(articleVoRedisTemplate, key);
        return articleVoFromRedis;
    }

    /**
     * 保存文章到redis
     *
     * @param articleId
     * @param articleVo
     */
    private void setArticleVoForRedis(Long articleId, ArticleVo articleVo) {
        String key = RedisConstants.ARTICLE + articleId;
        redisBeanUtil.set(articleVoRedisTemplate, key, articleVo);
    }

    /**
     * 删除redis中缓存的文章
     *
     * @param articleId
     */
    private void delArticleVoForRedis(Long articleId) {
        // 判断缓存中是否有
        if (BeanUtil.isNotEmpty(getArticleVoFromRedis(articleId))) {
            String key = RedisConstants.ARTICLE + articleId;
            redisBeanUtil.delete(articleVoRedisTemplate, key);
        }
    }

}
