package com.nekotaku.questionnairesystem.common.R;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 统一结果返回集
 *
 * @Title:Result
 * @Author:NekoTaku
 * @Date:2023/11/20 19:47
 * @Version:1.0
 */
@Data
public class Result {


    @ApiModelProperty("请求响应码")
    private int code;

    @ApiModelProperty("请求消息体")
    private String msg;

    @ApiModelProperty("请求响应数据")
    private Object data;

    @ApiModelProperty("请求响应数据总数")
    private Long total; // 总记录数


    public static Result success(String msg,Object data) {
        return result(ResponseCode.SUCCESS.val(), msg, data, 0L);
    }
    public static Result success(Object data) {
        return result(ResponseCode.SUCCESS.val(), "", data, 0L);
    }

    public static Result success(int code, String msg) {
        return result(code, msg, null, 0L);
    }
    public static Result success(int code, String msg, Object data) {
        return result(code, msg, data, 0L);
    }
    public static Result success(int code, String msg, Object data, Long total) {
        return result(code, msg, data, total);
    }

    public static Result fail(int code, String msg) {
        return result(code, msg, null, 0L);
    }

    public static Result result(int code, String msg, Object data, Long total) {
        Result res = new Result();
        res.setCode(code);
        res.setMsg(msg);
        res.setData(data);
        res.setTotal(total);
        return res;
    }
}
