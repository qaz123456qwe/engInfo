package com.nekotaku.questionnairesystem.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.nekotaku.questionnairesystem.common.R.ResponseCode;
import com.nekotaku.questionnairesystem.common.enums.QuestionType;
import com.nekotaku.questionnairesystem.common.enums.TmpSurveyStatus;
import com.nekotaku.questionnairesystem.vo.QuestionTmpVo;
import com.nekotaku.questionnairesystem.entity.TmpOption;
import com.nekotaku.questionnairesystem.entity.TmpQuestion;
import com.nekotaku.questionnairesystem.entity.TmpSurvey;
import com.nekotaku.questionnairesystem.mapper.TmpQuestionMapper;
import com.nekotaku.questionnairesystem.service.TmpOptionService;
import com.nekotaku.questionnairesystem.service.TmpQuestionService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.nekotaku.questionnairesystem.service.TmpSurveyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;

/**
 * <p>
 * 模板问卷问题表 服务实现类
 * </p>
 *
 * @author nekotaku
 * @since 2024-03-04
 */
@Service
public class TmpQuestionServiceImpl extends ServiceImpl<TmpQuestionMapper, TmpQuestion> implements TmpQuestionService {

    @Autowired
    private TmpQuestionMapper tmpQuestionMapper;

    @Autowired
    private TmpSurveyService tmpSurveyService;

    @Autowired
    private TmpOptionService tmpOptionService;

    /**
     * 保存问卷模板
     *
     * @param questionTmpVo
     * @return
     */
    @Override
    @Transactional
    public Integer saveQuestion(List<QuestionTmpVo> questionTmpVo) {

        // 获取模板问卷id
        Long tmpId = questionTmpVo.get(0).getTmpId();

        TmpSurvey tmpSurveyById = tmpSurveyService.getTmpSurveyById(tmpId);

        // 判断是新增还是更新
        if (tmpSurveyById.getTmpSurveyStatus() != TmpSurveyStatus.UN_DESIGNED.getStatusId()) {
            // 更新操作，删除之前的问题
            deleteTmpQuestions(tmpId);
        }

        // 保存问题
        ArrayList<TmpQuestion> tmpQuestions = new ArrayList<>();
        for (QuestionTmpVo dto : questionTmpVo) {
            TmpQuestion tmpQuestion = new TmpQuestion();
            // 拷贝对象
            BeanUtil.copyProperties(dto, tmpQuestion);
            tmpQuestions.add(tmpQuestion);
        }

        // 执行提交保存
        if (!this.saveBatch(tmpQuestions)) {
            return ResponseCode.FAIL.val();
        }

        // 根据模板id查询保存好的问卷问题，设置选项的问题Id
        List<TmpQuestion> tmpQuestionsByOrder = getTmpQuestionsByOrder(tmpId);
        for (int i = 0; i < questionTmpVo.size(); i++) {
            // 判断单选还是多选
            if (questionTmpVo.get(i).getTmpQuestionType() != QuestionType.TEXTAREA.getTypeId()) {
                for (int j = 0; j < questionTmpVo.get(i).getOption().size(); j++) {
                    questionTmpVo.get(i).getOption().get(j)
                            .setTmpQuestionId(tmpQuestionsByOrder.get(i).getTmpQuestionId());
                }
            }
        }

        // 保存模板选项
        ArrayList<TmpOption> tmpOptions = new ArrayList<>();
        for (QuestionTmpVo dto : questionTmpVo) {
            // 排除客观题
            if (dto.getTmpQuestionType() != QuestionType.TEXTAREA.getTypeId()) {
                tmpOptions.addAll(dto.getOption());
            }
        }
        // 执行批量保存
        if (!tmpOptions.isEmpty()) {
            if (!tmpOptionService.saveBatch(tmpOptions)) {
                return ResponseCode.FAIL.val();
            }
        }

        // 更新模板问卷状态
        return tmpSurveyService.changeTmpSurveyStatus(tmpId, TmpSurveyStatus.DESIGNED.getStatusId());
    }

    /**
     * 根据模板id删除问题
     *
     * @param tmpId
     */
    @Override
    public void deleteTmpQuestions(Long tmpId) {
        LambdaQueryWrapper<TmpQuestion> qw = new LambdaQueryWrapper<>();
        qw.eq(TmpQuestion::getTmpId, tmpId);
        tmpQuestionMapper.delete(qw);
    }

    /**
     * 根据问卷模板id查询问题和选项(具体逻辑参考QuestionServiceImpl.getQuestions)
     *
     * @param tmpId
     * @return
     */
    @Override
    public List<QuestionTmpVo> getTmpQuestions(Long tmpId) {

        // 查询状态是否设计了
        if (tmpSurveyService.getTmpSurveyById(tmpId).getTmpSurveyStatus()
                != TmpSurveyStatus.DESIGNED.getStatusId()) {
            return null;
        }

        // 通过sql连接查询(会造成笛卡尔积情况，逻辑上进行处理)
        List<QuestionTmpVo> questionsAndOptionsByTmpId = tmpQuestionMapper.getQuestionsAndOptionsByTmpId(tmpId);

        // 通过LinkedHashSet去重
        LinkedHashSet<QuestionTmpVo> questionTmpVo = new LinkedHashSet<>(questionsAndOptionsByTmpId);

        // 再转换为ArrayList
        questionsAndOptionsByTmpId = new ArrayList<>(questionTmpVo);

        // 排序
        CollUtil.sort(questionsAndOptionsByTmpId,
                Comparator.comparing(TmpQuestion::getTmpQuestionSort));

        // 设置问题类型值
        for (QuestionTmpVo questionTmpVo1 : questionsAndOptionsByTmpId) {
            questionTmpVo1.setQuestionTypeValue(
                    QuestionType.getByTypeId(questionTmpVo1.getTmpQuestionType()).getTypeValue());
        }

        return questionsAndOptionsByTmpId;
    }

    /**
     * 根据问卷模板id和题目模板序号将问题按照顺序查询出来
     *
     * @param tmpId
     * @return
     */
    private List<TmpQuestion> getTmpQuestionsByOrder(Long tmpId) {
        LambdaQueryWrapper<TmpQuestion> qw = new LambdaQueryWrapper<>();
        qw.eq(TmpQuestion::getTmpId, tmpId);
        qw.orderByAsc(TmpQuestion::getTmpQuestionSort);
        return tmpQuestionMapper.selectList(qw);
    }


}
