package com.nekotaku.questionnairesystem.service.impl;

import com.nekotaku.questionnairesystem.entity.Role;
import com.nekotaku.questionnairesystem.mapper.RoleMapper;
import com.nekotaku.questionnairesystem.service.RoleService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 用户角色表 服务实现类
 * </p>
 *
 * @author nekotaku
 * @since 2023-12-10
 */
@Service
@Slf4j
public class RoleServiceImpl extends ServiceImpl<RoleMapper, Role> implements RoleService {

}
