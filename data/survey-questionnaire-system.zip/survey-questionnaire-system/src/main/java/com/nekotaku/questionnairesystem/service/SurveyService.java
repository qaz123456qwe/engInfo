package com.nekotaku.questionnairesystem.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.nekotaku.questionnairesystem.common.R.Result;
import com.nekotaku.questionnairesystem.common.page.QueryPageParam;
import com.nekotaku.questionnairesystem.vo.QuestionVo;
import com.nekotaku.questionnairesystem.vo.SurveyAndQuestionVo;
import com.nekotaku.questionnairesystem.vo.SurveyCountDataVo;
import com.nekotaku.questionnairesystem.vo.SurveyMonthlyCountVo;
import com.nekotaku.questionnairesystem.vo.analysis.AnswerChoiceAnalysisVo;
import com.nekotaku.questionnairesystem.vo.analysis.SurveyAnalysisVo;
import com.nekotaku.questionnairesystem.entity.Survey;
import com.baomidou.mybatisplus.extension.service.IService;
import com.nekotaku.questionnairesystem.vo.front.SurveyFrontVo;

import java.time.LocalDateTime;
import java.util.List;

/**
 * <p>
 * 调查问卷表（主要是问卷的基本信息） 服务类
 * </p>
 *
 * @author nekotaku
 * @since 2023-12-13
 */
public interface SurveyService extends IService<Survey> {

    Integer saveOrUpdateSurvey(Survey survey);

    Page<Survey> listSurveys(QueryPageParam queryPageParam, Long userId);

    Page<SurveyFrontVo> listSurveysForFront(QueryPageParam queryPageParam);

    Integer changeSurveyStatus(Long surveyId, Integer status);

    Survey getSurveyById(Long surveyId);

    SurveyAndQuestionVo getSurveyDetailedById(Long surveyId, List<QuestionVo> questions);

    SurveyAndQuestionVo getSurveyDetailedFromRedis(Long surveyId);

    SurveyAnalysisVo getSurveyAnalysisFromRedis(Long surveyId);

    void saveSurveyDetailsToRedis(Long surveyId, SurveyAndQuestionVo surveyAndQuestionVo);

    void saveSurveyAnalysisToRedis(Long surveyId, SurveyAnalysisVo surveyAnalysisVo);

    Integer publishSurvey(Survey survey, List<QuestionVo> questions);

    Integer changeSurveyTime(Long surveyId, LocalDateTime startTime, LocalDateTime endTime);

    List<Survey> getSurveysByStatus(Integer status);

    void checkSurveyIsStart(Survey survey);

    boolean checkSurveyIsEnd(Survey survey);

    void processSurveyAsync(Survey survey);

    Integer deleteSurveyById(Long surveyId, Long userId);

    void deleteSurveyFromRedis(Long surveyId);

    void deleteSurveyAnalysisFromRedis(Long surveyId);

    Integer updateSurveyCollected(Survey survey);

    SurveyCountDataVo getSurveyCountData(Long userId);

    List<SurveyMonthlyCountVo> getSurveyMonthlyCount(Long userId);

    Result deleteByIds(String ids);

    SurveyAnalysisVo dealWithAnswerCount(SurveyAndQuestionVo survey, List<AnswerChoiceAnalysisVo> answerCountBySurveyId,
                                         Long questionId, Long optionId);

    Integer setReportResult(Long reportSurveyId, Integer reportResult, String userEmail, Integer reportStatus);
}
