package com.nekotaku.questionnairesystem.vo.front;

import com.baomidou.mybatisplus.annotation.TableId;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * @Title:ArticleFrontVo
 * @Author:NekoTaku
 * @Date:2024/05/08 15:33
 * @Version:1.0
 */
@Data
public class ArticleFrontVo implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "文章id")
    @TableId(value = "article_id")
    private Long articleId;

    @ApiModelProperty(value = "文章标题")
    private String articleTitle;

    @ApiModelProperty(value = "文章描述")
    private String articleDesc;

    @ApiModelProperty(value = "文章封面")
    private String articleImage;

    @ApiModelProperty(value = "文章浏览量")
    private Long articleViews;

    @ApiModelProperty(value = "文章标签")
    private String articleTag;

    @ApiModelProperty(value = "分类id")
    private Long categoryId;

    @ApiModelProperty(value = "文章分类名")
    private String categoryName;

    @ApiModelProperty(value = "作者名")
    private String userNickname;

    @ApiModelProperty(value = "文章发表时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
    private LocalDateTime updateTime;

}
