package com.nekotaku.questionnairesystem.common.R;

/**
 * 返回值常量，使用校验框架validation验证时的参数message需要
 *
 * @Title:ResponseConstants
 * @Author:NekoTaku
 * @Date:2023/11/29 23:40
 * @Version:1.0
 */
public class ResponseConstants {

    public static final String INVALID_RESPONSE_CODE = "601";

    public static final String INVALID_CATEGORY_CODE = "609";

    public static final String INVALID_QUESTION_CODE = "613";
}
