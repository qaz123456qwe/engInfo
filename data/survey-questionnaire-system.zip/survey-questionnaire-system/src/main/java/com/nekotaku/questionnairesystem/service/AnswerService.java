package com.nekotaku.questionnairesystem.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.nekotaku.questionnairesystem.common.page.QueryPageParam;
import com.nekotaku.questionnairesystem.vo.analysis.AnswerChoiceAnalysisVo;
import com.nekotaku.questionnairesystem.vo.AnswerVo;
import com.nekotaku.questionnairesystem.vo.analysis.TextQuestionAnalysisVo;
import com.nekotaku.questionnairesystem.entity.Answer;
import com.baomidou.mybatisplus.extension.service.IService;
import com.nekotaku.questionnairesystem.vo.excel.ExcelQuestionVo;
import com.nekotaku.questionnairesystem.vo.excel.ExcelWithChoiceVo;
import com.nekotaku.questionnairesystem.vo.excel.dto.ExportDto;

import java.util.List;

/**
 * <p>
 * 问卷结果表	 服务类
 * </p>
 *
 * @author nekotaku
 * @since 2024-02-20
 */
public interface AnswerService extends IService<Answer> {

    Integer saveAnswer(AnswerVo answerVo, Long logId);

    List<Answer> getAnswerByLogId(Long id);

    List<AnswerChoiceAnalysisVo> getAnswerCountBySurveyId(Long surveyId,Long optionId);

    Page<TextQuestionAnalysisVo> getTextAnswerContextList(Long surveyId, QueryPageParam queryPageParam);

    List<ExcelQuestionVo> getTextAnswerContextListForExcel(Long surveyId);

    List<TextQuestionAnalysisVo> getTextAnswerContextList(Long surveyId);

    List<ExcelWithChoiceVo> getTextWithChoiceAnswer(Long surveyId);

    List<ExportDto> ExcelWithChoiceVoConvertToExportDto(List<ExcelWithChoiceVo> textWithChoiceAnswer);

    void deleteBySurveyId(Long reportSurveyId);
}
