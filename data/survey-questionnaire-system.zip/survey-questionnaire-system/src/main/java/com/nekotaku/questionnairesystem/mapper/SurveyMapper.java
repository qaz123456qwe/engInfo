package com.nekotaku.questionnairesystem.mapper;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Constants;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.nekotaku.questionnairesystem.vo.SurveyMonthlyCountVo;
import com.nekotaku.questionnairesystem.entity.Survey;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.nekotaku.questionnairesystem.vo.front.SurveyFrontVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 调查问卷表（主要是问卷的基本信息） Mapper 接口
 * </p>
 *
 * @author nekotaku
 * @since 2023-12-13
 */
@Mapper
public interface SurveyMapper extends BaseMapper<Survey> {

    // 统计每月发布问卷数量
    List<SurveyMonthlyCountVo> selectSurveyCountByMonth(@Param("userId") Long userId);


    // 查询前台首页的问卷列表
    Page<SurveyFrontVo> selectSurveyFront(Page<SurveyFrontVo> page
            , @Param(Constants.WRAPPER) QueryWrapper<SurveyFrontVo> queryWrapper);

}
