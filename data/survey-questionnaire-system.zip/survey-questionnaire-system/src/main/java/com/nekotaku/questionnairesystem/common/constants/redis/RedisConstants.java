package com.nekotaku.questionnairesystem.common.constants.redis;

/**
 * redis常量
 *
 * @Title:RedisConstants
 * @Author:NekoTaku
 * @Date:2024/02/10 13:48
 * @Version:1.0
 */
public class RedisConstants {

    // 问卷发布
    public static final String PUBLISH_SURVEY = "publish:survey:";

    // 问卷选择题分析
    public static final String ANALYZE_CHOICE_SURVEY = "analyze:survey:choice:";

    // 问卷客观题分析
    public static final String ANALYZE_OBJECTIVE_SURVEY = "analyze:survey:Objective:";

    // 图片所有图片路径
    public static final String UPLOAD_FILE = "upload:";

    // 文章
    public static final String ARTICLE = "article:";

    // 红包列表
    public static final String RED_PACKET="red:packet:";
}
