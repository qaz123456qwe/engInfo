package com.nekotaku.questionnairesystem.vo;

import com.nekotaku.questionnairesystem.entity.Question;
import com.nekotaku.questionnairesystem.entity.QuestionOption;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;

import java.util.List;


/**
 * @Title:QuestionDto
 * @Author:NekoTaku
 * @Date:2024/01/27 14:39
 * @Version:1.0
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class QuestionVo extends Question {

    @ApiModelProperty(value = "选项列表")
    private List<QuestionOption> option;

    @ApiModelProperty(value = "题类型")
    private String questionTypeValue;

    @ApiModelProperty(value = "单选题答案选项id或者客观题内容")
    private String answerContext;

    @ApiModelProperty(value = "多选题答案选项id")
    private List<Long> answersContext;

    @Override
    public String toString() {
        return "[QuestionDto{" +
                "问题ID:" + super.getQuestionId() +
                ", 问卷ID:" + super.getSurveyId() +
                ", 问题类型:" + super.getQuestionType() +
                ", 问题内容:'" + super.getQuestionContent() + '\'' +
                ", 问题顺序:'" + super.getQuestionSort() + '\'' +
                ", QuestionOption=" + option +
                "}]\n";
    }
}
