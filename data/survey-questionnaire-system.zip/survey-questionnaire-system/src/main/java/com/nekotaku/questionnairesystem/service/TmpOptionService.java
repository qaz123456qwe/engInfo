package com.nekotaku.questionnairesystem.service;

import com.nekotaku.questionnairesystem.entity.TmpOption;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 模板选项表 服务类
 * </p>
 *
 * @author nekotaku
 * @since 2024-03-04
 */
public interface TmpOptionService extends IService<TmpOption> {

}
