package com.nekotaku.questionnairesystem.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

/**
 * 问卷和问题 Vo
 *
 * @Title:SurveyAndQuestionDto
 * @Author:NekoTaku
 * @Date:2024/01/31 16:54
 * @Version:1.0
 */
@Data
public class SurveyAndQuestionVo implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "问卷id")
    private Long surveyId;

    @ApiModelProperty(value = "问卷标题")
    private String surveyTitle;

    @ApiModelProperty(value = "问卷描述")
    private String surveyDescription;

    @ApiModelProperty(value = "问卷开始时间")
    private LocalDateTime surveyStartTime;

    @ApiModelProperty(value = "问卷结束时间")
    private LocalDateTime surveyEndTime;

    @ApiModelProperty(value = "问卷状态")
    private Integer surveyStatus;

    @ApiModelProperty(value = "问卷结束语")
    private String surveyTip;

    @ApiModelProperty(value = "问卷问题和对应选项列表)")
    private List<QuestionVo> questions;
}
