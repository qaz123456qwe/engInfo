package com.nekotaku.questionnairesystem.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.date.LocalDateTimeUtil;
import cn.hutool.core.util.ObjUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.OrderItem;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.extension.conditions.update.LambdaUpdateChainWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.nekotaku.questionnairesystem.common.R.ResponseCode;
import com.nekotaku.questionnairesystem.common.R.Result;
import com.nekotaku.questionnairesystem.common.enums.*;
import com.nekotaku.questionnairesystem.common.exception.CustomException;
import com.nekotaku.questionnairesystem.common.lock.TimeoutLock;
import com.nekotaku.questionnairesystem.common.page.QueryPageParam;
import com.nekotaku.questionnairesystem.common.constants.redis.RedisConstants;
import com.nekotaku.questionnairesystem.entity.User;
import com.nekotaku.questionnairesystem.service.MailService;
import com.nekotaku.questionnairesystem.service.UserService;
import com.nekotaku.questionnairesystem.utils.RedPacket;
import com.nekotaku.questionnairesystem.utils.redis.RedisBeanUtil;
import com.nekotaku.questionnairesystem.vo.QuestionVo;
import com.nekotaku.questionnairesystem.vo.SurveyAndQuestionVo;
import com.nekotaku.questionnairesystem.vo.SurveyCountDataVo;
import com.nekotaku.questionnairesystem.vo.SurveyMonthlyCountVo;
import com.nekotaku.questionnairesystem.vo.analysis.*;
import com.nekotaku.questionnairesystem.entity.Survey;
import com.nekotaku.questionnairesystem.mapper.SurveyMapper;
import com.nekotaku.questionnairesystem.service.SurveyService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.nekotaku.questionnairesystem.vo.front.SurveyFrontVo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * <p>
 * 调查问卷表（主要是问卷的基本信息） 服务实现类
 * </p>
 *
 * @author nekotaku
 * @since 2023-12-13
 */
@Service
@Slf4j
public class SurveyServiceImpl extends ServiceImpl<SurveyMapper, Survey> implements SurveyService {

    @Autowired
    private SurveyMapper surveyMapper;

    @Autowired
    private RedisBeanUtil redisBeanUtil;

    @Autowired
    @Qualifier("surveyRedisTemplate")
    private RedisTemplate<String, SurveyAndQuestionVo> redisTemplate;

    @Autowired
    @Qualifier("surveyAnalysisRedisTemplate")
    private RedisTemplate<String, SurveyAnalysisVo> redisAnalysisTemplate;

    @Autowired
    @Qualifier("ObjectiveAnalysisRedisTemplate")
    private RedisTemplate<String, TextQuestionAnalysisVo> objectiveAnalysisRedisTemplate;

    @Autowired
    @Qualifier("integerRedisTemplate")
    private RedisTemplate<String, Integer> listRedisTemplate;

    @Autowired
    private MailService mailService;

    @Autowired
    private UserService userService;

    private final TimeoutLock timeoutLock;

    @Autowired
    public SurveyServiceImpl() {
        // 设置锁超时时间 5秒 传参单位：毫秒
        this.timeoutLock = new TimeoutLock(5000L);
    }

    /**
     * 保存或者更新问卷表基本信息
     *
     * @param survey
     * @return
     */
    @Override
//    @CachePut(value = "surveyCache", key = "'survey_' + #surveyId.toString()")
    public Integer saveOrUpdateSurvey(Survey survey) {

        log.info("添加或更新问卷表基本信息服务");

        // 标题去空格
        survey.setSurveyTitle(survey.getSurveyTitle().trim());

        LambdaQueryWrapper<Survey> qw = new LambdaQueryWrapper<>();

        // 根据userId和标题名判断是否重复
        qw.eq(Survey::getUserId, survey.getUserId());
        qw.eq(Survey::getSurveyTitle, survey.getSurveyTitle());
        // 判单是否更新操作，排除自己重复情况
        if (!ObjUtil.isNull(survey.getSurveyId())) {
            qw.ne(Survey::getSurveyId, survey.getSurveyId());

            // 更新操作时，判断问卷限制数量是否修改，如果修改且小于当前已收集的问卷数量，则不能修改
            Survey surveyById = getSurveyById(survey.getSurveyId());
            if (surveyById.getSurveyCollected() >= survey.getSurveyCollectedLimit()) {
                // 超过数量不能修改
                return ResponseCode.SURVEY_UPDATE_INVALID.val();
            }
        }
        if (surveyMapper.selectCount(qw) > 0) {
            return ResponseCode.SURVEY_TITLE_EXIST.val();
        }
        // 保存
        boolean res = this.saveOrUpdate(survey);
        // 更新redis
        SurveyAndQuestionVo surveyDetailedFromRedis = getSurveyDetailedFromRedis(survey.getSurveyId());
        if (BeanUtil.isNotEmpty(surveyDetailedFromRedis)) {
            // 说明redis中有，更新redis的数据
            BeanUtil.copyProperties(survey, surveyDetailedFromRedis);
            saveSurveyDetailsToRedis(survey.getSurveyId(), surveyDetailedFromRedis);
        }
        if (res) {
            return ResponseCode.SUCCESS.val();
        }
        return ResponseCode.FAIL.val();
    }

    /**
     * 分页查询当前用户所有问卷信息(可带条件查询)
     *
     * @param queryPageParam
     * @param userId
     * @return
     */
    @Override
    public Page<Survey> listSurveys(QueryPageParam queryPageParam, Long userId) {
        log.info("分页查询问卷列表服务");
        Page<Survey> surveyPage = new Page<>();

        // 设置当前页
        surveyPage.setCurrent(queryPageParam.getPageNum());

        // 设置当前页面数量
        surveyPage.setSize(queryPageParam.getPageSize());

        // 按照最新数据查询(从后往前排序查询)
        surveyPage.setOrders(Arrays.asList(OrderItem.desc("update_time")));

        // 获取条件,进行条件查询
        HashMap param = queryPageParam.getParam();
        String surveyTitle = param.get("surveyTitle").toString();
        String surveyStatus = param.get("surveyStatus").toString();
        String surveyCategoryId = param.get("surveyCategoryId").toString();
        LambdaQueryWrapper<Survey> qw = new LambdaQueryWrapper<>();
        // 判断条件是否存在
        if (StringUtils.isNotBlank(surveyTitle) && !"null".equals(surveyTitle)) {
            // 模糊查询问卷标题
            qw.like(Survey::getSurveyTitle, surveyTitle);
        }
        if (StringUtils.isNotBlank(surveyStatus) && !"null".equals(surveyStatus)) {
            // 匹配问卷状态
            qw.eq(Survey::getSurveyStatus, Integer.parseInt(surveyStatus));
        }
        if (StringUtils.isNotBlank(surveyCategoryId) && !"null".equals(surveyCategoryId)) {
            // 匹配问卷分类
            qw.eq(Survey::getSurveyCategoryId, Long.parseLong(surveyCategoryId));
        }
        // 排除掉已完成的答卷(如果不是已完成问卷列表的话)
        if (!surveyStatus.equals(String.valueOf(SurveyStatus.COMPLETED.getStatusId()))) {
            qw.ne(Survey::getSurveyStatus, SurveyStatus.COMPLETED.getStatusId());
        }
        qw.eq(Survey::getUserId, userId);

        return this.page(surveyPage, qw);
    }

    /**
     * 分页查询所有问卷信息，前台首页用
     *
     * @param queryPageParam
     * @return
     */
    @Override
    public Page<SurveyFrontVo> listSurveysForFront(QueryPageParam queryPageParam) {
        Page<SurveyFrontVo> surveyPage = new Page<>();

        // 设置当前页
        surveyPage.setCurrent(queryPageParam.getPageNum());

        // 设置当前页面数量
        surveyPage.setSize(queryPageParam.getPageSize());

        // 按照最新数据查询(从后往前排序查询)
        surveyPage.setOrders(Arrays.asList(OrderItem.desc("A.update_time")));

        // 获取条件,进行条件查询
        HashMap param = queryPageParam.getParam();
        String surveyTitle = param.get("surveyTitle").toString();
        String surveyStatus = param.get("surveyStatus").toString();
        QueryWrapper<SurveyFrontVo> qw = new QueryWrapper<>();
        // 判断条件是否存在
        if (StringUtils.isNotBlank(surveyTitle) && !"null".equals(surveyTitle)) {
            // 首先根据标题条件进行模糊查询
            qw.like("A.survey_title", surveyTitle)
                    // 并且进一步筛选，确保查询结果仅包含符合状态条件的问卷
                    .and(wrapper -> {
                        // 是否连接查询
                        if (StringUtils.isNotBlank(surveyStatus) && !"null".equals(surveyStatus)) {
                            wrapper.eq("A.survey_status", Integer.parseInt(surveyStatus));
                        } else {
                            // 使用'and'条件筛选状态
                            wrapper.eq("A.survey_status", SurveyStatus.COMPLETED.getStatusId())
                                    .or()
                                    .eq("A.survey_status", SurveyStatus.PUBLISHED.getStatusId());
                        }
                    });
        } else if (StringUtils.isNotBlank(surveyStatus) && !"null".equals(surveyStatus)) {
            // 匹配问卷状态
            qw.eq("A.survey_status", Integer.parseInt(surveyStatus));
        } else {
            // 如果没有标题条件，则应用默认的状态条件
            qw.eq("A.survey_status", SurveyStatus.COMPLETED.getStatusId())
                    .or()
                    .eq("A.survey_status", SurveyStatus.PUBLISHED.getStatusId());
        }

        return surveyMapper.selectSurveyFront(surveyPage, qw);
    }

    /**
     * 更新问卷状态
     *
     * @param surveyId
     * @param status
     * @return
     */
    @Transactional
//    @CachePut(value = "surveyCache", key = "'survey_' + #surveyId.toString()")
    public Integer changeSurveyStatus(Long surveyId, Integer status) {
        log.info("更新问卷状态服务:" + surveyId);
        Survey survey = getSurveyById(surveyId);
        if (survey != null) {

            // 如果文章状态为封禁，并且status不为待审核，则保持不变
            if (survey.getSurveyStatus().equals(SurveyStatus.SURVEY_BAN.getStatusId())
                    && !status.equals(SurveyStatus.SURVEY_AUDIT.getStatusId())) {
                survey.setSurveyStatus(SurveyStatus.SURVEY_BAN.getStatusId());
            } else {
                survey.setSurveyStatus(status);
            }

            if (surveyMapper.updateById(survey) > 0) {
                // 查询redis的缓存，如果非空则更新redis缓存的状态
                SurveyAndQuestionVo surveyDetailedFromRedis = getSurveyDetailedFromRedis(surveyId);
                if (!BeanUtil.isEmpty(surveyDetailedFromRedis)) {
                    surveyDetailedFromRedis.setSurveyStatus(status);
                    // 更新
                    saveSurveyDetailsToRedis(surveyId, surveyDetailedFromRedis);
                }
                return ResponseCode.SUCCESS.val();
            }
        }
        return ResponseCode.FAIL.val();
    }

    /**
     * 根据id查询问卷
     *
     * @param surveyId
     * @return
     */
//    @Cacheable(value = "surveyCache", key = "'survey_' + #surveyId.toString()")
    public Survey getSurveyById(Long surveyId) {
        LambdaQueryWrapper<Survey> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(Survey::getSurveyId, surveyId);
        return surveyMapper.selectOne(queryWrapper);
    }

    /**
     * 获取查看页面或者做问卷页面所需要的问卷数据(包括问卷基本信息和问题以及问题对应的选项)
     *
     * @param surveyId
     * @return
     */
    @Override
    public SurveyAndQuestionVo getSurveyDetailedById(Long surveyId, List<QuestionVo> questions) {

        // 获取问卷基本信息
        Survey surveyById = getSurveyById(surveyId);

        SurveyAndQuestionVo survey = new SurveyAndQuestionVo();

        // 设置问题
        survey.setQuestions(questions);

        // 使用拷贝
        BeanUtil.copyProperties(surveyById, survey);

        return survey;
    }

    /**
     * 从缓存中获取问卷以及问题
     *
     * @param surveyId
     * @return
     */
    @Override
    public SurveyAndQuestionVo getSurveyDetailedFromRedis(Long surveyId) {
        String key = RedisConstants.PUBLISH_SURVEY + surveyId;
        return redisBeanUtil.get(redisTemplate, key);
    }

    /**
     * 从缓存中中获取问卷选择题分析的统计数据实体
     *
     * @param surveyId
     * @return
     */
    @Override
    public SurveyAnalysisVo getSurveyAnalysisFromRedis(Long surveyId) {
        String key = RedisConstants.ANALYZE_CHOICE_SURVEY + surveyId;
        return redisBeanUtil.get(redisAnalysisTemplate, key);
//        return  redisAnalysisTemplate.opsForValue().get(key);
    }

    /**
     * 将问卷和问题保存到缓存中
     *
     * @param surveyId
     * @param surveyAndQuestionVo
     */
    @Override
    public void saveSurveyDetailsToRedis(Long surveyId, SurveyAndQuestionVo surveyAndQuestionVo) {
        // 放入redis中,用surveyId当作主键
        String key = RedisConstants.PUBLISH_SURVEY + surveyId;
        redisBeanUtil.set(redisTemplate, key, surveyAndQuestionVo);
    }


    /**
     * 将选择题分析统计结果放入redis中
     *
     * @param surveyId
     * @param surveyAnalysisVo
     */
    @Override
    public void saveSurveyAnalysisToRedis(Long surveyId, SurveyAnalysisVo surveyAnalysisVo) {
        // 放入redis中,用surveyId当作主键(设置1天过期时间)
        String key = RedisConstants.ANALYZE_CHOICE_SURVEY + surveyId;
        redisBeanUtil.setTTL(redisAnalysisTemplate, key, surveyAnalysisVo, 1L, TimeUnit.DAYS);
    }


    /**
     * 从redis中删除问卷缓存
     *
     * @param surveyId
     */
    @Override
    public void deleteSurveyFromRedis(Long surveyId) {
        String key = RedisConstants.PUBLISH_SURVEY + surveyId;
        redisBeanUtil.delete(redisTemplate, key);
    }

    /**
     * 从redis中删除问卷分析缓存
     *
     * @param surveyId
     */
    @Override
    public void deleteSurveyAnalysisFromRedis(Long surveyId) {
        String key = RedisConstants.ANALYZE_CHOICE_SURVEY + surveyId;
        redisBeanUtil.delete(redisAnalysisTemplate, key);
    }

    /**
     * 更新问卷收集数量(每提交一次回答则更新一份)
     *
     * @param survey
     * @return
     */
    @Override
    public Integer updateSurveyCollected(Survey survey) {
        // 检查问卷是否已经达到结束时间
        boolean isEnd = checkSurveyIsEnd(survey);
        if (isEnd) {
            // 已经结束了无法提交
            return ResponseCode.SURVEY_INVALID.val();
        }
        // 设置数量+1
        survey.setSurveyCollected(survey.getSurveyCollected() + 1);

        // 更新问卷收集数量字段
        surveyMapper.updateById(survey);

        // 再次确认是否结束(即主要确认收集数量是否大于问卷的收集限制数量)
        checkSurveyIsEnd(survey);

        return ResponseCode.SUCCESS.val();
    }

    /**
     * 获取问卷的一些数量的数据
     *
     * @param userId
     * @return
     */
    @Override
    public SurveyCountDataVo getSurveyCountData(Long userId) {
        LambdaQueryWrapper<Survey> qw = new LambdaQueryWrapper<>();
        qw.eq(Survey::getUserId, userId);

        // 获取当前用户的所有问卷信息
        List<Survey> surveys = surveyMapper.selectList(qw);

        SurveyCountDataVo surveyCountDataVo = new SurveyCountDataVo();

        // 已经发布的问卷数量(包括暂停中，只要设定了发布时间的)
        Long surveyCount = 0L;

        // 已经收集的问卷数量
        Long surveyCollectedCount = 0L;

        // 已经完成的问卷数量
        Long surveyCompletedCount = 0L;

        for (Survey survey : surveys) {
            // 问卷收集数量相加
            surveyCollectedCount += survey.getSurveyCollected();

            if (survey.getSurveyStatus() == SurveyStatus.PUBLISHED.getStatusId()
                    || survey.getSurveyStatus() == SurveyStatus.PAUSED.getStatusId()) {
                // 已发布数量+1；
                surveyCount++;
            }

            if (survey.getSurveyStatus() == SurveyStatus.COMPLETED.getStatusId()) {
                // 已完成数量+1；
                surveyCompletedCount++;
            }
        }
        // 实体类赋值
        surveyCountDataVo.setSurveyCount(surveyCount + surveyCompletedCount);
        surveyCountDataVo.setSurveyCollectedCount(surveyCollectedCount);
        surveyCountDataVo.setSurveyCompletedCount(surveyCompletedCount);

        return surveyCountDataVo;
    }

    /**
     * 获取当年每月发布的问卷数量(每月统计数量以发布设定的开始时间为准)
     *
     * @param userId
     * @return
     */
    @Override
    public List<SurveyMonthlyCountVo> getSurveyMonthlyCount(Long userId) {
        return surveyMapper.selectSurveyCountByMonth(userId);
    }

    /**
     * 批量删除问卷(完成问卷使用)
     *
     * @param ids
     * @return
     */
    @Override
    @Transactional
    public Result deleteByIds(String ids) {
        // 将ids值转换为Long数组
        List<Long> collect = Arrays.stream(ids.split(","))
                .map(Long::parseLong)
                .collect(Collectors.toList());

        // 批量删除
        int res = surveyMapper.deleteBatchIds(collect);

        if (res > 0) {
            // 删除redis的缓存数据
            for (Long aLong : collect) {
                this.deleteSurveyAnalysisFromRedis(aLong);
                redisBeanUtil.delete(objectiveAnalysisRedisTemplate, RedisConstants.ANALYZE_OBJECTIVE_SURVEY + aLong);
            }
            return Result.success(ResponseCode.SUCCESS.val(), "批量删除问卷成功");
        }
        return Result.fail(ResponseCode.FAIL.val(), ResponseCode.FAIL.msg());
    }

    /**
     * 选择题选择数量统计分析
     *
     * @param survey
     * @param answerCountBySurveyId
     * @param questionId            条件参数
     * @param optionId              条件参数
     * @return
     */
    @Override
    public SurveyAnalysisVo dealWithAnswerCount(SurveyAndQuestionVo survey,
                                                List<AnswerChoiceAnalysisVo> answerCountBySurveyId,
                                                Long questionId, Long optionId) {
        SurveyAnalysisVo surveyAnalysisVo = new SurveyAnalysisVo();

        // 拷贝问题和选项
        BeanUtil.copyProperties(survey, surveyAnalysisVo);

        // 获取问卷回收数量
        Survey surveyById = this.getSurveyById(surveyAnalysisVo.getSurveyId());

        // 设置回收总数
        surveyAnalysisVo.setSurveyCollected(surveyById.getSurveyCollected());

        // 排除客观题
        List<QuestionAnalysisVo> questions = surveyAnalysisVo.getQuestions();
        List<QuestionAnalysisVo> collect = questions.stream()
                .filter(question -> !question.getQuestionType().equals(QuestionType.TEXTAREA.getTypeId()))
                .collect(Collectors.toList());

        // 如果带选项条件的话，排除那个选项问题的其他选项，只保留条件选项一个
        if (!ObjUtil.isNull(optionId)) {
            // 改用stream流
            collect.stream()
                    .filter(question -> question.getQuestionId().equals(questionId))
                    .forEach(question -> {
                        List<OptionAnalysisVo> filteredOptions = question.getOption().stream()
                                .filter(option -> option.getOptionId().equals(optionId))
                                .collect(Collectors.toList());
                        question.setOption(filteredOptions);
                    });
            // 设置回收总数(变为条件的总计数)
            for (AnswerChoiceAnalysisVo answerChoiceAnalysisVo : answerCountBySurveyId) {
                if (answerChoiceAnalysisVo.getOptionId().equals(optionId)) {
                    surveyAnalysisVo.setSurveyCollected(answerChoiceAnalysisVo.getAnswerCount());
                    break;
                }
            }
        }

        // 为每个选项设置对应的选择数量
        for (QuestionAnalysisVo questionAnalysisVo : collect) {
            List<OptionAnalysisVo> option = questionAnalysisVo.getOption();
            for (OptionAnalysisVo optionAnalysisVo : option) {
                // 找到统计选项数量列表对应的选项设置值
                List<AnswerChoiceAnalysisVo> countList = answerCountBySurveyId.stream()
                        .filter(item -> item.getOptionId().equals(optionAnalysisVo.getOptionId()))
                        .collect(Collectors.toList());
                optionAnalysisVo.setAnswerCount(countList.get(0).getAnswerCount());
            }
        }
        surveyAnalysisVo.setQuestions(collect);

        // 保存到redis 如果带条件不需要保存在redis中
        if (ObjUtil.isNull(optionId)) {
            saveSurveyAnalysisToRedis(surveyAnalysisVo.getSurveyId(), surveyAnalysisVo);
        }

        return surveyAnalysisVo;
    }

    /**
     * 处理问卷举报状态
     *
     * @param reportSurveyId
     * @param reportResult
     * @param userEmail
     * @param reportStatus
     * @return
     */
    @Override
    public Integer setReportResult(Long reportSurveyId, Integer reportResult, String userEmail, Integer reportStatus) {
        // 确认问卷是否还存在
        Survey survey = getSurveyById(reportSurveyId);

        if (BeanUtil.isEmpty(survey)) {
            // 问卷已经被删除不需要审核
            return ResponseCode.SURVEY_IS_EMPTY.val();
        }

        // 问卷存在，判断结果
        if (reportResult == ReportResult.PASS.getStatusId()) {
            // 问卷审核无异常,检查问卷状态是否为待审核(待审核解封还需要发送邮件进行通知)
            if (survey.getSurveyStatus() == SurveyStatus.SURVEY_AUDIT.getStatusId()) {
                // 申述解封发送邮件
                this.sendEmail(EmailType.APPEAL_SUCCESS.getTypeName(), userEmail, survey.getSurveyTitle());
                // 解封(封禁是将问卷状态重置到未设定发布时间之前，将问卷状态设置为申述通过)
                return this.changeSurveyStatus(reportSurveyId, SurveyStatus.SURVEY_APPEAL_SUCCESS.getStatusId());
            }
            // 无异常直接返回,不做任何操作
            return ResponseCode.SUCCESS.val();
        } else if (reportResult == ReportResult.BAN.getStatusId()) {
            // 实施封禁，将问卷重置到未发布之前，即：没有设定开始时间和结束时间，并且状态设置为封禁，需要修改内容之后申述通过才能发布
            // 删除redis中的缓存
            deleteSurveyFromRedis(reportSurveyId);

            // 金额退还
            this.backBalance(survey);

            // 修改开始和结束时间为null，状态为ban，已经收回数量重置为0，金额重置为0
            LambdaUpdateWrapper<Survey> uwp = new LambdaUpdateWrapper<>();
            uwp.set(Survey::getSurveyStartTime, null)
                    .set(Survey::getSurveyEndTime, null)
                    .set(Survey::getSurveyStatus, SurveyStatus.SURVEY_BAN.getStatusId())
                    .set(Survey::getSurveyCollected, 0)
                    .set(Survey::getSurveyBalance, BigDecimal.ZERO)
                    .eq(Survey::getSurveyId, reportSurveyId);
            int update = surveyMapper.update(null, uwp);
            if (update > 0) {
                // 是否为申述
                if (survey.getSurveyStatus() == SurveyStatus.SURVEY_AUDIT.getStatusId()) {
                    // 申述失败邮件
                    this.sendEmail(EmailType.APPEAL_FALSE.getTypeName(), userEmail, survey.getSurveyTitle());
                }
                // 首次封禁邮件
                if ((survey.getSurveyStatus() == SurveyStatus.PUBLISHED.getStatusId()
                        || survey.getSurveyStatus() == SurveyStatus.PAUSED.getStatusId())
                        && reportStatus == ReportResult.NO_DISPOSE.getStatusId()) {
                    this.sendEmail(EmailType.BAN.getTypeName(), userEmail, survey.getSurveyTitle());
                }
                return ResponseCode.SUCCESS.val();
            }
        } else if (reportResult == ReportResult.NO_DISPOSE.getStatusId()) {
            // 问卷申述(设置问卷状态为待审核)
            survey.setSurveyStatus(SurveyStatus.SURVEY_AUDIT.getStatusId());
            // 邮件通知
            this.sendEmail(EmailType.APPEAL.getTypeName(), userEmail, survey.getSurveyTitle());
            // 更新文章状态
            return this.changeSurveyStatus(reportSurveyId, SurveyStatus.SURVEY_AUDIT.getStatusId());
        } else {
            return ResponseCode.FAIL.val();
        }
        return ResponseCode.FAIL.val();
    }


    /**
     * 审核结果通知
     *
     * @param type        邮件作用
     * @param userEmail
     * @param surveyTitle
     */
    @Async
    public void sendEmail(String type, String userEmail, String surveyTitle) {

        // 邮件主题
        String subject = "调查问卷平台";
        // 邮件内容
        String message = "";

        // 问卷被ban通知
        if (type.equals(EmailType.BAN.getTypeName())) {
            // 邮件信息
            message = "<h3>【调查问卷平台】</h3><br/><p>我们收到了关于您的问卷:"
                    + "<span style='color:red'>" + surveyTitle + "</span>的举报，并经过核实后发现其内容存在违规行为。基于此，我们不得不对您的问卷进行封禁处理。</p>" +
                    "<p>封禁是为了维护我们社区的良好秩序和规范，我们希望每一篇问卷都能符合我们的准则和政策。为了重新提交您的问卷进行审核，您需要对其内容进行修改，" +
                    "确保其符合我们的规范。请检查并修改您的问卷后，重新提交审核，我们将尽快处理您的请求。</p>" +
                    "<p>如有任何疑问或需要进一步帮助，请随时联系我们的客服团队。</p>" +
                    "<p>谢谢您的理解与合作。</p>";
        }

        // 问卷申述
        if (type.equals(EmailType.APPEAL.getTypeName())) {
            message = "<h3>【调查问卷平台】</h3><br/><p>我们收到了关于您的问卷:"
                    + "<span style='color:red'>" + surveyTitle + "</span>的申述，感谢您提交的问卷申述。</p>" +
                    "<p>我们将会重新审视您的问卷，并尽快作出决定。请您耐心等待，我们会在处理完毕后及时向您反馈结果。</p>" +
                    "<p>如果您有任何其他问题或需要进一步解释，请随时联系我们的客服团队，我们将竭诚为您服务。</p>" +
                    "<p>谢谢您的理解与合作。</p>";
        }

        // 问卷申述通过审核
        if (type.equals(EmailType.APPEAL_SUCCESS.getTypeName())) {
            message = "<h3>【调查问卷平台】</h3><br/><p>我们收到了关于您的问卷:"
                    + "<span style='color:red'>" + surveyTitle + "</span>的申述，感谢您重新提交的问卷。我们很高兴地通知您，您的问卷已经通过审核，可以重新发布了！进入系统设定时间即可重新完成问卷发布</p>" +
                    "<p>您的问卷已经符合了我们的准则和政策，我们相信它将为我们的社区带来价值和启发。再次感谢您的合作和理解。" +
                    "<p>如有任何疑问或需要进一步帮助，请随时联系我们的客服团队。</p>" +
                    "<p>期待您未来更多的优质内容！</p>";
        }

        // 问卷申述未通过审核
        if (type.equals(EmailType.APPEAL_FALSE.getTypeName())) {
            message = "<h3>【调查问卷平台】</h3><br/><p>我们收到了关于您的问卷:"
                    + "<span style='color:red'>" + surveyTitle + "</span>的申述，感谢您提交的问卷申述。经过我们再次审核后，很抱歉地通知您，您的申述未能通过审核。</p>" +
                    "<p>在重新审查过程中，我们仔细考虑了您提出的观点，但我们仍然认为您的问卷存在违规行为，因此我们必须维持之前的封禁决定。</p>" +
                    "<p>我们非常理解您可能对此感到失望，但我们的审核标准非常严格，我们需要确保每篇问卷都符合我们的准则和政策，以维护我们社区的良好秩序。</p>" +
                    "<p>如果您有任何其他问题或需要进一步解释，请随时联系我们的客服团队，我们将竭诚为您服务。</p>" +
                    "<p>谢谢您的理解与合作。</p>";
        }

        // 发送邮件
        try {
            mailService.sendMail(userEmail, subject, message);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * 发布问卷
     *
     * @param survey
     * @param questions
     * @return
     */
    @Override
    @Transactional
    public Integer publishSurvey(Survey survey, List<QuestionVo> questions) {

        // 检验问卷状态,如果不是未发布或未开始或审核通过直接返回错误信息
        if (survey.getSurveyStatus() != SurveyStatus.UN_PUBLISHED.getStatusId()
                && survey.getSurveyStatus() != SurveyStatus.UN_STARTED.getStatusId()
                && survey.getSurveyStatus() != SurveyStatus.SURVEY_APPEAL_SUCCESS.getStatusId()) {
            return ResponseCode.FAIL.val();
        }
        // 时间检验
        LocalDateTime surveyStartTime = survey.getSurveyStartTime();
        LocalDateTime surveyEndTime = survey.getSurveyEndTime();
        // (比较结束时间是否大于开始时间五分钟)
        Duration diff = LocalDateTimeUtil.between(surveyStartTime, surveyEndTime);
        if (diff.toMinutes() < 5) {
            return ResponseCode.TIME_INVALID.val();
        }
        // 检查开始时间是否大于等于系统时间(开始时间不能小于系统时间，考虑延迟设置15s)
        LocalDateTime now = LocalDateTimeUtil.now();
        if (LocalDateTimeUtil.between(surveyStartTime, now).getSeconds() >= 15) {
            return ResponseCode.TIME_INVALID.val();
        }

        // 只有未发布和审核通过之后，才需要计算扣费
        // 判断是否设有奖励金额，如果奖励金额大于0，扣除账户余额
        if (survey.getSurveyStatus() == SurveyStatus.UN_PUBLISHED.getStatusId()
                || survey.getSurveyStatus() == SurveyStatus.SURVEY_APPEAL_SUCCESS.getStatusId()) {
            if (survey.getSurveyBalance().compareTo(BigDecimal.ZERO) > 0) {
                // 有金额，判断金额是否足够
                User byId = userService.getById(survey.getUserId());
                if (byId.getUserBalance().compareTo(survey.getSurveyBalance()) < 0) {
                    return ResponseCode.BALANCE_LACK.val();
                }

                // 金额足够，进行余额扣费
                BigDecimal subtract = byId.getUserBalance().subtract(survey.getSurveyBalance());

                boolean balance = userService.updateBalance(byId.getUserId(), subtract);

                if (!balance) {
                    throw new CustomException("余额发生未知错误，请重新尝试");
                }

                // 生成红包列表
                // 金额乘以100，转换为单位分，避免浮点数计算问题 setScale(0) 移除所有小数
                String amount = survey.getSurveyBalance().multiply(new BigDecimal("100")).setScale(0).toString();
                // 总红包数（需要回收的问卷数量）
                Integer total = survey.getSurveyCollectedLimit();
                List<Integer> redPackets = RedPacket.distributeRedPacket(Integer.parseInt(amount), total);

                // 放入Redis中
                String key = RedisConstants.RED_PACKET + survey.getSurveyId();
                listRedisTemplate.opsForList().leftPushAll(key, redPackets);
            }
        }

        // 更新问卷状态(变成发布状态)
        // 如果时间已经到了，变成发布中状态
        if (LocalDateTimeUtil.between(LocalDateTimeUtil.now(), surveyStartTime).getSeconds() <= 0) {
            changeSurveyStatus(survey.getSurveyId(), SurveyStatus.PUBLISHED.getStatusId());
        } else {
            // 没有到达规定时间，变成未开始状态
            changeSurveyStatus(survey.getSurveyId(), SurveyStatus.UN_STARTED.getStatusId());
        }

        // 获取问卷和问题信息
        SurveyAndQuestionVo surveyDetailedById = getSurveyDetailedById(survey.getSurveyId(), questions);
        // 设置开始时间和结束时间
        surveyDetailedById.setSurveyStartTime(surveyStartTime);
        surveyDetailedById.setSurveyEndTime(surveyEndTime);
        // 更新表的时间
        changeSurveyTime(survey.getSurveyId(), surveyStartTime, surveyEndTime);

        // 放入redis中
        saveSurveyDetailsToRedis(survey.getSurveyId(), surveyDetailedById);

        return ResponseCode.SUCCESS.val();
    }

    /**
     * 更新开始时间和结束时间
     *
     * @param surveyId
     * @param startTime
     * @param endTime
     * @return
     */
    @Override
//    @CachePut(value = "surveyCache", key = "'survey_' + #surveyId")
    public Integer changeSurveyTime(Long surveyId, LocalDateTime startTime, LocalDateTime endTime) {
        log.info("更新问卷状态服务");
        Survey survey = getSurveyById(surveyId);
        if (survey != null) {
            survey.setSurveyStartTime(startTime);
            survey.setSurveyEndTime(endTime);
            if (surveyMapper.updateById(survey) > 0) {
                return ResponseCode.SUCCESS.val();
            }
        }
        return ResponseCode.FAIL.val();
    }

    /**
     * 根据状态获取问卷列表
     *
     * @param status
     * @return
     */
    @Override
    public List<Survey> getSurveysByStatus(Integer status) {
        log.info("根据问卷状态获取问卷：" + status);
        LambdaQueryWrapper<Survey> qw = new LambdaQueryWrapper<>();
        qw.eq(Survey::getSurveyStatus, status);
        return surveyMapper.selectList(qw);
    }

    /**
     * 检查问卷是否开始
     *
     * @param survey
     */
    @Override
    public void checkSurveyIsStart(Survey survey) {
        // 获取当前时间
        LocalDateTime currentTime = LocalDateTime.now();
        LocalDateTime surveyStartTime = survey.getSurveyStartTime();
        LocalDateTime surveyEndTime = survey.getSurveyEndTime();
        // 如果当前时间在开始时间和结束时间之间，则将问卷状态设置为进行中
        if (currentTime.isAfter(surveyStartTime) && currentTime.isBefore(surveyEndTime)) {
            // 更新问卷状态
            changeSurveyStatus(survey.getSurveyId(), SurveyStatus.PUBLISHED.getStatusId());
        }
    }

    /**
     * 检查问卷是否结束
     *
     * @param survey
     * @return true:已完成，false:未完成
     */
    @Override
    public boolean checkSurveyIsEnd(Survey survey) {

        // 获取锁
        if (timeoutLock.tryLock()) {
            try {
                // 获取当前时间
                LocalDateTime currentTime = LocalDateTime.now();
                LocalDateTime surveyEndTime = survey.getSurveyEndTime();
                // 如果当前时间大于结束时间，则将问卷状态设置为已结束
                if (currentTime.isAfter(surveyEndTime)) {
                    // 更新问卷状态
                    changeSurveyStatus(survey.getSurveyId(), SurveyStatus.COMPLETED.getStatusId());
                    // 清空redis缓存信息
                    deleteSurveyFromRedis(survey.getSurveyId());

                    // 发送邮件通知
                    sendSurveyEndEmail(survey.getSurveyId());
                    // 金额退还
                    this.backBalance(survey);
                    return true;
                }
                // 如果回收数量达到设定的数量，则将问卷状态设置为已结束
                // 已回收数量
                Integer surveyCollected = survey.getSurveyCollected();
                // 设定的需要回收的数量
                Integer surveyCollectedLimit = survey.getSurveyCollectedLimit();
                if (surveyCollected.equals(surveyCollectedLimit)) {
                    changeSurveyStatus(survey.getSurveyId(), SurveyStatus.COMPLETED.getStatusId());
                    // 清空redis缓存信息
                    deleteSurveyFromRedis(survey.getSurveyId());

                    // 发送邮件通知
                    sendSurveyEndEmail(survey.getSurveyId());

                    // 金额退还
                    this.backBalance(survey);
                    return true;
                }
                return false;
            } finally {
                // 确保锁释放
                timeoutLock.unlock();
            }
        } else {
            log.info("检查问卷状态，获取锁超时");
            throw new CustomException("发送未知错误，请重新尝试");
        }
    }

    /**
     * 异步检查问卷状态
     *
     * @param survey
     */
    @Override
    @Async
    public void processSurveyAsync(Survey survey) {
        Integer surveyStatus = survey.getSurveyStatus();
        if (surveyStatus == SurveyStatus.UN_STARTED.getStatusId()) {
            // 检查是否开始
            checkSurveyIsStart(survey);
        }
        if (surveyStatus == SurveyStatus.PUBLISHED.getStatusId() ||
                surveyStatus == SurveyStatus.PAUSED.getStatusId()) {
            // 检查是否结束
            checkSurveyIsEnd(survey);
        }
    }

    /**
     * 根据id删除问卷
     *
     * @param surveyId
     * @param userId
     * @return
     */
    @Override
    @Transactional
    public Integer deleteSurveyById(Long surveyId, Long userId) {

        log.info("调用根据id删除问卷服务,surveyId:{}", surveyId);

        // 获取问卷,对比userid
        Survey surveyById = getSurveyById(surveyId);
        if (BeanUtil.isNotEmpty(surveyById)) {
            if (surveyById.getUserId().equals(userId)) {
                // 删除问卷
                int res = surveyMapper.deleteById(surveyId);
                // 查询redis缓存中是否有
                if (BeanUtil.isNotEmpty(getSurveyDetailedFromRedis(surveyId))) {
                    // 删除缓存的
                    deleteSurveyFromRedis(surveyId);
                }
                // 删除完成问卷分析的缓存
                if (BeanUtil.isNotEmpty(getSurveyAnalysisFromRedis(surveyId))) {
                    deleteSurveyAnalysisFromRedis(surveyId);
                    redisBeanUtil.delete(objectiveAnalysisRedisTemplate, RedisConstants.ANALYZE_OBJECTIVE_SURVEY + surveyId);
                }
                // 金额退还,只有非完成的状态的问卷，需要退还金额
                if (!surveyById.getSurveyStatus().equals(SurveyStatus.COMPLETED.getStatusId())) {
                    this.backBalance(surveyById);
                }

                return res > 0 ? ResponseCode.SUCCESS.val() : ResponseCode.FAIL.val();
            }
        }

        return ResponseCode.FAIL.val();
    }


    /**
     * 发送邮件通知问卷完成
     *
     * @param surveyId
     */
    @Async
    public void sendSurveyEndEmail(Long surveyId) {

        Survey surveyById = getSurveyById(surveyId);
        User user = userService.getById(surveyById.getUserId());

        // 邮件主题
        String subject = "调查问卷平台";
        // 邮件信息
        String message = "<h3>【调查问卷平台】</h3><br/>你的问卷：" +
                "<span style='color:red'>" + surveyById.getSurveyTitle() + "</span> 已经完成，请前往：<span style='color:red'><a href='http://localhost:8128'>调查问卷平台</a></span> 查看结果";

        // 发送邮件
        try {
            mailService.sendMail(user.getUserEmail(), subject, message);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 金额回退给用户，（情况：发布中被封禁的剩余金额返回，问卷结束的剩余金额返回）
     */
    public void backBalance(Survey survey) {
        BigDecimal balance = survey.getSurveyBalance();
        if (balance.compareTo(BigDecimal.ZERO) > 0) {
            // 还有金额，退回金额
            log.info("问卷奖励金额退回，金额为：{}元", balance);
            User user = userService.getById(survey.getUserId());
            user.setUserBalance(user.getUserBalance().add(balance));
            // 更新账号余额
            userService.updateById(user);
            // 删除Redis缓存
            listRedisTemplate.opsForList().trim(RedisConstants.RED_PACKET + survey.getSurveyId(), 1, 0);
        }
    }


}
