package com.nekotaku.questionnairesystem.mapper;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Constants;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.nekotaku.questionnairesystem.vo.analysis.AnswerChoiceAnalysisVo;
import com.nekotaku.questionnairesystem.vo.analysis.TextQuestionAnalysisVo;
import com.nekotaku.questionnairesystem.entity.Answer;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.nekotaku.questionnairesystem.vo.excel.ExcelWithChoiceVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 问卷结果表	 Mapper 接口
 * </p>
 *
 * @author nekotaku
 * @since 2024-02-20
 */
@Mapper
public interface AnswerMapper extends BaseMapper<Answer> {


    // 统计问卷的每道选择题的选择数量
    List<AnswerChoiceAnalysisVo> selectSurveyAnswerCount(@Param("surveyId")Long surveyId,
                                                         @Param("optionId")Long optionId);

    // 查询客观题的答题详细内容
    Page<TextQuestionAnalysisVo> selectTextAnswerBySurveyId(Page<TextQuestionAnalysisVo> page
            , @Param(Constants.WRAPPER) QueryWrapper<TextQuestionAnalysisVo> queryWrapper);

    // 查询客观题的答题详细内容（导出excel用）
    List<TextQuestionAnalysisVo> selectTextAnswerBySurveyIdForExcel(@Param("surveyId")Long surveyId);

    // 查询客观题和选择题的答题详细内容（导出excel用）
    List<ExcelWithChoiceVo> selectTextWithChoiceBySurveyIdForExcel(@Param("surveyId")Long surveyId);

}
