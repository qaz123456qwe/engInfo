package com.nekotaku.questionnairesystem.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.util.ObjUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.OrderItem;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.nekotaku.questionnairesystem.common.R.ResponseCode;
import com.nekotaku.questionnairesystem.common.R.Result;
import com.nekotaku.questionnairesystem.common.enums.SurveyStatus;
import com.nekotaku.questionnairesystem.common.page.QueryPageParam;
import com.nekotaku.questionnairesystem.vo.QuestionVo;
import com.nekotaku.questionnairesystem.vo.QuestionTmpVo;
import com.nekotaku.questionnairesystem.vo.SurveyAndQuestionVo;
import com.nekotaku.questionnairesystem.entity.TmpSurvey;
import com.nekotaku.questionnairesystem.mapper.TmpSurveyMapper;
import com.nekotaku.questionnairesystem.service.TmpSurveyService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

/**
 * <p>
 * 模板问卷表 服务实现类
 * </p>
 *
 * @author nekotaku
 * @since 2024-03-02
 */
@Service
@Slf4j
public class TmpSurveyServiceImpl extends ServiceImpl<TmpSurveyMapper, TmpSurvey> implements TmpSurveyService {

    @Autowired
    private TmpSurveyMapper tmpSurveyMapper;

    /**
     * 新增或更新问卷模板基本信息
     *
     * @param tmpSurvey
     * @return
     */
    @Override
    public Integer saveOrUpdateSurveyTmp(TmpSurvey tmpSurvey) {

        log.info("添加或更新问卷表基本信息服务");

        // 标题去除两端空格
        tmpSurvey.setTmpSurveyTitle(tmpSurvey.getTmpSurveyTitle().trim());

        LambdaQueryWrapper<TmpSurvey> qw = new LambdaQueryWrapper<>();

        // 判断标题是否重复(根据UserId和标题)
        qw.eq(TmpSurvey::getUserId, tmpSurvey.getUserId());
        qw.eq(TmpSurvey::getTmpSurveyTitle, tmpSurvey.getTmpSurveyTitle());
        // 排除原本的标题(更新防止没有改动时，无法保存)
        if (!ObjUtil.isNull(tmpSurvey.getTmpId())) {
            qw.ne(TmpSurvey::getTmpId, tmpSurvey.getTmpId());
        }
        if (tmpSurveyMapper.selectCount(qw) > 0) {
            // 重复标题返回错误
            return ResponseCode.SURVEY_TMP_TITLE_EXIST.val();
        }

        // 新增或更新
        boolean res = this.saveOrUpdate(tmpSurvey);

        if (res) {
            return ResponseCode.SUCCESS.val();
        }
        return ResponseCode.FAIL.val();
    }

    /**
     * 问卷模板列表分页查询
     *
     * @param queryPageParam
     * @param userId
     * @return
     */
    @Override
    public Page<TmpSurvey> listTmpSurveys(QueryPageParam queryPageParam, Long userId) {

        log.info("分页查询问卷模板列表服务");

        Page<TmpSurvey> tmpSurveyPage = new Page<>();

        // 设置当前页
        tmpSurveyPage.setCurrent(queryPageParam.getPageNum());
        // 设置当前页面数量
        tmpSurveyPage.setSize(queryPageParam.getPageSize());
        // 按照最新数据查询(从后往前排序查询)
        tmpSurveyPage.setOrders(Arrays.asList(OrderItem.desc("update_time")));

        HashMap param = queryPageParam.getParam();

        // 获取查询条件
        // 标题
        String surveyTmpTitle = param.get("surveyTmpTitle").toString();
        // 状态
        String surveyTmpStatus = param.get("surveyTmpStatus").toString();

        LambdaQueryWrapper<TmpSurvey> qw = new LambdaQueryWrapper<>();

        // 判断条件是否存在
        if (StringUtils.isNotBlank(surveyTmpTitle) && !"null".equals(surveyTmpTitle)) {
            // 模糊查询
            qw.like(TmpSurvey::getTmpSurveyTitle, surveyTmpTitle);
        }
        if (StringUtils.isNotBlank(surveyTmpStatus) && !"null".equals(surveyTmpStatus)) {
            // 匹配问卷状态
            qw.eq(TmpSurvey::getTmpSurveyStatus, Integer.parseInt(surveyTmpStatus));
        }

        qw.eq(TmpSurvey::getUserId, userId);

        return this.page(tmpSurveyPage, qw);
    }

    /**
     * 根据模板问卷id获取问卷模板
     *
     * @param tmpId
     * @return
     */
    @Override
    public TmpSurvey getTmpSurveyById(Long tmpId) {
        LambdaQueryWrapper<TmpSurvey> qw = new LambdaQueryWrapper<>();
        qw.eq(TmpSurvey::getTmpId, tmpId);
        return tmpSurveyMapper.selectOne(qw);
    }

    /**
     * 更新模板问卷状态
     *
     * @param tmpId
     * @param status
     * @return
     */
    @Override
    public Integer changeTmpSurveyStatus(Long tmpId, Integer status) {

        TmpSurvey tmpSurveyById = getTmpSurveyById(tmpId);
        if (tmpSurveyById != null) {
            tmpSurveyById.setTmpSurveyStatus(status);
            if (tmpSurveyMapper.updateById(tmpSurveyById) > 0) {
                return ResponseCode.SUCCESS.val();
            }
        }

        return ResponseCode.FAIL.val();
    }

    /**
     * 删除模板问卷
     *
     * @param tmpId
     * @param userId
     * @return
     */
    @Override
    @Transactional
    public Integer deleteSurveyTmpById(Long tmpId, Long userId) {
        LambdaQueryWrapper<TmpSurvey> qw = new LambdaQueryWrapper<>();
        // 根据用户id和模板问卷id删除模板问卷
        qw.eq(TmpSurvey::getUserId, userId).eq(TmpSurvey::getTmpId, tmpId);

        return tmpSurveyMapper.delete(qw) > 0 ?
                ResponseCode.SUCCESS.val() : ResponseCode.FAIL.val();
    }

    /**
     * 批量删除模板问卷
     *
     * @param ids
     * @return
     */
    @Override
    @Transactional
    public Result deleteByIds(String ids) {

        // 将ids值转换为Long数组
        List<Long> collect = Arrays.stream(ids.split(","))
                .map(Long::parseLong)
                .collect(Collectors.toList());

        // 批量删除分类
        int res = tmpSurveyMapper.deleteBatchIds(collect);
        if (res > 0) {
            return Result.success(ResponseCode.SUCCESS.val(), "批量删除分类成功");
        }
        return Result.fail(ResponseCode.FAIL.val(), ResponseCode.FAIL.msg());
    }

    /**
     * 查看模板问卷(显示问题和选项)
     *
     * @param tmpId
     * @param tmpQuestions
     * @return
     */
    @Override
    public SurveyAndQuestionVo getTmpSurveyDetailedById(Long tmpId, List<QuestionTmpVo> tmpQuestions) {

        // 获取模板问卷基本信息
        TmpSurvey tmpSurveyById = getTmpSurveyById(tmpId);

        SurveyAndQuestionVo survey = new SurveyAndQuestionVo();

        // 准备一个问卷对象DTO(做拷贝),使用@Alias 设置了属性别名，即不同属性名也能实现拷贝
        List<QuestionVo> questions = BeanUtil.copyToList(tmpQuestions, QuestionVo.class);

        // 设置问题
        survey.setQuestions(questions);

        // 设置基本信息
        survey.setSurveyId(tmpId);
        survey.setSurveyTitle(tmpSurveyById.getTmpSurveyTitle());
        survey.setSurveyDescription(tmpSurveyById.getTmpSurveyDesc());
        // 设置未发布状态，防止提交
        survey.setSurveyStatus(SurveyStatus.UN_PUBLISHED.getStatusId());

        return survey;
    }
}
