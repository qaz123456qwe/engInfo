package com.nekotaku.questionnairesystem.utils.redis;

import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;

import javax.annotation.Resource;

/**
 * Redis通用工具类，适合普通的
 *
 * @Title:RedisUtilCommon
 * @Author:NekoTaku
 * @Date:2024/03/16 18:57
 * @Version:1.0
 */
@Component
public class RedisUtilCommon {

    @Resource
    private RedisTemplate<String, Object> redisTemplate;

    // 存入缓存
    public <T> void set(String key, T value) {
        redisTemplate.opsForValue().set(key, value);
    }

    // 存入缓存并设置过期时间
    public <T> void set(String key, T value, long timeout, TimeUnit timeUnit) {
        redisTemplate.opsForValue().set(key, value, timeout, timeUnit);
    }

    // 获取缓存
    public <T> T get(String key) {
        return (T) redisTemplate.opsForValue().get(key);
    }

    // 删除缓存
    public void delete(String key) {
        redisTemplate.delete(key);
    }

}
