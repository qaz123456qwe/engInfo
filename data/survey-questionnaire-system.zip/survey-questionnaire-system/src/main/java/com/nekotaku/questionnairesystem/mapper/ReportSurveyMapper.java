package com.nekotaku.questionnairesystem.mapper;

import com.nekotaku.questionnairesystem.entity.report.ReportSurvey;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * 问卷举报信息表 Mapper 接口
 * </p>
 *
 * @author nekotaku
 * @since 2024-04-05
 */
@Mapper
public interface ReportSurveyMapper extends BaseMapper<ReportSurvey> {

}
