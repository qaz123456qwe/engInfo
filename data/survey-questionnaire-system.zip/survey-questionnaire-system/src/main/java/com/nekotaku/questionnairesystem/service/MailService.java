package com.nekotaku.questionnairesystem.service;

/**
 * 邮件发送服务
 *
 * @Title:MailService
 * @Author:NekoTaku
 * @Date:2023/11/21 18:58
 * @Version:1.0
 */
public interface MailService {

    void sendMail(String email,String subject,String content);
}
