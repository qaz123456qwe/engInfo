package com.nekotaku.questionnairesystem.common.lock;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

/**
 * 自定义锁
 * 主要作用：对问卷结束判定进行加锁，防止出现脏数据
 *
 * @Title:lock
 * @Author:NekoTaku
 * @Date:2024/05/02 21:00
 * @Version:1.0
 */
public class TimeoutLock {

    // 可重入锁（互斥锁，与 synchronized 关键字类似的同步和锁定能力，可设置锁超时时间）
    private final ReentrantLock lock = new ReentrantLock();
    private final long timeoutMillis;

    public TimeoutLock(long timeoutMillis) {
        this.timeoutMillis = timeoutMillis;
    }


    /**
     * 获取锁
     *
     * @return
     */
    public boolean tryLock() {
        try {
            return lock.tryLock(timeoutMillis, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            // 恢复中断状态
            Thread.currentThread().interrupt();
            // 返回 false 表示没有获取到锁
            return false;
        }
    }

    /**
     * 释放锁
     */
    public void unlock() {
        lock.unlock();
    }
}
