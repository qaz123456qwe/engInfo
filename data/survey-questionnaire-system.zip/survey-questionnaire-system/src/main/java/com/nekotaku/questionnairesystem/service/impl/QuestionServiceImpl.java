package com.nekotaku.questionnairesystem.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.ObjUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.nekotaku.questionnairesystem.common.R.ResponseCode;
import com.nekotaku.questionnairesystem.common.enums.QuestionType;
import com.nekotaku.questionnairesystem.common.enums.SurveyStatus;
import com.nekotaku.questionnairesystem.common.exception.CustomException;
import com.nekotaku.questionnairesystem.vo.QuestionVo;
import com.nekotaku.questionnairesystem.vo.QuestionTmpVo;
import com.nekotaku.questionnairesystem.entity.Question;
import com.nekotaku.questionnairesystem.entity.QuestionOption;
import com.nekotaku.questionnairesystem.entity.Survey;
import com.nekotaku.questionnairesystem.mapper.QuestionMapper;
import com.nekotaku.questionnairesystem.service.QuestionOptionService;
import com.nekotaku.questionnairesystem.service.QuestionService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.nekotaku.questionnairesystem.service.SurveyService;
import com.nekotaku.questionnairesystem.service.TmpQuestionService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

/**
 * <p>
 * 问卷问题表 服务实现类
 * </p>
 *
 * @author nekotaku
 * @since 2024-01-27
 */
@Service
@Slf4j
public class QuestionServiceImpl extends ServiceImpl<QuestionMapper, Question> implements QuestionService {

    @Autowired
    private SurveyService surveyService;

    @Autowired
    private QuestionMapper questionMapper;

    @Autowired
    private QuestionOptionService questionOptionService;

    @Autowired
    private TmpQuestionService tmpQuestionService;


    /**
     * 保存问卷的问题和选项
     *
     * @param questionsDto
     * @return
     */
    @Override
    @Transactional
    public Integer saveQuestion(List<QuestionVo> questionsDto) {
        log.info("保存问卷问题服务");
        if (questionsDto.size() <= 0) {
            return ResponseCode.FAIL.val();
        }
        // 获取问卷id
        Long surveyId = questionsDto.get(0).getSurveyId();

        Survey surveyById = surveyService.getSurveyById(surveyId);
        // 判断问卷状态，如果是已经发布了则不能再次修改
        if (surveyById.getSurveyStatus() == SurveyStatus.PUBLISHED.getStatusId() ||
                surveyById.getSurveyStatus() == SurveyStatus.COMPLETED.getStatusId() ||
                surveyById.getSurveyStatus() == SurveyStatus.PAUSED.getStatusId()
        ) {
            return ResponseCode.FAIL.val();
        }

        // 先删除问卷下的问题和选项(可能是更新操作)
        // 判断是否第一次设计问卷的保存，如果第一次无需再进行删除操作
        if (surveyById.getSurveyStatus() != SurveyStatus.UN_DESIGNED.getStatusId()) {
            // MySQL数据库设置了外键级联删除，选项会自动删除
            deleteQuestions(surveyId);
        }
        // 保存问题
        // 对象转化
        List<Question> questions = new ArrayList<>();
        for (QuestionVo dto : questionsDto) {
            Question question = new Question();
            BeanUtil.copyProperties(dto, question);
            questions.add(question);
        }
        // 保存，如果失败返回错误
        if (!this.saveBatch(questions)) {
            return ResponseCode.FAIL.val();
        }

        // 根据问卷id查询刚才保存好的问卷问题,为options的questionId赋值
        List<Question> questionsBySave = getQuestionsByOrder(surveyId);
        for (int i = 0; i < questionsDto.size(); i++) {
            // 如果是单选或者多选，才设置选项的问题id
            if (questionsDto.get(i).getQuestionType() != QuestionType.TEXTAREA.getTypeId()) {
                for (int j = 0; j < questionsDto.get(i).getOption().size(); j++) {
                    questionsDto.get(i).getOption().get(j)
                            .setQuestionId(questionsBySave.get(i).getQuestionId());
                }
            }
        }
        // 保存选项
        List<QuestionOption> optionsToSave = new ArrayList<>();
        for (QuestionVo dto : questionsDto) {
            // 排除客观题
            if (dto.getQuestionType() != QuestionType.TEXTAREA.getTypeId()) {
                optionsToSave.addAll(dto.getOption());
            }
        }
        if (!optionsToSave.isEmpty()) {
            // 批量保存选项
            if (!questionOptionService.saveBatch(optionsToSave)) {
                return ResponseCode.FAIL.val();
            }
        }
        // 更改问卷状态，并向控制器返回结果
        return surveyService.changeSurveyStatus(surveyId, SurveyStatus.UN_PUBLISHED.getStatusId());
    }

    /**
     * 使用模板新增问卷
     *
     * @param survey
     * @param tmpId
     * @return
     */
    @Override
    @Transactional
    public Integer saveForTempSurvey(Survey survey, Long tmpId) {
        // 保存问卷
        Integer saveRes = surveyService.saveOrUpdateSurvey(survey);

        // 判断是否保存成功
        if (!saveRes.equals(ResponseCode.SUCCESS.val())) {
            // 保存失败
            return saveRes;
        }
        // 保存成功，查询刚才保存好的问卷，获取问卷id(由于标题不可重复，可以通过标题和userId来查询刚刚保存的问卷)
        LambdaQueryWrapper<Survey> qw = new LambdaQueryWrapper<>();
        qw.eq(Survey::getUserId, survey.getUserId());
        qw.eq(Survey::getSurveyTitle, survey.getSurveyTitle());
        Survey addSurvey = surveyService.getOne(qw);

        // 判断是否保存成功
        if (ObjUtil.isNull(addSurvey)) {
            // 如果没有找到，说明保存有问题，抛出异常触发事务回滚
            throw new CustomException("使用模板保存异常");
        }

        // 根据模板id获取模板问题列表
        List<QuestionTmpVo> tmpQuestions = tmpQuestionService.getTmpQuestions(tmpId);

        // 准备一个问卷对象DTO(做拷贝),使用@Alias 设置了属性别名，即不同属性名也能实现拷贝
        List<QuestionVo> questions = BeanUtil.copyToList(tmpQuestions, QuestionVo.class);

        // 设置问卷id(拷贝的对象surveyId还是tmpId，需要刚刚保存的问卷id)
        questions.forEach(questionDto -> questionDto.setSurveyId(addSurvey.getSurveyId()));

        // 设置问题id和选项id为null
        questions.forEach(questionDto -> questionDto.setQuestionId(null));
        questions.forEach(questionDto -> questionDto.getOption().forEach(option -> {
            option.setOptionId(null);
            option.setOptionId(null);
        }));

        // 保存问题和选项
        return this.saveQuestion(questions);
    }

    /**
     * 获取单选题问题和问题选项
     *
     * @param surveyId
     * @return
     */
    @Override
    public List<QuestionVo> getSingleQuestions(Long surveyId) {
        // 获取所有
        List<QuestionVo> questions = getQuestions(surveyId);
        // 排除多选和客观题
        questions.removeIf(questionVo -> questionVo.getQuestionType() == QuestionType.MULTIPLE_CHOICE.getTypeId()
                || questionVo.getQuestionType() == QuestionType.TEXTAREA.getTypeId());

        return questions;
    }

    /**
     * 根据问卷id获取问题列表
     * (由于自定义SQL连接查询，会造成笛卡尔积情况，需要逻辑处理)
     *
     * @param surveyId
     * @return
     */
    @Override
    public List<QuestionVo> getQuestions(Long surveyId) {
        // 查询问卷状态，如果未设计直接返回空
        if (surveyService.getSurveyById(surveyId).getSurveyStatus()
                == SurveyStatus.UN_DESIGNED.getStatusId()) {
            return null;
        }
        // 查询问卷问题列表
        List<QuestionVo> questions = questionMapper.getQuestionsAndOptionsBySurveyId(surveyId);

        // 处理由于连接查询出现的笛卡尔积情况造成重复列表数据
        // 通过LinkedHashSet去除重复数据列，并且保留插入顺序
        LinkedHashSet<QuestionVo> questionVoHashSet = new LinkedHashSet<>(questions);

        // 转为List并按照问题顺序字段排序
        questions = new ArrayList<>(questionVoHashSet);
        // 排序(按照问题顺序升序排序)，由于连接查询结果客观题是在集合最后的，所以还是需要排序(排除客观题不在后面的情况)
        CollUtil.sort(questions, Comparator.comparing(Question::getQuestionSort));

//        log.info("问题列表：" + questions);
        // 设置问题type的value值
        for (QuestionVo qd : questions) {
            qd.setQuestionTypeValue(QuestionType.getByTypeId(qd.getQuestionType()).getTypeValue());
        }
        return questions;
    }


    /**
     * 根据问卷id和题目序号将问题按照顺序查询出来，目的给Options的questionId赋值
     *
     * @return
     */
    private List<Question> getQuestionsByOrder(Long surveyId) {
        LambdaQueryWrapper<Question> qw = new LambdaQueryWrapper<>();
        qw.eq(Question::getSurveyId, surveyId);
        qw.orderByAsc(Question::getQuestionSort);
        return questionMapper.selectList(qw);
    }

    /**
     * 根据id删除问题
     *
     * @param surveyId
     */
    private void deleteQuestions(Long surveyId) {
        LambdaQueryWrapper<Question> qw = new LambdaQueryWrapper<>();
        qw.eq(Question::getSurveyId, surveyId);
        questionMapper.delete(qw);
    }


}
