package com.nekotaku.questionnairesystem.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.nekotaku.questionnairesystem.common.R.ResponseConstants;
import com.nekotaku.questionnairesystem.utils.RegexPatterns;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

/**
 * <p>
 * 调查问卷系统用户表
 * </p>
 *
 * @author nekotaku
 * @since 2023-11-20
 */
@Data
@EqualsAndHashCode(callSuper = false)
@ApiModel(value="User对象", description="调查问卷系统用户表")
public class User implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "用户id")
    @TableId(value = "user_id")
    private Long userId;

    @ApiModelProperty(value = "用户名")
    @NotBlank(message = ResponseConstants.INVALID_RESPONSE_CODE)
    @Pattern(regexp = RegexPatterns.USERNAME_REGEX,message = ResponseConstants.INVALID_RESPONSE_CODE)
    private String userName;

    @ApiModelProperty(value = "用户密码(加密存储)")
    @NotBlank(message = ResponseConstants.INVALID_RESPONSE_CODE)
    @Pattern(regexp = RegexPatterns.PASSWORD_REGEX,message = ResponseConstants.INVALID_RESPONSE_CODE)
    private String userPassword;

    @ApiModelProperty(value = "用户邮箱")
    @Email(message = ResponseConstants.INVALID_RESPONSE_CODE)
    private String userEmail;

    @ApiModelProperty(value = "用户昵称")
    @Pattern(regexp = RegexPatterns.STRING_NO_SPACE,message = ResponseConstants.INVALID_RESPONSE_CODE)
    private String userNickname;

    @ApiModelProperty(value = "用户头像路径")
    private String userAvatarPath;

    @ApiModelProperty(value = "用户角色id")
    @NotBlank(message = ResponseConstants.INVALID_RESPONSE_CODE)
    private Integer userRoleId;

    @ApiModelProperty(value = "用户账户是否可用(0不可用，1可用)")
    @NotBlank(message = ResponseConstants.INVALID_RESPONSE_CODE)
    private Integer userIsValid;

    @ApiModelProperty(value = "用户余额")
    @TableField(fill = FieldFill.INSERT)
    private BigDecimal userBalance;

    @ApiModelProperty(value = "用户创建时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    @ApiModelProperty(value = "用户更新时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime updateTime;

}
