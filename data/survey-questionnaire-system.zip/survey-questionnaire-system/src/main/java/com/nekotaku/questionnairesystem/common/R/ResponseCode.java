package com.nekotaku.questionnairesystem.common.R;

/**
 * 响应码
 * 1XX：信息，服务器收到请求，需要请求者继续执行操作
 * 2XX：成功，操作被成功接收并处理
 * 3XX：重定向，需要进一步的操作以完成请求
 * 4XX：客户端错误，请求包含语法错误或无法完成请求
 * 5XX：服务器错误，服务器在处理请求的过程中发生了错误
 *
 * @Title:ResponseCode
 * @Author:NekoTaku
 * @Date:2023/11/20 20:06
 * @Version:1.0
 */
public enum ResponseCode {

    /**
     * GET，PUT或DELETE请求成功
     */
    SUCCESS(200, "请求成功"),
    /**
     * GET，PUT或DELETE请求失败
     */
    FAIL(400, "发生未知错误"),
    /**
     * 缺少API用户未经过身份验证
     */
    UNAUTHORIZED(401, "用户未经过身份验证"),

    /**
     * 该请求不被允许
     */
    FORBIDDEN(403, "该请求不被允许"),

    /**
     * 查找不到
     */
    NOT_FOUND(404, "查找不到想要的资源"),

    /**
     * 服务器异常
     */
    ERROR(500, "服务器异常"),

//  自定义响应码
    /**
     * 验证无法通过
     */
    VALUE_INVALID(601, "输入值无法通过验证"),

    /**
     * 验证码不匹配
     */
    CODE_INVALID(602, "验证码不正确,无法通过验证"),

    /**
     * 验证码失效
     */
    CODE_TIMEOUT(603, "验证码失效"),

    /**
     * 验证码频繁发送
     */
    CODE_FREQUENT(604, "验证码发送频繁,请稍后再试"),

    /**
     * 邮箱被占用
     */
    EMAIL_EXIST(605, "邮箱已经被占用"),

    /**
     * 用户名被占用
     */
    USERNAME_EXIST(606, "用户名已经被占用"),

    /**
     * Token失效
     */
    TOKEN_INVALID(607, "当前用户无效，请重新登录"),

    /**
     * 无效用户
     */
    USER_INVALID(608, "用户名(邮箱)或者密码错误"),

    /**
     * 无效分类名
     */
    CATEGORY_INVALID(609, "分类名无效"),

    /**
     * 重复分类名
     */
    CATEGORY_EXIST(610, "分类名重复，请换一个"),

    /**
     * 分类正在使用
     */
    CATEGORY_DELETE_FAILED(611, "分类正在使用，无法随意删除"),

    /**
     * 重复问卷标题
     */
    SURVEY_TITLE_EXIST(612, "问卷标题重复，请重新输入"),

    /**
     * 无效问卷内容(问卷设计为空的情况)
     */
    QUESTION_INVALID(613, "问卷问题内容为空，请添加问题"),

    /**
     * 问卷开始和结束时间无效
     */
    TIME_INVALID(614, "无效的开始时间和结束时间"),

    /**
     * 问卷状态不允许回答
     */
    SURVEY_INVALID(615, "抱歉，当前问卷"),

    /**
     * 问卷更新不合法，已经收集的问卷数量大于限制收集的问卷数量
     */
    SURVEY_UPDATE_INVALID(616, "更新失败，当前问卷已完成数量不能大于等于限制收集数量"),

    /**
     * 问卷更新不合法，已经收集的问卷数量大于限制收集的问卷数量
     */
    SURVEY_END(617, "当前问卷已经结束，感谢参与本次问卷！"),

    /**
     * 重复问卷标题
     */
    SURVEY_TMP_TITLE_EXIST(618, "问卷模板标题重复，请重新输入"),

    /**
     * 旧密码验证不通过
     */
    PASSWORD_NO_MATCH(619, "旧密码错误"),

    /**
     * 邮箱不通过
     */
    EMAIL_NO_MATCH(620, "与旧邮箱不匹配"),

    /**
     * 旧邮箱验证码不通过
     */
    OLD_EMAIL_CODE_NO_MATCH(621, "旧邮箱验证码错误"),

    /**
     * 新邮箱验证码不通过
     */
    NEW_EMAIL_CODE_NO_MATCH(622, "新邮箱验证码错误"),

    /**
     * 文件为空
     */
    FILE_EMPTY(623, "文件为空"),

    /**
     * 图片格式错误
     */
    IMAGE_FORMAT_ERROR(624, "图片格式只支持jpg、png、jpeg、gif"),

    /**
     * 文章标题重复
     */
    ARTICLE_TITLE_EXIST(623, "文章标题重复，请换一个"),

    /**
     * 文章还没攥写内容，不可修改状态
     */
    ARTICLE_NOT_WRITTEN(626, "当前文章还没撰写内容，不可修改状态"),

    /**
     * 邮箱没有用户使用
     */
    EMAIL_NOT_USER(627, "当前邮箱没有用户使用"),

    /**
     * 文章已经被封禁或者删除
     */
    ARTICLE_IS_BAN_OR_DEL(628, "当前文章已被封禁或删除，感谢您的支持与配合"),

    /**
     * 文章被删除
     */
    ARTICLE_IS_EMPTY(629, "文章不存在"),

    /**
     * 文章封禁
     */
    ARTICLE_IS_BAN(630, "当前文章因违规被封禁，请修改内容后提交审核"),

    /**
     * 文章不需要申述
     */
    ARTICLE_NOT_REPORT(631, "当前文章不需要申述，请尝试刷新状态"),

    /**
     * 文章不需要申述
     */
    ARTICLE_IS_AUDIT(632, "当前文章正在重新审核中，无法改变状态"),

    /**
     * 文章举报信息删除不符合规定
     */
    REPORT_ARTICLE_DEL_FAIL(633, "删除失败，只有已经审核并且通过审核的举报信息才能删除"),

    /**
     * 问卷已经被封禁或者删除
     */
    SURVEY_IS_BAN_OR_DEL(634, "当前问卷已被封禁或删除，感谢您的支持与配合"),

    /**
     * 问卷为空
     */
    SURVEY_IS_EMPTY(635, "问卷不存在"),

    /**
     * 问卷不需要申述
     */
    SURVEY_NOT_REPORT(636, "当前文章不需要申述，请尝试刷新状态"),

    /**
     * 导航图大于五张
     */
    NAVI_IMG_MANY(637, "当前开启的导航图已经大于五张，请先关闭一张之后在开启"),

    /**
     * 导航图大于五张
     */
    BALANCE_LACK(638, "当前账户余额不足，无法设置奖励金额，请先充值或更改金额大小"),

    /**
     * 号码验证失败
     */
    PHONE_INVALID(639, "当前手机号格式有误，请输入正确的手机号"),

    /**
     * 重复号码领取
     */
    PHONE_REPAID(640,"当前号码已经领取过奖励，请勿重复领取！");


    /**
     * 响应状态码
     */
    private int val;

    /**
     * 响应状态信息
     */
    private String msg;

    ResponseCode(int value, String msg) {
        this.val = value;
        this.msg = msg;
    }

    public int val() {
        return val;
    }

    public String msg() {
        return msg;
    }

    /**
     * 根据响应状态码获取响应信息
     *
     * @param val 响应状态码
     * @return 响应信息
     */
    public static String getMsgByVal(int val) {
        for (ResponseCode responseCode : values()) {
            if (responseCode.val == val) {
                return responseCode.msg;
            }
        }
        throw new IllegalArgumentException("未知的响应码：" + val);
    }
}
