package com.nekotaku.questionnairesystem.controller;


import com.nekotaku.questionnairesystem.common.R.ResponseCode;
import com.nekotaku.questionnairesystem.common.R.ResponseConstants;
import com.nekotaku.questionnairesystem.common.R.Result;
import com.nekotaku.questionnairesystem.vo.QuestionTmpVo;
import com.nekotaku.questionnairesystem.service.TmpQuestionService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 * 模板问卷问题表 前端控制器
 * </p>
 *
 * @author nekotaku
 * @since 2024-03-04
 */
@RestController
@RequestMapping("/tmp-question")
@Slf4j
public class TmpQuestionController {

    @Autowired
    private TmpQuestionService tmpQuestionService;


    /**
     * 保存问卷模板
     *
     * @param questionTmpVo
     * @return
     */
    @PostMapping("/saveTmpQuestion")
    public Result saveTmpQuestion(@RequestBody List<QuestionTmpVo> questionTmpVo) {
        // 判断问题是否为空
        if (questionTmpVo.isEmpty()) {
            int code = Integer.parseInt(ResponseConstants.INVALID_QUESTION_CODE);
            return Result.fail(code, ResponseCode.getMsgByVal(code));
        }

        // 提交保存
        Integer res = tmpQuestionService.saveQuestion(questionTmpVo);
        if (res != 200) {
            return Result.fail(res, ResponseCode.getMsgByVal(res));
        }
        return Result.success(res, "问卷模板设计完成");
    }


    /**
     * 获取问卷模板问题和选项
     *
     * @param tmpId
     * @return
     */
    @GetMapping("/getTmpQuestionList/{tmpId}")
    public Result getQuestionBySurveyId(@PathVariable("tmpId") Long tmpId) {
        log.info("获取模板问卷id:" + tmpId);
        // 获取问卷问题
        List<QuestionTmpVo> questionDto = tmpQuestionService.getTmpQuestions(tmpId);

        if (questionDto.isEmpty()) {
            return Result.fail(ResponseCode.FAIL.val(), ResponseCode.FAIL.msg());
        }
        return Result.success(ResponseCode.SUCCESS.msg(), questionDto);
    }


}
