package com.nekotaku.questionnairesystem.controller;


import cn.hutool.core.bean.BeanUtil;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.nekotaku.questionnairesystem.common.R.ResponseCode;
import com.nekotaku.questionnairesystem.common.R.Result;
import com.nekotaku.questionnairesystem.common.page.QueryPageParam;
import com.nekotaku.questionnairesystem.entity.report.ReportSurvey;
import com.nekotaku.questionnairesystem.service.ReportSurveyService;
import com.nekotaku.questionnairesystem.utils.TokenUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.constraints.NotBlank;

/**
 * <p>
 * 问卷举报信息表 前端控制器
 * </p>
 *
 * @author nekotaku
 * @since 2024-04-05
 */
@RestController
@RequestMapping("/report-survey")
public class ReportSurveyController {

    @Autowired
    private TokenUtil tokenUtil;

    @Autowired
    private ReportSurveyService reportSurveyService;

    /**
     * 增加或者修改一条举报信息(修改主要针对于多个用户对同一篇问卷的举报)
     *
     * @param reportSurvey
     * @return
     */
    @PostMapping("/report")
    public Result saveOrUpdate(@RequestBody ReportSurvey reportSurvey,
                               HttpServletRequest request) {
        // 是否管理员操作
        boolean isAdminUser = tokenUtil.checkIsAdmin(request);

        Integer res = isAdminUser ? reportSurveyService.saveOrUpdateArticleReport(reportSurvey, true)
                : reportSurveyService.saveOrUpdateArticleReport(reportSurvey, false);

        if (res != ResponseCode.SUCCESS.val()) {
            return Result.fail(res, ResponseCode.getMsgByVal(res));
        }


        String msg = (BeanUtil.isNotEmpty(reportSurvey.getReportId()) && isAdminUser) ?
                "已完成问卷：" + reportSurvey.getReportSurveyTitle() + " 的审批"
                : "我们已经收到您的举报，我们将尽快审核此问卷，感谢您的支持和配合";
        return Result.success(res, msg);
    }

    /**
     * 分页查询举报文章信息列表(可带条件查询)
     *
     * @param queryPageParam
     * @param request
     * @return
     */
    @PostMapping("/listReportSurvey")
    public Result listReportArticle(@RequestBody QueryPageParam queryPageParam,
                                    HttpServletRequest request) {
        // 判断是否为管理员操作
        boolean isAdminUser = tokenUtil.checkIsAdmin(request);
        if (!isAdminUser) {
            // 非管理员用户拒绝访问
            return Result.fail(ResponseCode.FORBIDDEN.val(),
                    ResponseCode.FORBIDDEN.msg());
        }
        // 分页查询
        Page<ReportSurvey> res = reportSurveyService.listReportSurvey(queryPageParam);

        return Result.success(ResponseCode.SUCCESS.val(), ResponseCode.SUCCESS.msg(),
                res.getRecords(), res.getTotal());
    }

    /**
     * 问卷申述
     *
     * @param request
     * @param surveyId
     * @return
     */
    @PutMapping("/appealSurvey/{SurveyId}")
    public Result appealSurvey(HttpServletRequest request, @PathVariable("SurveyId") Long surveyId) {
        // 获取用户id
        Long userId = tokenUtil.getUserIdFromToken(request);

        // 申述
        Integer res = reportSurveyService.appealSurvey(userId, surveyId);

        if (res != ResponseCode.SUCCESS.val()) {
            return Result.fail(res, ResponseCode.getMsgByVal(res));
        }

        return Result.success(res, "申述已经提交，我们将尽快对此问卷进行审核，感谢您的支持和配合");
    }

    /**
     * 删除问卷举报的信息(只有审核完成，且已经通过的审核的信息才能删除)
     *
     * @param request
     * @param surveyId
     * @return
     */
    @DeleteMapping("/delReportSurvey/{SurveyId}")
    public Result delReportSurvey(HttpServletRequest request,
                                  @NotBlank @PathVariable("SurveyId") Long surveyId) {
        // 检查是否管理员操作
        boolean isAdmin = tokenUtil.checkIsAdmin(request);

        if(!isAdmin){
            // 无权限
            return Result.fail(ResponseCode.FORBIDDEN.val(), ResponseCode.FORBIDDEN.msg());
        }
        Integer res = reportSurveyService.delReportSurvey(surveyId);

        if (res != ResponseCode.SUCCESS.val()) {
            return Result.fail(res, ResponseCode.getMsgByVal(res));
        }

        return Result.success(res, "删除举报问卷信息成功");
    }
}
