package com.nekotaku.questionnairesystem.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.io.Serializable;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 调查问卷表（主要是问卷的基本信息）
 * </p>
 *
 * @author nekotaku
 * @since 2023-12-13
 */
@Data
@EqualsAndHashCode(callSuper = false)
@ApiModel(value = "Survey对象", description = "调查问卷表（主要是问卷的基本信息）")
public class Survey implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "问卷ID(主键)")
    @TableId(value = "survey_id")
    private Long surveyId;

    @ApiModelProperty(value = "用户id")
    private Long userId;

    @ApiModelProperty(value = "问卷标题")
    private String surveyTitle;

    @ApiModelProperty(value = "问卷描述")
    private String surveyDescription;

    @ApiModelProperty(value = "问卷创建时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    @ApiModelProperty(value = "问卷更新时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;

    @ApiModelProperty(value = "问卷开始时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
    private LocalDateTime surveyStartTime;

    @ApiModelProperty(value = "问卷结束时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
    private LocalDateTime surveyEndTime;

    @ApiModelProperty(value = "问卷回收数量")
    private Integer surveyCollected;

    @ApiModelProperty(value = "问卷需要收集的总数")
    private Integer surveyCollectedLimit;

    @ApiModelProperty(value = "问卷分类id")
    private Long surveyCategoryId;

    @ApiModelProperty(value = "问卷状态id(发布中1、完成2、未发布0、暂停-1、未设计-2、未开始3)")
    private Integer surveyStatus;

    @ApiModelProperty(value = "问卷完成后结束语")
    private String surveyTip;

    @ApiModelProperty(value = "奖励金额")
    private BigDecimal surveyBalance;

}
