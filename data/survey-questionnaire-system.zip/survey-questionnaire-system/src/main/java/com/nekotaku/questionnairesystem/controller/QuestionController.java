package com.nekotaku.questionnairesystem.controller;


import com.nekotaku.questionnairesystem.common.R.ResponseCode;
import com.nekotaku.questionnairesystem.common.R.ResponseConstants;
import com.nekotaku.questionnairesystem.common.R.Result;
import com.nekotaku.questionnairesystem.vo.QuestionVo;
import com.nekotaku.questionnairesystem.entity.Survey;
import com.nekotaku.questionnairesystem.service.QuestionService;
import com.nekotaku.questionnairesystem.utils.TokenUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * <p>
 * 问卷问题表 前端控制器
 * </p>
 *
 * @author nekotaku
 * @since 2024-01-27
 */
@RestController
@RequestMapping("/question")
@Slf4j
public class QuestionController {

    @Autowired
    private QuestionService questionService;

    @Autowired
    private TokenUtil tokenUtil;

    /**
     * 保存问题(可兼容更新)
     *
     * @param questionsDto
     * @return
     */
    @PostMapping("/saveQuestion")
    public Result saveQuestion(@RequestBody List<QuestionVo> questionsDto) {
//        log.info("获取问题：" + questionsDto);
        // 判断是否为空
        if (questionsDto.isEmpty()) {
            int code = Integer.parseInt(ResponseConstants.INVALID_QUESTION_CODE);
            return Result.fail(code, ResponseCode.getMsgByVal(code));
        }

        // 提交保存
        Integer res = questionService.saveQuestion(questionsDto);
        if (res != ResponseCode.SUCCESS.val()) {
            return Result.fail(res, ResponseCode.getMsgByVal(res));
        }
        return Result.success(res, "问卷设计完成，可发布问卷！");
    }

    /**
     * 根据问卷id获取问卷问题和选项
     *
     * @return
     */
    @GetMapping("/getQuestionList/{surveyId}")
    public Result getQuestionBySurveyId(@PathVariable("surveyId") Long surveyId) {
        log.info("获取问卷id:" + surveyId);
        // 获取问卷问题和问题选项
        List<QuestionVo> questionVo = questionService.getQuestions(surveyId);

        if (questionVo.isEmpty()) {
            return Result.fail(ResponseCode.FAIL.val(), ResponseCode.FAIL.msg());
        }
        return Result.success(ResponseCode.SUCCESS.msg(), questionVo);
    }

    /**
     * 获取单选题的问题和选项
     *
     * @param surveyId
     * @return
     */
    @GetMapping("/getSingleQuestionBySurveyId/{surveyId}")
    public Result getSingleQuestionBySurveyId(@PathVariable("surveyId") Long surveyId) {
        // 获取问卷单选题问题和问题选项选项
        List<QuestionVo> questionVo = questionService.getSingleQuestions(surveyId);

        if (questionVo.isEmpty()) {
            return Result.fail(ResponseCode.FAIL.val(), ResponseCode.FAIL.msg());
        }
        return Result.success(ResponseCode.SUCCESS.msg(), questionVo);
    }

    /**
     * 使用模板新增问卷,并保存问题
     *
     * @param survey
     * @param tmpId
     * @param httpServletRequest
     * @return
     */
    @PostMapping("/saveForTempSurvey")
    public Result saveForTempSurvey(@RequestBody Survey survey, @RequestParam Long tmpId,
                                    HttpServletRequest httpServletRequest) {
        // 用户id
        Long userId = tokenUtil.getUserIdFromToken(httpServletRequest);

        survey.setUserId(userId);

        // 调用保存模板服务
        Integer res = questionService.saveForTempSurvey(survey, tmpId);

        if (res != ResponseCode.SUCCESS.val()) {
            return Result.fail(res, ResponseCode.getMsgByVal(res));
        }
        return Result.success(res, "新增问卷成功");

    }


}
