package com.nekotaku.questionnairesystem.vo.excel;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import lombok.Data;

import java.util.List;

/**
 * 实现excel表一对多关系(弃用，没有处理合并单元格)
 *
 * @Title:ExcelQuestionVo
 * @Author:NekoTaku
 * @Date:2024/03/16 16:25
 * @Version:1.0
 */
@Data
@Deprecated // 弃用注解
public class ExcelQuestionVo {

    @ColumnWidth(50)
    @ExcelProperty(value = "问题")
    private String questionContent;

    @ColumnWidth(50)
    @ExcelProperty(value = "回答列表")
    private List<ExcelAnswerVo> answerVos;
}
