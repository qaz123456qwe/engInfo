package com.nekotaku.questionnairesystem.mapper;

import com.nekotaku.questionnairesystem.entity.report.ReportArticle;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 *  文章举报表 Mapper 接口
 * </p>
 *
 * @author nekotaku
 * @since 2024-04-01
 */
@Mapper
public interface ReportArticleMapper extends BaseMapper<ReportArticle> {

}
