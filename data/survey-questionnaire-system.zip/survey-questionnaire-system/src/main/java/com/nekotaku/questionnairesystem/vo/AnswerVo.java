package com.nekotaku.questionnairesystem.vo;

import com.nekotaku.questionnairesystem.entity.Answer;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @Title:AnswerDto
 * @Author:NekoTaku
 * @Date:2024/02/21 9:06
 * @Version:1.0
 */
@Data
public class AnswerVo implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "问卷id")
    private Long surveyId;

    @ApiModelProperty(value = "答案列表")
    private List<Answer> answerList;
}
