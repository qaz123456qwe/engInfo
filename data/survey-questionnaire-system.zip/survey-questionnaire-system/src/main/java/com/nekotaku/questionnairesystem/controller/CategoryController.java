package com.nekotaku.questionnairesystem.controller;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.nekotaku.questionnairesystem.common.R.ResponseCode;
import com.nekotaku.questionnairesystem.common.R.ResponseConstants;
import com.nekotaku.questionnairesystem.common.R.Result;
import com.nekotaku.questionnairesystem.common.page.QueryPageParam;
import com.nekotaku.questionnairesystem.entity.Category;
import com.nekotaku.questionnairesystem.service.CategoryService;
import com.nekotaku.questionnairesystem.utils.TokenUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.constraints.NotBlank;
import java.util.List;

/**
 * <p>
 * 分类表 前端控制器
 * </p>
 *
 * @author nekotaku
 * @since 2023-12-10
 */
@RestController
@RequestMapping("/category")
@Slf4j
public class CategoryController {

    @Autowired
    private CategoryService categoryService;

    @Autowired
    private TokenUtil tokenUtil;

    /**
     * 添加或者保存分类
     * @param category
     * @param httpServletRequest
     * @return
     */
    @PostMapping("/addOrUpdateCategory")
    public Result addOrUpdateCategory(@Validated @RequestBody Category category,
                              HttpServletRequest httpServletRequest){

        log.info("需要添加的分类信息:"+category);
        // 获取token，用token解析出用户id
//        String token = httpServletRequest.getHeader("Authorization");
//        Map<String, String> map = tokenUtil.parseToken(token);
//        Long userId = Long.parseLong(map.get("userId"));
        Long userId = tokenUtil.getUserIdFromToken(httpServletRequest);

        // 保存到分类对象中
        category.setUserId(userId);

        Integer res = categoryService.saveOrUpdateCategory(category);
        if(res!=ResponseCode.SUCCESS.val()){
            return Result.fail(res,ResponseCode.getMsgByVal(res));
        }
        return Result.success(res, "分类成功");
    }

    /**
     * 分页查询分类列表(可带条件查询)
     * @param queryPageParam
     * @return
     */
    @PostMapping("/listCategory")
    public Result listCategory(@RequestBody QueryPageParam queryPageParam,
                               HttpServletRequest httpServletRequest){
        Long userId = tokenUtil.getUserIdFromToken(httpServletRequest);
        Page<Category> res = categoryService.listCategory(queryPageParam,userId);
        return Result.success(ResponseCode.SUCCESS.val(), ResponseCode.SUCCESS.msg(),
                res.getRecords(),res.getTotal());
    }

    /**
     * 删除分类
     * @param id
     * @return
     */
    @DeleteMapping("/deleteCategory/{CategoryId}")
    public Result deleteCategory(@NotBlank(message = ResponseConstants.INVALID_RESPONSE_CODE)
                                     @PathVariable("CategoryId") String id){
        Integer res = categoryService.deleteCategory(id);
        if(res!=ResponseCode.SUCCESS.val()){
            return Result.fail(res,ResponseCode.getMsgByVal(res));
        }
        return Result.success(res, "删除分类成功");
    }

    /**
     * 批量删除分类
     * @param ids
     * @return
     */
    @PostMapping("/deleteByIds")
    public Result deleteByIds(@NotBlank(message = ResponseConstants.INVALID_RESPONSE_CODE) String ids){
        return categoryService.deleteByIds(ids);
    }

    /**
     * 根据用户id获取分类列表
     * @param httpServletRequest
     * @return
     */
    @GetMapping("/getCategories")
    public Result  getCategoriesByUserId(HttpServletRequest httpServletRequest){
        Long userId = tokenUtil.getUserIdFromToken(httpServletRequest);
        List<Category> categories = categoryService.getCategoriesByUserId(userId);
        return Result.success(categories);
    }
}
