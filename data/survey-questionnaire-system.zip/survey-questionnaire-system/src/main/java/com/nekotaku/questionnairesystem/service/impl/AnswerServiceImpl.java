package com.nekotaku.questionnairesystem.service.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.nekotaku.questionnairesystem.common.R.ResponseCode;
import com.nekotaku.questionnairesystem.common.enums.QuestionType;
import com.nekotaku.questionnairesystem.common.exception.CustomException;
import com.nekotaku.questionnairesystem.common.page.QueryPageParam;
import com.nekotaku.questionnairesystem.common.constants.redis.RedisConstants;
import com.nekotaku.questionnairesystem.utils.redis.RedisBeanUtil;
import com.nekotaku.questionnairesystem.vo.analysis.AnswerChoiceAnalysisVo;
import com.nekotaku.questionnairesystem.vo.AnswerVo;
import com.nekotaku.questionnairesystem.vo.analysis.TextQuestionAnalysisVo;
import com.nekotaku.questionnairesystem.entity.Answer;
import com.nekotaku.questionnairesystem.mapper.AnswerMapper;
import com.nekotaku.questionnairesystem.service.AnswerService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.nekotaku.questionnairesystem.vo.excel.ExcelAnswerVo;
import com.nekotaku.questionnairesystem.vo.excel.ExcelQuestionVo;
import com.nekotaku.questionnairesystem.vo.excel.ExcelWithChoiceVo;
import com.nekotaku.questionnairesystem.vo.excel.dto.ExportDataBase;
import com.nekotaku.questionnairesystem.vo.excel.dto.ExportDto;
import org.apache.ibatis.session.ExecutorType;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * <p>
 * 问卷结果表	 服务实现类
 * </p>
 *
 * @author nekotaku
 * @since 2024-02-20
 */
@Service
public class AnswerServiceImpl extends ServiceImpl<AnswerMapper, Answer> implements AnswerService {

    @Autowired
    private AnswerMapper answerMapper;

    @Autowired
    private RedisBeanUtil redisBeanUtil;

    @Autowired
    private SqlSessionFactory sqlSessionFactory;

    @Autowired
    @Qualifier("ObjectiveAnalysisRedisTemplate")
    private RedisTemplate<String, TextQuestionAnalysisVo> objectiveAnalysisRedisTemplate;

    /**
     * 保存答案
     *
     * @param answerVo
     * @param logId
     * @return
     */
    @Override
    @Transactional
    public Integer saveAnswer(AnswerVo answerVo, Long logId) {

        /**
         * 在 MyBatis 中使用 ExecutorType.BATCH 进行批量操作，是通过控制 SqlSession 来手动管理批量操作。
         * 这种方式可以有效减少与数据库的交互次数，从而提升大批量数据操作的性能。
         * 它适合复杂的场景，其中可能需要在批量操作中进行条件判断、循环或其他逻辑处理。
         * 优点:
         *
         * 更高的灵活性: 可以在批处理过程中根据具体逻辑添加条件语句或逻辑处理。
         * 性能优化: 对于大量数据操作，通过减少数据库的交互次数来优化性能。
         * 缺点:
         *
         * 代码复杂: 需要手动管理 SqlSession 的开启、提交和关闭，代码管理相对繁琐。
         * 缺乏声明式事务支持: 需要手动处理事务的提交和回滚，易于出错。
         */
        SqlSession sqlSession = null;
        try{
            sqlSession = sqlSessionFactory.openSession(ExecutorType.BATCH);
            AnswerMapper answerMapper = sqlSession.getMapper(AnswerMapper.class);
            // 获取选项列表
            List<Answer> answerList = answerVo.getAnswerList();
            for (Answer answer : answerList) {
                // 设置问卷id
                answer.setSurveyId(answerVo.getSurveyId());
                // 设置日志id
                answer.setSurveyFinishLogId(logId);
                // 保存答案
                answerMapper.insert(answer);
            }
            sqlSession.commit();
            return ResponseCode.SUCCESS.val();
        }catch (Exception e){
            if (sqlSession != null) {
                // 显式回滚事务
                sqlSession.rollback();
            }
            throw new CustomException("保存问卷选项出错");
        }finally {
            // 确保 sqlSession 总是被关闭
            if (sqlSession != null) {
                sqlSession.close();
            }
        }
        /**
         * 使用 Spring Data 的 saveBatch()（或类似方法）
         * 在 Spring Data JPA 或类似的集成框架中，通常提供了一些如 saveAll() 或 saveBatch() 的方法，
         * 这些方法可以自动处理批量数据的持久化，无需手动管理 SQL 会话和事务。
         * 优点:
         *
         * 简化的代码: 只需一行代码就可以完成批量保存，无需手动管理 SQL 会话和事务。
         * 自动事务管理: 利用 Spring 的 @Transactional 管理事务，减少了出错的可能性。
         * 适用性广: 对于大多数标准的批量插入操作，这种方法简单且高效。
         * 缺点:
         *
         * 可能的性能问题: 对于极大量数据的批处理，这种方法可能不如直接使用 MyBatis 的 ExecutorType.BATCH 来得高效，因为每个对象都会被单独处理，尽管是在一次事务中。
         * 灵活性差: 对于需要在批量处理中执行复杂逻辑的情况，这种方法可能不够灵活。
         */

//        // 获取选项列表
//        List<Answer> answerList = answerVo.getAnswerList();
//        for (Answer answer : answerList) {
//            // 设置问卷id
//            answer.setSurveyId(answerVo.getSurveyId());
//            // 设置日志id
//            answer.setSurveyFinishLogId(logId);
//        }
//        boolean res = saveBatch(answerList);
//        return res ? ResponseCode.SUCCESS.val() : ResponseCode.FAIL.val();
    }

    /**
     * 根据完成记录id获取答案(用于查询每位答题者回答的情况)
     *
     * @param id
     * @return
     */
    @Override
    public List<Answer> getAnswerByLogId(Long id) {

        LambdaQueryWrapper<Answer> qw = new LambdaQueryWrapper<>();
        qw.eq(Answer::getSurveyFinishLogId, id);
        return answerMapper.selectList(qw);
    }

    /**
     * 选择题的数据分析（统计选项选择情况）
     *
     * @param surveyId
     * @return
     */
    @Override
    public List<AnswerChoiceAnalysisVo> getAnswerCountBySurveyId(Long surveyId, Long optionId) {

        return answerMapper.selectSurveyAnswerCount(surveyId, optionId);
    }

    /**
     * 查询客观题回答列表
     *
     * @param queryPageParam
     * @return
     */
    @Override
    public Page<TextQuestionAnalysisVo> getTextAnswerContextList(Long surveyId, QueryPageParam queryPageParam) {

        Page<TextQuestionAnalysisVo> textQuestionAnalysisDtoPage = new Page<>();

        // 设置当前页
        textQuestionAnalysisDtoPage.setCurrent(queryPageParam.getPageNum());
        // 设置当前页面数量
        textQuestionAnalysisDtoPage.setSize(queryPageParam.getPageSize());

        // 条件拼接
        QueryWrapper<TextQuestionAnalysisVo> qw = new QueryWrapper<>();

        HashMap param = queryPageParam.getParam();

        // 问题模糊匹配
        String questionContent = param.get("questionContent").toString();
        if (StringUtils.isNotBlank(questionContent) && !"null".equals(questionContent)) {
            qw.like("A.question_content", questionContent);
        }

        // 匹配问卷id
        qw.eq("A.survey_id", surveyId);

        // 匹配客观题
        qw.eq("A.question_type", QuestionType.TEXTAREA.getTypeId());

        // 按照顺序排序
        qw.orderByAsc("A.question_sort", "C.create_time");


        return answerMapper.selectTextAnswerBySurveyId(textQuestionAnalysisDtoPage, qw);
    }

    /**
     * 根据问卷id获取客观题回答列表(导出excel用，没有处理合并表格，这个弃用)
     *
     * @param surveyId
     * @return
     */
    @Override
    @Deprecated
    public List<ExcelQuestionVo> getTextAnswerContextListForExcel(Long surveyId) {
        List<TextQuestionAnalysisVo> textQuestionAnalysisVos = answerMapper.selectTextAnswerBySurveyIdForExcel(surveyId);
        // 处理成一对多的关系，一个问题对应多条回答
        // 创建一个Map来按问题内容分组，将问题当作key处理
        Map<String, List<ExcelAnswerVo>> questionMap = new HashMap<>();
        for (TextQuestionAnalysisVo item : textQuestionAnalysisVos) {
            String questionContent = item.getQuestionContent();
            String answerContext = item.getAnswerContext();
            LocalDateTime createTime = item.getCreateTime();
            // 创建一个答案实体类
            ExcelAnswerVo answerVo = new ExcelAnswerVo();
            answerVo.setAnswerContext(answerContext);
            answerVo.setCreateTime(createTime);

            // 将回答添加到对应的问题列表中
            if (!questionMap.containsKey(questionContent)) {
                // 如果问题列表不存在，则创建一个新列表
                questionMap.put(questionContent, new ArrayList<>());
            }
            questionMap.get(questionContent).add(answerVo);
        }

        // 将Map转换成ExcelQuestionVo列表
        return questionMap.entrySet().stream()
                .map(entry -> {
                    ExcelQuestionVo questionVo = new ExcelQuestionVo();
                    questionVo.setQuestionContent(entry.getKey());
                    questionVo.setAnswerVos(entry.getValue());
                    return questionVo;
                }).collect(Collectors.toList());
    }

    /**
     * 获取客观题答案详细列表（导出excel可用）
     *
     * @param surveyId
     * @return
     */
    @Override
    public List<TextQuestionAnalysisVo> getTextAnswerContextList(Long surveyId) {
        String key = RedisConstants.ANALYZE_OBJECTIVE_SURVEY + surveyId;

        // 查询redis中是否有
        List<TextQuestionAnalysisVo> list = redisBeanUtil.getList(objectiveAnalysisRedisTemplate, key);
        if (!CollUtil.isEmpty(list)) {
            return list;
        }

        List<TextQuestionAnalysisVo> textQuestionAnalysisVos = answerMapper.selectTextAnswerBySurveyIdForExcel(surveyId);

        // 保存到redis中
        if (!textQuestionAnalysisVos.isEmpty()) {
            redisBeanUtil.setList(objectiveAnalysisRedisTemplate, key, textQuestionAnalysisVos);
            // 设置过期时间(1天)
            redisBeanUtil.setExpiration(objectiveAnalysisRedisTemplate,key,1L, TimeUnit.DAYS);
        }
        return textQuestionAnalysisVos;
    }

    /**
     * 获取选择题和客观题的回答内容（导出excel用）
     *
     * @param surveyId
     * @return
     */
    @Override
    public List<ExcelWithChoiceVo> getTextWithChoiceAnswer(Long surveyId) {
        return answerMapper.selectTextWithChoiceBySurveyIdForExcel(surveyId);
    }

    /**
     * 获取导出Excel所需要的数据格式
     * 当前问卷的所有人的选择题回答和客观题回答
     *
     * @param textWithChoiceAnswer
     * @return
     */
    @Override
    public List<ExportDto> ExcelWithChoiceVoConvertToExportDto(List<ExcelWithChoiceVo> textWithChoiceAnswer) {
        // 使用map进行优化
        // 创建一个 Map 来存储 surveyFinishLogId 和对应的 ExportDto
        Map<Long, ExportDto> exportDtoMap = new HashMap<>();

        // 遍历问卷回答数据
        for (ExcelWithChoiceVo excelWithChoiceVo : textWithChoiceAnswer) {
            Long surveyFinishLogId = excelWithChoiceVo.getSurveyFinishLogId();

            // 获取或创建对应的 ExportDto 对象
            ExportDto exportDto = exportDtoMap.get(surveyFinishLogId);
            if (exportDto == null) {
                // 如果没有找到相同 surveyFinishLogId 的 ExportDto，则创建一个新的
                exportDto = new ExportDto();
                exportDto.setSurveyFinishLogId(surveyFinishLogId);
                exportDto.setBases(new ArrayList<>());
                exportDtoMap.put(surveyFinishLogId, exportDto);
            }

            // 获取回答内容，若为空则使用选项内容
            String answerContext = excelWithChoiceVo.getAnswerContext();
            String answer = StrUtil.isEmpty(answerContext) ? excelWithChoiceVo.getOptionContents() : answerContext;

            // 将问题和回答添加到 ExportDto 中
            exportDto.getBases().add(new ExportDataBase(excelWithChoiceVo.getQuestionContent(), answer));
        }

        // 将 Map 中的导出数据对象转换为列表
        List<ExportDto> exportDtos = new ArrayList<>(exportDtoMap.values());

        // 设置导出数据对象的索引
        for (int i = 0; i < exportDtos.size(); i++) {
            exportDtos.get(i).setSurveyFinishLogId((long) (i + 1));
        }

        return exportDtos;
    }

    /**
     * // 根据问卷id，批量删除问卷回答表的信息
     * @param reportSurveyId
     */
    @Override
    public void deleteBySurveyId(Long reportSurveyId) {

        LambdaQueryWrapper<Answer> qw = new LambdaQueryWrapper<>();
        qw.eq(Answer::getSurveyId,reportSurveyId);
        answerMapper.delete(qw);
    }
}
