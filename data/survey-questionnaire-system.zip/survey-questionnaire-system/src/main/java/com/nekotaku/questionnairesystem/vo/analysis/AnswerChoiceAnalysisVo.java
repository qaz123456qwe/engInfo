package com.nekotaku.questionnairesystem.vo.analysis;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * 对于选择题的答案分析，统计每个选项的选择数
 *
 * @Title:AnswerChoiceAnalysisDto
 * @Author:NekoTaku
 * @Date:2024/03/12 10:13
 * @Version:1.0
 */
@Data
public class AnswerChoiceAnalysisVo implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "问卷id")
    private Long surveyId;

    @ApiModelProperty(value = "问题id")
    private Long  questionId;

    @ApiModelProperty(value = "选项id")
    private Long optionId;

    @ApiModelProperty(value = "选项选择的数量")
    private Integer answerCount;
}
