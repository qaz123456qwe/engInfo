package com.nekotaku.questionnairesystem.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.nekotaku.questionnairesystem.common.R.Result;
import com.nekotaku.questionnairesystem.common.page.QueryPageParam;
import com.nekotaku.questionnairesystem.vo.QuestionTmpVo;
import com.nekotaku.questionnairesystem.vo.SurveyAndQuestionVo;
import com.nekotaku.questionnairesystem.entity.TmpSurvey;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 * 模板问卷表 服务类
 * </p>
 *
 * @author nekotaku
 * @since 2024-03-02
 */
public interface TmpSurveyService extends IService<TmpSurvey> {

    Integer saveOrUpdateSurveyTmp(TmpSurvey tmpSurvey);

    Page<TmpSurvey> listTmpSurveys(QueryPageParam queryPageParam, Long userId);

    TmpSurvey getTmpSurveyById(Long tmpId);

    Integer changeTmpSurveyStatus(Long tmpId,Integer status);

    Integer deleteSurveyTmpById(Long tmpId, Long userId);

    Result deleteByIds(String ids);

    SurveyAndQuestionVo getTmpSurveyDetailedById(Long tmpId, List<QuestionTmpVo> tmpQuestions);
}
