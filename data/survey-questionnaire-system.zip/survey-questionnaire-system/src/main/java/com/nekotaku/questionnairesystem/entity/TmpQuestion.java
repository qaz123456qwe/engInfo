package com.nekotaku.questionnairesystem.entity;

import cn.hutool.core.annotation.Alias;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 模板问卷问题表
 * </p>
 *
 * @author nekotaku
 * @since 2024-03-04
 */
@Data
@EqualsAndHashCode(callSuper = false)
@ApiModel(value="TmpQuestion对象", description="模板问卷问题表")
public class TmpQuestion implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "模板问题id")
    @TableId(value = "tmp_question_id")
    @Alias("questionId")
    private Long tmpQuestionId;

    @ApiModelProperty(value = "模板id")
    @Alias("surveyId")
    private Long tmpId;

    @ApiModelProperty(value = "模板问卷类型id(单选、多选、单行输入)")
    @Alias("questionType")
    private Integer tmpQuestionType;

    @ApiModelProperty(value = "模板问题内容")
    @Alias("questionContent")
    private String tmpQuestionContent;

    @ApiModelProperty(value = "模板题目顺序")
    @Alias("questionSort")
    private Integer tmpQuestionSort;


}
