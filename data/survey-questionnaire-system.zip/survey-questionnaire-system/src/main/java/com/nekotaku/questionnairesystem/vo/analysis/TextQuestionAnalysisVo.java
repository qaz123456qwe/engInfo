package com.nekotaku.questionnairesystem.vo.analysis;

import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.nekotaku.questionnairesystem.utils.excel.EasyExcelLocalDateTimeConverter;
import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 客观题分析Vo
 *
 * @Title:TextQuestionAnalysisDto
 * @Author:NekoTaku
 * @Date:2024/03/15 8:52
 * @Version:1.0
 */
@Data
public class TextQuestionAnalysisVo implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * excel生成忽略的字段
     */
    @ExcelIgnore
    private Long surveyId;

    @ExcelIgnore
    private Long questionId;

    @ColumnWidth(50)
    @ExcelProperty(value = "问题")
    private String questionContent;

    @ColumnWidth(50)
    @ExcelProperty(value = "回答")
    private String answerContext;

    @ColumnWidth(50)
    @ExcelProperty(value = "完成时间",converter = EasyExcelLocalDateTimeConverter.class)
    private LocalDateTime createTime;
}
