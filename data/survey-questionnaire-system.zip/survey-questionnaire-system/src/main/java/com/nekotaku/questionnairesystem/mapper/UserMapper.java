package com.nekotaku.questionnairesystem.mapper;

import com.nekotaku.questionnairesystem.entity.User;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * 调查问卷系统用户表 Mapper 接口
 * </p>
 *
 * @author nekotaku
 * @since 2023-11-20
 */
@Mapper
public interface UserMapper extends BaseMapper<User> {

}
