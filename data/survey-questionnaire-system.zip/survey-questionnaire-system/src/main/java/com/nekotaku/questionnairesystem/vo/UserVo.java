package com.nekotaku.questionnairesystem.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.nekotaku.questionnairesystem.common.R.ResponseConstants;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.Email;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * @Title:UserDto
 * @Author:NekoTaku
 * @Date:2023/12/03 16:54
 * @Version:1.0
 */
@Data
public class UserVo {

    @ApiModelProperty(value = "用户名")
    private String userName;

    @ApiModelProperty(value = "用户昵称")
    private String userNickname;

    @ApiModelProperty(value = "用户头像路径")
    private String userAvatarPath;

    @ApiModelProperty(value = "用户邮箱")
    @Email(message = ResponseConstants.INVALID_RESPONSE_CODE)
    private String userEmail;

    @ApiModelProperty(value = "用户角色")
    private String role;

    @ApiModelProperty(value = "用户余额")
    private BigDecimal userBalance;

    @ApiModelProperty(value = "用户登录时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
    private LocalDateTime loginTime;

}
