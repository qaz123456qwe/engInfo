package com.nekotaku.questionnairesystem.common.enums;

/**
 * 文章状态枚举类
 *
 * @Title:ArticleType
 * @Author:NekoTaku
 * @Date:2024/03/21 15:28
 * @Version:1.0
 */
public enum ArticleStatus {
    OPEN(1, "公开"),
    PRIVATE(0, "隐藏"),
    NOT_WRITTEN(-1, "未撰写"),

    ARTICLE_BAN(2, "被封禁"),
    ARTICLE_AUDIT(3,"待审核");

    private final int statusId;
    private final String statusName;

    ArticleStatus(int statusId, String statusName) {
        this.statusId = statusId;
        this.statusName = statusName;
    }

    public int getStatusId() {
        return statusId;
    }

    public String getStatusName() {
        return statusName;
    }

    public static ArticleStatus getByStatusId(int statusId) {
        for (ArticleStatus article : values()) {
            if (article.getStatusId() == statusId) {
                return article;
            }
        }
        throw new IllegalArgumentException("无效状态id: " + statusId);
    }

}
