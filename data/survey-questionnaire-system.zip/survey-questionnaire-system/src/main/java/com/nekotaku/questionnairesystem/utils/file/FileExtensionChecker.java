package com.nekotaku.questionnairesystem.utils.file;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;

/**
 * 图片格式检查器
 *
 * @Title:FileExtensionChecker
 * @Author:NekoTaku
 * @Date:2024/03/20 14:02
 * @Version:1.0
 */
@Component
public class FileExtensionChecker {

    private final List<String> allowedExtensions;

    public FileExtensionChecker(@Value("${allowed.extensions}") String allowedExtensions) {
        this.allowedExtensions = Arrays.asList(allowedExtensions.split(","));
    }

    public boolean isAllowedExtension(String fileName) {
        String extension = getFileExtension(fileName);
        return extension != null && allowedExtensions.contains(extension.toLowerCase());
    }

    private String getFileExtension(String fileName) {
        int dotIndex = fileName.lastIndexOf('.');
        if (dotIndex >= 0 && dotIndex < fileName.length() - 1) {
            return fileName.substring(dotIndex + 1);
        }
        return null;
    }

}
