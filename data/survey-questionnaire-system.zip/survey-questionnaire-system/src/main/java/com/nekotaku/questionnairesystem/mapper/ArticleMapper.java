package com.nekotaku.questionnairesystem.mapper;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Constants;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.nekotaku.questionnairesystem.entity.Article;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.nekotaku.questionnairesystem.vo.front.ArticleFrontVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 *  文章表 Mapper 接口
 * </p>
 *
 * @author nekotaku
 * @since 2024-03-19
 */
@Mapper
public interface ArticleMapper extends BaseMapper<Article> {

    // 查询前台首页的文章列表
    Page<ArticleFrontVo> selectArticleFront(Page<ArticleFrontVo> page
            , @Param(Constants.WRAPPER) QueryWrapper<ArticleFrontVo> queryWrapper);

}
