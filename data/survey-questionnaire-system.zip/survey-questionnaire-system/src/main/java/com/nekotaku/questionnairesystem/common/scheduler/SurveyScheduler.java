package com.nekotaku.questionnairesystem.common.scheduler;

import com.nekotaku.questionnairesystem.common.enums.SurveyStatus;
import com.nekotaku.questionnairesystem.vo.SurveyAndQuestionVo;
import com.nekotaku.questionnairesystem.entity.Survey;
import com.nekotaku.questionnairesystem.service.SurveyService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * 定时器，检查问卷是否到达开始时间或者结束时间
 *
 * @Title:SurveyScheduler
 * @Author:NekoTaku
 * @Date:2024/02/10 15:32
 * @Version:1.0
 */
@Component
@Slf4j
public class SurveyScheduler {

    @Autowired
    private SurveyService surveyService;

    @Autowired
    @Qualifier("surveyRedisTemplate")
    private RedisTemplate<String, SurveyAndQuestionVo> redisTemplate;

    // 每5分钟检查一次
    @Scheduled(fixedRate = 300000)
//    @Scheduled(fixedRate = 30000)
    @Async("myAsyncExecutor")
    public void checkTime() {
        LocalDateTime currentDateTime = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String formattedTime = currentDateTime.format(formatter);
        log.info("问卷定时任务执行了："+formattedTime);

//        Set<String> keys = redisTemplate.keys(RedisConstants.PUBLISH_SURVEY + "*");
//        if(CollUtil.isNotEmpty(keys)){
//            for (String key : keys) {
//                SurveyAndQuestionDto surveyAndQuestionDto = redisTemplate.opsForValue().get(key);
//                // 插入断言
//                assert surveyAndQuestionDto != null;
//                Survey survey = surveyService.getSurveyById(surveyAndQuestionDto.getSurveyId());
//                surveyService.processSurveyAsync(survey);
//            }
//        }
        // 获取问卷未开始的问卷列表
        List<Survey> surveysNotStart = surveyService.getSurveysByStatus(SurveyStatus.UN_STARTED.getStatusId());
        for (Survey survey : surveysNotStart) {
            surveyService.checkSurveyIsStart(survey);
        }

        // 获取问卷未结束的问卷列表(包括发布中和暂停中的)
        List<Survey> surveysNotEnd = surveyService.getSurveysByStatus(SurveyStatus.PUBLISHED.getStatusId());
        surveysNotEnd.addAll(surveyService.getSurveysByStatus(SurveyStatus.PAUSED.getStatusId()));
        for(Survey survey:surveysNotEnd){
            surveyService.checkSurveyIsEnd(survey);
        }
    }

}
