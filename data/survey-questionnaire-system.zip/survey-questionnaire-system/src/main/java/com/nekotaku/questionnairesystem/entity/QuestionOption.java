package com.nekotaku.questionnairesystem.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 选项表，对应问卷问题的选择题
 * </p>
 *
 * @author nekotaku
 * @since 2024-01-29
 */
@Data
@EqualsAndHashCode(callSuper = false)
@ApiModel(value="QuestionOption对象", description="选项表，对应问卷问题的选择题")
public class QuestionOption implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "选项id")
    @TableId(value = "option_id", type = IdType.AUTO)
    private Long optionId;

    @ApiModelProperty(value = "问卷问题的id")
    private Long questionId;

    @ApiModelProperty(value = "选项内容")
    private String optionContent;

    @ApiModelProperty(value = "选项顺序")
    private Integer optionSort;

}
