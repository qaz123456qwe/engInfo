package com.nekotaku.questionnairesystem.controller;

import com.nekotaku.questionnairesystem.common.R.ResponseCode;
import com.nekotaku.questionnairesystem.common.R.ResponseConstants;
import com.nekotaku.questionnairesystem.common.R.Result;
import com.nekotaku.questionnairesystem.common.lock.TimeoutLock;
import com.nekotaku.questionnairesystem.entity.User;
import com.nekotaku.questionnairesystem.service.UserService;
import com.nekotaku.questionnairesystem.utils.TokenUtil;
import com.nekotaku.questionnairesystem.vo.email.EmailVo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import java.util.HashMap;


/**
 * <p>
 * 调查问卷系统用户表 前端控制器
 * </p>
 *
 * @author nekotaku
 * @since 2023-11-20
 */
@Slf4j
@Validated
@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;

    @Autowired
    private TokenUtil tokenUtil;


//    @GetMapping("/test")
//    public Result testToken(HttpServletRequest request) {
//        throw new CustomException(String.valueOf(ResponseCode.TOKEN_INVALID.val()));
//    }

    /**
     * 用户登录
     *
     * @param account  用户名或邮箱
     * @param password
     * @return
     */
    @PostMapping("/login")
    public Result login(@RequestParam("account") String account,
                        @RequestParam("password") String password) {
        log.info("用户 {} 登录", account);
        return userService.login(account, password);
    }


    /**
     * 用户注册
     *
     * @param user
     * @return
     */
    @PostMapping("/register")
    public Result register(@RequestBody User user,
                           @RequestParam String code, @RequestParam String type) {

        log.info("注册参数User:" + user + ",code:" + code + ",type:" + type);

        if (user == null) {
            return Result.fail(ResponseCode.FAIL.val(), "请求错误");
        }
        Integer res = userService.register(user, code, type);
        if (res != ResponseCode.SUCCESS.val()) {
            return Result.fail(res, ResponseCode.getMsgByVal(res));
        }
        return Result.success(ResponseCode.SUCCESS.val(), "注册成功");
    }

    /**
     * 用户获取邮箱验证码
     *
     * @param email
     * @return
     */
    @PostMapping("/sendEmail")
    public Result getEmailCode(
            @NotBlank @Email(message = ResponseConstants.INVALID_RESPONSE_CODE) @RequestParam String email,
            @NotBlank(message = ResponseConstants.INVALID_RESPONSE_CODE) @RequestParam String type) {
        log.info("邮箱：" + email + ",类型：" + type);
        Integer rCode = userService.getEmailCode(email, type);
        if (rCode != ResponseCode.SUCCESS.val()) {
            return Result.fail(rCode, ResponseCode.getMsgByVal(rCode));
        }

        return Result.success(rCode, "验证码已发送，请注意查收");
    }

    /**
     * 更改用户信息
     *
     * @param request
     * @param avatar   头像地址
     * @param nickName 用户昵称
     * @return
     */
    @PutMapping("/updateUserInfo")
    public Result updateUserInfo(HttpServletRequest request,
                                 @NotBlank(message = ResponseConstants.INVALID_RESPONSE_CODE) @RequestParam("userAvatar") String avatar,
                                 @NotBlank(message = ResponseConstants.INVALID_RESPONSE_CODE) @RequestParam("nickName") String nickName) {
        Long userId = tokenUtil.getUserIdFromToken(request);
        Integer res = userService.updateUserInfo(userId, avatar, nickName);
        if (res != ResponseCode.SUCCESS.val()) {
            return Result.fail(res, ResponseCode.getMsgByVal(res));
        }

        // 获取用户信息，重新绑定数据
        HashMap<String, Object> map = userService.getUserVoMap(userId);

        return Result.success("个人信息更新成功", map);

    }

    /**
     * 修改密码
     *
     * @return
     */
    @PutMapping("/updatePassword")
    public Result updatePassword(HttpServletRequest request,
                                 @RequestParam("oldPassword") String oldPassword,
                                 @RequestParam("newPassword") String newPassword) {
        Long userId = tokenUtil.getUserIdFromToken(request);
        Integer res = userService.updatePassword(userId, oldPassword, newPassword);
        if (res != ResponseCode.SUCCESS.val()) {
            return Result.fail(res, ResponseCode.getMsgByVal(res));
        }

        return Result.success(res, "更改密码成功，请重新登录");
    }

    /**
     * 邮箱换绑
     *
     * @return
     */
    @PutMapping("/changeEmail")
    public Result changeEmail(HttpServletRequest request, @RequestBody EmailVo emailVo) {
        Long userId = tokenUtil.getUserIdFromToken(request);
        Integer res = userService.changeEmail(userId, emailVo);
        if (res != ResponseCode.SUCCESS.val()) {
            return Result.fail(res, ResponseCode.getMsgByVal(res));
        }
        // 获取用户信息，重新绑定数据
        HashMap<String, Object> map = userService.getUserVoMap(userId);

        return Result.success("更换邮箱成功", map);
    }

    /**
     * 重置密码的邮箱验证
     *
     * @param email
     * @param code
     * @return
     */
    @PostMapping("/validationCodeForReset")
    public Result validationCodeForReset(@Email(message = ResponseConstants.INVALID_RESPONSE_CODE) @RequestParam("email") String email,
                                         @NotBlank(message = ResponseConstants.INVALID_RESPONSE_CODE) @RequestParam("code") String code) {
        Integer res = userService.validationCodeForReset(email, code);
        if (res != ResponseCode.SUCCESS.val()) {
            return Result.fail(res, ResponseCode.getMsgByVal(res));
        }
        return Result.success(res, "邮箱验证成功，请输入新密码");
    }

    /**
     * 重置密码
     *
     * @param email
     * @param code
     * @param newPassword
     * @return
     */
    @PutMapping("/resetPassword")
    public Result resetPassword(@Email(message = ResponseConstants.INVALID_RESPONSE_CODE) @RequestParam("email") String email,
                                @NotBlank(message = ResponseConstants.INVALID_RESPONSE_CODE) @RequestParam("code") String code,
                                @NotBlank(message = ResponseConstants.INVALID_RESPONSE_CODE) @RequestParam("newPassword") String newPassword) {
        Integer res = userService.resetPassword(email, code, newPassword);
        if (res != ResponseCode.SUCCESS.val()) {
            return Result.fail(res, ResponseCode.getMsgByVal(res));
        }
        return Result.success(res, "重置密码成功，请登录");
    }


    /**
     * 刷新余额
     *
     * @param request
     * @return
     */
    @GetMapping("/updateBalance")
    public Result getNewBalance(HttpServletRequest request) {

        Long userId = tokenUtil.getUserIdFromToken(request);

        HashMap<String, Object> map = userService.getUserVoMap(userId);

        return Result.success("余额已刷新", map);
    }
}
