package com.nekotaku.questionnairesystem.vo.front;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.nekotaku.questionnairesystem.common.R.ResponseConstants;
import com.nekotaku.questionnairesystem.utils.RegexPatterns;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 前台首页的问卷列表Vo对象
 *
 * @Title:SurveyFrontVo
 * @Author:NekoTaku
 * @Date:2024/05/08 14:00
 * @Version:1.0
 */
@Data
public class SurveyFrontVo implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "问卷ID(主键)")
    @TableId(value = "survey_id")
    private Long surveyId;

    @ApiModelProperty(value = "问卷标题")
    private String surveyTitle;

    @ApiModelProperty(value = "问卷创建时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
    private LocalDateTime createTime;

    @ApiModelProperty(value = "问卷分类id")
    private Long surveyCategoryId;

    @ApiModelProperty(value = "分类名")
    private String categoryName;

    @ApiModelProperty(value = "问卷状态id(发布中1、完成2、未发布0、暂停-1、未设计-2、未开始3)")
    private Integer surveyStatus;

}
