package com.nekotaku.questionnairesystem.entity;

import lombok.Data;

/**
 * @Title:AlipayBean
 * @Author:NekoTaku
 * @Date:2024/05/12 15:58
 * @Version:1.0
 */
@Data
public class AlipayBean {

    /**
     * 订单编号
     */
    private String traceNo;

    /**
     * 支付金额
     */
    private double totalAmount;

    /**
     * 商品名称
     */
    private String subject;

    /**
     * 订单追踪号，商户自己生成，可已不使用
     */
    private String alipayTraceNo;
}
