package com.nekotaku.questionnairesystem.common.page;

import lombok.Data;

import java.util.HashMap;

/**
 * 分页参数封装
 *
 * @Title:QueryPageParam
 * @Author:NekoTaku
 * @Date:2023/12/12 16:30
 * @Version:1.0
 */
@Data
public class QueryPageParam {

    // 默认
    private static Long PAGE_SIZE = 10L;
    private static Long PAGE_NUM = 1L;

    private Long pageSize = PAGE_SIZE; //每页大小
    private Long pageNum = PAGE_NUM; //页数

    private HashMap param = new HashMap();

}
