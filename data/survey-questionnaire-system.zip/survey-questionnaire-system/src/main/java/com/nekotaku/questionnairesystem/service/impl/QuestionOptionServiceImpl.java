package com.nekotaku.questionnairesystem.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.nekotaku.questionnairesystem.entity.QuestionOption;
import com.nekotaku.questionnairesystem.mapper.QuestionOptionMapper;
import com.nekotaku.questionnairesystem.service.QuestionOptionService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 * 选项表，对应问卷问题的选择题 服务实现类
 * </p>
 *
 * @author nekotaku
 * @since 2024-01-29
 */
@Service
public class QuestionOptionServiceImpl extends ServiceImpl<QuestionOptionMapper, QuestionOption> implements QuestionOptionService {

    @Autowired
    private QuestionOptionMapper questionOptionMapper;

    /**
     * 根据问题Id查找选项
     *
     * @param questionId
     * @return
     */
    @Override
    public List<QuestionOption> getQuestionOptionsByQuestionId(Long questionId) {
        LambdaQueryWrapper<QuestionOption> qw = new LambdaQueryWrapper<>();
        qw.eq(QuestionOption::getQuestionId, questionId);
        List<QuestionOption> questionOptions = questionOptionMapper.selectList(qw);
        return questionOptions;
    }

    /**
     * 根据问题Id删除选项
     *
     * @param questionId
     */
    @Override
    public void deleteOptionsByQuestionId(Long questionId) {
        LambdaQueryWrapper<QuestionOption> qw = new LambdaQueryWrapper<>();
        qw.eq(QuestionOption::getQuestionId, questionId);
        questionOptionMapper.delete(qw);
    }
}
