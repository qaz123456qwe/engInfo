package com.nekotaku.questionnairesystem.entity;

import java.io.Serializable;

import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 
 * </p>
 *
 * @author nekotaku
 * @since 2024-05-12
 */
@Data
@EqualsAndHashCode(callSuper = false)
@ApiModel(value="FrontAd对象", description="")
public class FrontAd implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "首页图Id")
    @TableId(value = "ad_id")
    private Long adId;

    @ApiModelProperty(value = "备注")
    private String adText;

    @ApiModelProperty(value = "首页图状态(1：启用，0：未启用)")
    private Integer adStatus;

    @ApiModelProperty(value = "首页图顺序")
    private Integer adSort;

    @ApiModelProperty(value = "首页图地址")
    private String adImg;


}
