package com.nekotaku.questionnairesystem.service.impl;

import com.nekotaku.questionnairesystem.entity.TmpOption;
import com.nekotaku.questionnairesystem.mapper.TmpOptionMapper;
import com.nekotaku.questionnairesystem.service.TmpOptionService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 模板选项表 服务实现类
 * </p>
 *
 * @author nekotaku
 * @since 2024-03-04
 */
@Service
public class TmpOptionServiceImpl extends ServiceImpl<TmpOptionMapper, TmpOption> implements TmpOptionService {

}
