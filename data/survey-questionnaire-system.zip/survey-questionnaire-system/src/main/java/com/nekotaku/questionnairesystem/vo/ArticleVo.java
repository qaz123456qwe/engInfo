package com.nekotaku.questionnairesystem.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 文章表实体 vo
 *
 * @Title:ArticleVo
 * @Author:NekoTaku
 * @Date:2024/03/22 8:46
 * @Version:1.0
 */
@Data
public class ArticleVo {

    @ApiModelProperty(value = "文章id")
    private Long articleId;

    @ApiModelProperty(value = "文章标题")
    private String articleTitle;

    @ApiModelProperty(value = "文章描述")
    private String articleDesc;

    @ApiModelProperty(value = "文章内容")
    private String articleContent;

    @ApiModelProperty(value = "文章封面")
    private String articleImage;

    @ApiModelProperty(value = "文章浏览量")
    private Long articleViews;

    @ApiModelProperty(value = "文章标签")
    private List<String> tags;

    @ApiModelProperty(value = "分类id")
    private Long categoryId;

    @ApiModelProperty(value = "文章分类名")
    private String CategoryName;

    @ApiModelProperty(value = "文章更新时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
    private LocalDateTime updateTime;

    @ApiModelProperty(value = "文章发表时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
    private LocalDateTime createTime;

    @ApiModelProperty(value = "是否可以浏览(1是，0否，-1还未撰写文章内容，2被封禁，3待审核)")
    private Integer articleIsOpen;

    @ApiModelProperty(value = "文章状态1是，0否，-1还未撰写文章内容，2被封禁，3待审核,由于开关只能0和1，不会有其他状态所以增加一个字段")
    private Integer articleStatus;
}
