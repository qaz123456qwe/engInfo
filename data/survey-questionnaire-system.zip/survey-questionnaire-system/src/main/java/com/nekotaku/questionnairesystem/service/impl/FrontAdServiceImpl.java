package com.nekotaku.questionnairesystem.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.util.ObjUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.OrderItem;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.nekotaku.questionnairesystem.common.R.ResponseCode;
import com.nekotaku.questionnairesystem.common.constants.upload.UpLoadConstants;
import com.nekotaku.questionnairesystem.common.enums.NaviImageStatus;
import com.nekotaku.questionnairesystem.common.page.QueryPageParam;
import com.nekotaku.questionnairesystem.entity.FrontAd;
import com.nekotaku.questionnairesystem.mapper.FrontAdMapper;
import com.nekotaku.questionnairesystem.service.FrontAdService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.nekotaku.questionnairesystem.utils.file.UploadUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author nekotaku
 * @since 2024-05-12
 */
@Service
public class FrontAdServiceImpl extends ServiceImpl<FrontAdMapper, FrontAd> implements FrontAdService {

    @Autowired
    private FrontAdMapper frontAdMapper;

    @Autowired
    private UploadUtils uploadUtils;

    /**
     * 保存导航栏图
     *
     * @param frontAd
     * @param userId
     * @return
     */
    @Override
    public Integer saveOrUpdateAdInfo(FrontAd frontAd, Long userId) {

        // 图片路径是否相同的flag
        boolean isSameImg = false;

        // 如果更新了封面图，删除旧封面图用
        String tempImgUrl = null;

        // 是否是更新操作
        if (!ObjUtil.isNull(frontAd.getAdId())) {
            // 判断封面图是否更新了
            tempImgUrl = frontAdMapper.selectById(frontAd.getAdId()).getAdImg();
            if (tempImgUrl.equals(frontAd.getAdImg())) {
                isSameImg = true;
            }
        }
        // 保存导航栏信息
        // 设置默认状态未启用
        frontAd.setAdStatus(NaviImageStatus.PRIVATE.getStatusId());

        // 设置默认顺序-1（未启用）
        frontAd.setAdSort(-1);
        boolean res = this.saveOrUpdate(frontAd);
        // 处理图片(如果图片信息更新，删除旧图片)
        if (res) {
            if (isSameImg) {
                // 图片未更新，直接返回成功
                return ResponseCode.SUCCESS.val();
            } else if (!ObjUtil.isNull(tempImgUrl)) {
                // 图片发生更新，删除旧图片
                uploadUtils.deleteFileByPath(tempImgUrl);
            }

            // 处理图片存放位置，所有上传图片默认在临时路径（会被定期删除，需要移动到正式路径）
            String adImg = frontAd.getAdImg();
            uploadUtils.copyTempFile(adImg, UpLoadConstants.NAVI_IMAGE, userId);

            return ResponseCode.SUCCESS.val();
        }

        return ResponseCode.FAIL.val();
    }

    /**
     * 分页查询导航栏图片信息
     *
     * @param queryPageParam
     * @return
     */
    @Override
    public Page<FrontAd> listFrontAdList(QueryPageParam queryPageParam) {

        Page<FrontAd> frontAdPage = new Page<>();

        // 设置当前页
        frontAdPage.setCurrent(queryPageParam.getPageNum());

        // 设置当前页面数量
        frontAdPage.setSize(queryPageParam.getPageSize());

        // 如果有启用的，排在最前面
        frontAdPage.setOrders(Arrays.asList(OrderItem.desc("ad_status")));

        // 获取查询条件
        HashMap param = queryPageParam.getParam();

        LambdaQueryWrapper<FrontAd> qw = new LambdaQueryWrapper<>();

        return this.page(frontAdPage, qw);
    }

    // 开启导航图
    @Override
    @Transactional
    public Integer openNaviImage(FrontAd frontAd) {
        // 判断是否大于五张
        if (getOpenNaviImage().size() >= 5) {
            return ResponseCode.NAVI_IMG_MANY.val();
        }
        // 更新单独的字段根据ID
        frontAd.setAdStatus(NaviImageStatus.OPEN.getStatusId());
        int i = frontAdMapper.updateById(frontAd);

        if (i > 0) {
            return ResponseCode.SUCCESS.val();
        }
        return ResponseCode.FAIL.val();
    }

    /**
     * 获取所有已开启的导航图
     *
     * @return
     */
    @Override
    public List<FrontAd> getOpenNaviImage() {
        LambdaQueryWrapper<FrontAd> qw = new LambdaQueryWrapper<>();
        // 获取所有开启状态的
        qw.eq(FrontAd::getAdStatus, NaviImageStatus.OPEN.getStatusId());
        // 按照顺序排序
        qw.orderByAsc(FrontAd::getAdSort);

        return this.list(qw);
    }

    /**
     * 删除导航图信息
     *
     * @param adId
     * @return
     */
    @Override
    public Integer deleteAdInfo(String adId) {

        // 获取导航图图路径
        if (BeanUtil.isNotEmpty(adId)) {
            String adImg = frontAdMapper.selectById(Long.parseLong(adId)).getAdImg();
            //  根据id删除导航信息
            int res = frontAdMapper.deleteById(adId);
            if (res > 0) {
                // 删除导航图
                uploadUtils.deleteFileByPath(adImg);
                return ResponseCode.SUCCESS.val();
            }
        }
        return ResponseCode.FAIL.val();
    }

}
