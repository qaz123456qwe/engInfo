package com.nekotaku.questionnairesystem.controller;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.nekotaku.questionnairesystem.common.R.ResponseCode;
import com.nekotaku.questionnairesystem.common.R.ResponseConstants;
import com.nekotaku.questionnairesystem.common.R.Result;
import com.nekotaku.questionnairesystem.common.page.QueryPageParam;
import com.nekotaku.questionnairesystem.entity.TmpSurvey;
import com.nekotaku.questionnairesystem.service.TmpSurveyService;
import com.nekotaku.questionnairesystem.utils.TokenUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.constraints.NotBlank;

/**
 * <p>
 * 模板问卷表 前端控制器
 * </p>
 *
 * @author nekotaku
 * @since 2024-03-02
 */
@RestController
@RequestMapping("/tmp-survey")
@Slf4j
public class TmpSurveyController {

    @Autowired
    private TmpSurveyService tmpSurveyService;

    @Autowired
    private TokenUtil tokenUtil;

    @PostMapping("/saveOrUpdateSurveyTmp")
    public Result saveOrUpdateSurveyTmp(@RequestBody TmpSurvey tmpSurvey,
                                        HttpServletRequest request) {

        // 获取用户id
        Long userId = tokenUtil.getUserIdFromToken(request);
        // 设置用户id
        tmpSurvey.setUserId(userId);

        // 调用保存或更新服务
        Integer res = tmpSurveyService.saveOrUpdateSurveyTmp(tmpSurvey);

        if (res != ResponseCode.SUCCESS.val()) {
            return Result.fail(res, ResponseCode.getMsgByVal(res));
        }
        return Result.success(res, "问卷模板成功");
    }

    /**
     * 分页查询当前用户所有模板问卷(可带条件查询)
     *
     * @param queryPageParam
     * @param httpServletRequest
     * @return
     */
    @PostMapping("/listTmpSurveys")
    public Result listTmpSurveys(@RequestBody QueryPageParam queryPageParam
            , HttpServletRequest httpServletRequest) {
        Long userId = tokenUtil.getUserIdFromToken(httpServletRequest);
        Page<TmpSurvey> res = tmpSurveyService.listTmpSurveys(queryPageParam, userId);

        return Result.success(ResponseCode.SUCCESS.val(), ResponseCode.SUCCESS.msg(),
                res.getRecords(), res.getTotal());
    }

    /**
     * 删除问卷模板
     *
     * @param tmpId
     * @return
     */
    @DeleteMapping("/deleteSurveyTmp/{tmpId}")
    public Result deleteSurveyTmp(@PathVariable("tmpId") Long tmpId
            , HttpServletRequest httpServletRequest) {
        Long userId = tokenUtil.getUserIdFromToken(httpServletRequest);
        Integer res = tmpSurveyService.deleteSurveyTmpById(tmpId, userId);
        if (!res.equals(ResponseCode.SUCCESS.val())) {
            return Result.fail(ResponseCode.FAIL.val(), "问卷模板删除失败");
        }
        return Result.success(ResponseCode.SUCCESS.val(), "删除问卷模板成功");
    }

    /**
     * 批量删除问卷模板
     *
     * @param ids
     * @return
     */
    @PostMapping("/deleteByIds")
    public Result deleteByIds(@NotBlank(message = ResponseConstants.INVALID_RESPONSE_CODE) String ids) {
        return tmpSurveyService.deleteByIds(ids);
    }

}
