package com.nekotaku.questionnairesystem;

import cn.hutool.core.util.StrUtil;
import cn.hutool.json.JSONUtil;
import com.nekotaku.questionnairesystem.common.constants.redis.RedisConstants;
import com.nekotaku.questionnairesystem.service.AnswerService;
import com.nekotaku.questionnairesystem.utils.Argon2PasswordEncoder;
import com.nekotaku.questionnairesystem.utils.TokenUtil;
import com.nekotaku.questionnairesystem.utils.redis.RedisBeanUtil;
import com.nekotaku.questionnairesystem.vo.analysis.SurveyAnalysisVo;
import com.nekotaku.questionnairesystem.vo.excel.ExcelWithChoiceVo;
import com.nekotaku.questionnairesystem.vo.excel.dto.ExportDto;
import com.nekotaku.questionnairesystem.vo.excel.dto.ExportDataBase;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;


@Slf4j
// 开启缓存
@EnableCaching
// 开启异步
@EnableAsync
// 开启定时任务
@EnableScheduling
@SpringBootTest
class QuestionnaireSystemApplicationTests {

    @Value("${token.secretKey}")
    private String secretKey;

    @Autowired
    private RedisTemplate redisTemplate;

    @Autowired
    private TokenUtil tokenUtil;

    @Autowired
    @Qualifier("surveyAnalysisRedisTemplate")
    private RedisTemplate<String, SurveyAnalysisVo> redisAnalysisTemplate;

    @Autowired
    private RedisBeanUtil redisBeanUtil;

    @Autowired
    private AnswerService answerService;

    @Test
    void contextLoads() {
        System.out.println(secretKey);
        System.out.println(redisTemplate.opsForValue().get("test"));
    }

    @Test
    void testArgon2() {
        System.out.println(Argon2PasswordEncoder.encode("admin"));
        Argon2PasswordEncoder.matches(Argon2PasswordEncoder.encode("admin"), "admin");
    }

    @Test
    void tesToken() {
        Map<String, String> stringStringMap = tokenUtil.parseToken("Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ0aW1lU3RhbXAiOjE3MDE1OTY1NzQ4MTYsInVzZXJSb2xlSWQiOiIxIiwidXNlcklkIjoiMTczMDU5NTA4OTEwNjk4MDg2NiJ9.4ddR-z8Rw6UhB8Jxv8QJXOWmR8Xcm1fdO7Ik-v0giAc");
        System.out.println(stringStringMap);
    }

    @Test
    void testStr() {
        String URL = "/avatar/default/defaultAvatar.jpg";
        if (URL.startsWith("/avatar")) {
            System.out.println("通过");
            ; // 允许访问静态资源
        } else {
            System.out.println("失败");
        }
    }

    @Test
    void testRedis() {
        String key = RedisConstants.ANALYZE_CHOICE_SURVEY + new Long(1768160217724325889L);
        System.out.println("redis：" + redisBeanUtil.get(redisAnalysisTemplate, key).toString());
    }

    @Test
    void testSQl() {
        Long surveyId = 1767345921696149505L;
        System.out.println("获取结果：------------------------------------------------------");
        List<ExcelWithChoiceVo> textWithChoiceAnswer = answerService.getTextWithChoiceAnswer(surveyId);

        List<ExportDto> exportDtos = new ArrayList<>();

        for (ExcelWithChoiceVo excelWithChoiceVo : textWithChoiceAnswer) {
            if (exportDtos.size() == 0) {
                // 初始化
                String answerContext = excelWithChoiceVo.getAnswerContext();

                // 创建基本模型
                List<ExportDataBase> ExportDataBases = new ArrayList<>();
                ExportDataBases.add(new ExportDataBase(excelWithChoiceVo.getQuestionContent(),
                        StrUtil.isEmpty(answerContext) ? excelWithChoiceVo.getOptionContents() : answerContext));

                ExportDto exportDto = new ExportDto();
                exportDto.setSurveyFinishLogId(excelWithChoiceVo.getSurveyFinishLogId());
                exportDto.setBases(ExportDataBases);

                exportDtos.add(exportDto);
            } else {
                Optional<ExportDto> first = exportDtos.stream().filter(exportDto -> exportDto.getSurveyFinishLogId()
                        .equals(excelWithChoiceVo.getSurveyFinishLogId())).findFirst();
                if (!first.isPresent()) {
                    // 不存在添加一个新的
                    // 初始化
                    String answerContext = excelWithChoiceVo.getAnswerContext();

                    // 创建基本模型
                    List<ExportDataBase> ExportDataBases = new ArrayList<>();
                    ExportDataBases.add(new ExportDataBase(excelWithChoiceVo.getQuestionContent(),
                            StrUtil.isEmpty(answerContext) ? excelWithChoiceVo.getOptionContents() : answerContext));

                    ExportDto exportDto = new ExportDto();
                    exportDto.setSurveyFinishLogId(excelWithChoiceVo.getSurveyFinishLogId());
                    exportDto.setBases(ExportDataBases);

                    exportDtos.add(exportDto);
                }else {
                    // 存在添加到已存在的
                    ExportDto exportDto = first.get();
                    String answerContext = excelWithChoiceVo.getAnswerContext();
                    exportDto.getBases().add(new ExportDataBase(excelWithChoiceVo.getQuestionContent(),
                            StrUtil.isEmpty(answerContext) ? excelWithChoiceVo.getOptionContents() : answerContext));
                }
            }
        }
        Long index = 1L;
        for (ExportDto exportDto : exportDtos) {
            exportDto.setSurveyFinishLogId(index++);
        }

//        System.out.println(JSONUtil.toJsonStr(exportDtos));
        System.out.println(exportDtos);
        System.out.println("获取结果：------------------------------------------------------");
    }


}
